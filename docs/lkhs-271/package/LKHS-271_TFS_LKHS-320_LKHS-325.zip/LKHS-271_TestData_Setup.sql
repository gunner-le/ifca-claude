-----------------------------------------------------------------------------------------
-- LKHS-271 / LKHS-320 / LKHS-325 - TEST DATA SETUP (local / Train) - updated 09/11
-- DO NOT COMMIT TO TFS. Run step by step (highlight each section and press F5).
-- Run AFTER all scripts of LKHS-320 and LKHS-325 (package LKHS-271_TFS_LKHS-320_LKHS-325, see the 2 READMEs).
--
-- Not done by this script (set in the screens):
--   - Company GIRO bank (CF_CompanyGiroBank): System Setup > Company Structure (Organization ID / Name, Export / Import path)
--   - Number Structure: Cash Management > "Receipt Group No" (DocCode 316_ReceiptGroup) for the test company:
--     Serial only, length 5, pad 0 (else GIRO Batch Generation says the batch no is empty)
--   - Debtor Identity No (D35, mandatory): debtor account profile (CF_Account.IdentityNo) - STEP 3 lists debtors without it
--
-- Last local test (before DB restore 09/11): company 195 (S36), GIRO bank 588 '003-922390-0 (NEW)', Org IBGGTS,
--   Rental 1812 / 1818, Construction 613 / 579, Other Receivable 2156, SWIFT 12474 (CITISGSG). IDs may differ after restore.
--
--   STEP 1  Find candidates: outstanding bills per Company / Module / Debtor
--           (same rules as View_CB_GIROCollectionPending, WITHOUT the GIRO setup conditions)
--   STEP 2  Bank accounts of the chosen company (bill currency must = bank currency)
--   STEP 3  Fill the @Setup table, then run SETUP
--   STEP 4  REVERT (only removes what this script set: test GIRO account no starts with 99900)
--
-- Requires: master setup (CF_Company.AllowGiroProcess, CF_CompanyGiroBank, AR_Debtor.AllowGiroProcess /
--           GiroBankSwiftCodeID / GiroAccountNo) and scripts 01-05 already run.
-- Company GIRO bank (CF_CompanyGiroBank) is NOT created here: set it up in the master screen
-- (System Setup > Company Structure) for the test company first.
-----------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------
-- STEP 1: candidates (choose 1-2 debtors per module, ideally in the same company)
--   ModulesInCompany = number of modules having bills in that company -> prefer the highest
--   HasGiroSetup = Y : debtor already has GIRO info (e.g. the Rental debtors set up earlier)
-----------------------------------------------------------------------------------------
;WITH b AS (
    SELECT  t.CompanyID,
            (SELECT COUNT(*) FROM dbo.CF_CompanyGiroBank g WHERE g.CompanyID = t.CompanyID AND g.RecordStatus = 'Active') AS GiroBanks,
            CASE d.RefTable WHEN 'RT_RentalContract' THEN 'Rental Management'
                            WHEN 'CF_Company'        THEN 'Other Receivable'
                            WHEN 'CF_Client'         THEN 'Construction Management'
                            WHEN 'PS_Sale'           THEN 'Property Sales' END AS Module,
            t.DebtorID, d.DebtorAcct, a.Name AS DebtorName, c.ISOCode AS Currency, t.CurrencyID,
            CASE WHEN d.AllowGiroProcess = 'Y' THEN 'Y' ELSE 'N' END AS HasGiroSetup,
            t.BillID, bal.BalanceAmt
    FROM    dbo.AR_Trx t WITH (NOLOCK)
            INNER JOIN dbo.AR_Debtor   d   WITH (NOLOCK) ON d.DebtorID    = t.DebtorID
            INNER JOIN dbo.CF_Account  a   WITH (NOLOCK) ON a.AccountID   = d.AccountID
            INNER JOIN dbo.CF_Currency c   WITH (NOLOCK) ON c.CurrencyID  = t.CurrencyID
            INNER JOIN dbo.CF_Company  com WITH (NOLOCK) ON com.CompanyID = t.CompanyID
            LEFT  JOIN dbo.AR_BillItem bi  WITH (NOLOCK) ON bi.BillItemID = t.BillItemID
            LEFT  JOIN dbo.CF_PopupLstElement bt WITH (NOLOCK) ON bt.PopupLstElementID = bi.BillTypeID
            OUTER APPLY (SELECT SUM(CASE WHEN x.RecordStatus = 'Active' THEN x.AllocAmt ELSE 0 END) AS ActiveAllocAmt
                         FROM dbo.AR_Allocation x WITH (NOLOCK) WHERE x.BillID = t.BillID) al
            CROSS APPLY (SELECT CASE WHEN d.RefTable = 'CF_Client' THEN t.DocumentAmt - ISNULL(al.ActiveAllocAmt, 0)
                                     ELSE t.BalanceAmt END AS BalanceAmt) bal
    WHERE   t.RecordStatus = CASE d.RefTable WHEN 'CF_Company' THEN 'Approved' WHEN 'CF_Client' THEN 'Approved' ELSE 'Active' END
      AND   t.DocumentAmt > 0
      AND   ROUND(bal.BalanceAmt, 2) > 0
      AND   t.DocumentDate IS NOT NULL
      AND   ISNULL(t.IsFreeze, 'N') <> 'Y'
      AND   d.RefTable IN ('RT_RentalContract', 'CF_Company', 'CF_Client', 'PS_Sale')
      AND   ISNULL(bt.ElementCode, '') <> 'RT.Deposit'
      AND   ISNULL(t.RefTable, '') <> 'RT_Deposit'
      AND   (d.RefTable <> 'CF_Company'
             OR (    (t.RefTable IS NULL OR (t.RefTable = 'AR_Trx' AND t.IsDebit = 'Y'))
                 AND EXISTS (SELECT 1 FROM dbo.View_AR_BillItemOfOtherDebtor ob WHERE ob.BillItemID = t.BillItemID)))
      AND   (d.RefTable <> 'CF_Client'
             OR (t.BalanceAmt > 0 AND t.ReceivableType IN ('PM_Retention', 'PM_Claim', 'PM_MOS', 'PM_OtherExpense', 'PM_OtherBilling')))
      AND   (d.RefTable <> 'PS_Sale'
             OR (    t.VoidDate IS NULL AND t.VoidByID IS NULL
                 AND t.DocumentNo IS NOT NULL
                 AND t.RequestUserID IS NULL
                 AND (ISNULL(t.StakeHolderFlag, 'N') = 'N' OR (t.StakeHolderFlag = 'Y' AND t.MasterBillID IS NULL AND t.TaxAmt > 0))
                 AND NOT EXISTS (SELECT 1 FROM dbo.PS_Sale s WITH (NOLOCK)
                                          INNER JOIN dbo.PS_Unit u WITH (NOLOCK) ON u.UnitID = s.UnitID
                                 WHERE s.SaleID = d.RefRecordID AND u.LockStatus = 'ContractLock')))
)
SELECT  b.CompanyID, b.GiroBanks AS CompanyGiroBanks,
        DENSE_RANK() OVER (PARTITION BY b.CompanyID ORDER BY b.Module)
          + DENSE_RANK() OVER (PARTITION BY b.CompanyID ORDER BY b.Module DESC) - 1 AS ModulesInCompany,
        b.Module, b.DebtorID, b.DebtorAcct, b.DebtorName, b.Currency, b.CurrencyID, b.HasGiroSetup,
        COUNT(*) AS BillCount, SUM(b.BalanceAmt) AS TotalBalance
FROM    b
GROUP BY b.CompanyID, b.GiroBanks, b.Module, b.DebtorID, b.DebtorAcct, b.DebtorName,
         b.Currency, b.CurrencyID, b.HasGiroSetup
ORDER BY ModulesInCompany DESC, b.CompanyID, b.Module, BillCount DESC;
GO

-----------------------------------------------------------------------------------------
-- STEP 2: bank accounts of the chosen company (pick one whose currency = bills' currency)
-----------------------------------------------------------------------------------------
DECLARE @CompanyIDForBank INT = 0;   -- <== company chosen in STEP 1
SELECT  ba.BankAccountID, ba.AccountNo, ca.Name AS BankName, c.ISOCode AS Currency, ba.CurrencyID,
        CASE WHEN EXISTS (SELECT 1 FROM dbo.CF_CompanyGiroBank g
                          WHERE g.CompanyID = ba.CompanyID AND g.GiroBankAccountID = ba.BankAccountID AND g.RecordStatus = 'Active')
             THEN 'Y' ELSE 'N' END AS IsCurrentGiroBank
FROM    dbo.CF_BankAccount ba WITH (NOLOCK)
        LEFT JOIN dbo.CF_Account  ca  WITH (NOLOCK) ON ca.AccountID   = ba.AccountID
        LEFT JOIN dbo.CF_Currency c   WITH (NOLOCK) ON c.CurrencyID   = ba.CurrencyID
WHERE   ba.CompanyID = @CompanyIDForBank
ORDER BY IsCurrentGiroBank DESC, ba.BankAccountID;
GO

-----------------------------------------------------------------------------------------
-- STEP 2b: company GIRO bank - Export / Import path (values of the last local test, change if needed)
--   Folders are NOT created by SQL: create them by hand on the web server machine.
--   Organization ID / Name are kept (set in Company Structure).
-----------------------------------------------------------------------------------------
DECLARE @GiroCompanyID     INT = 195;    -- <== S36 last test
DECLARE @GiroBankAccountID INT = 588;    -- <== '003-922390-0 (NEW)' last test
DECLARE @ExportPath NVARCHAR(500) = N'E:\IFCA Software\LKHS_Train\UpLoad\GIRO\Export';
DECLARE @ImportPath NVARCHAR(500) = N'E:\IFCA Software\LKHS_Train\UpLoad\GIRO\Import';

IF NOT EXISTS (SELECT 1 FROM dbo.CF_CompanyGiroBank WHERE CompanyID = @GiroCompanyID AND GiroBankAccountID = @GiroBankAccountID AND RecordStatus = 'Active')
    SELECT 'No active Company GIRO bank for this company / bank: set it up in Company Structure first' AS Problem;
ELSE
    UPDATE dbo.CF_CompanyGiroBank
    SET    ARExportPath = @ExportPath,
           ARImportPath = @ImportPath
    WHERE  CompanyID = @GiroCompanyID AND GiroBankAccountID = @GiroBankAccountID AND RecordStatus = 'Active';

SELECT  g.CompanyGiroBankID, g.CompanyID, g.GiroBankAccountID, ba.AccountNo, g.OrganizationID, g.OrganizationName,
        g.ARExportPath, g.ARImportPath, g.RecordStatus
FROM    dbo.CF_CompanyGiroBank g WITH (NOLOCK)
        LEFT JOIN dbo.CF_BankAccount ba WITH (NOLOCK) ON ba.BankAccountID = g.GiroBankAccountID
WHERE   g.CompanyID = @GiroCompanyID;

-- SWIFT codes available for @SwiftCodeID of STEP 3 (LookupID)
SELECT LookupID, LookupCode AS SwiftCode, LookupName AS BankName FROM dbo.View_CB_GIROLookup WHERE LookupType = 'SWIFT' ORDER BY LookupCode;
GO

-----------------------------------------------------------------------------------------
-- STEP 3: SETUP
--   Fill @Setup: one row per test debtor (CompanyID, GIRO BankAccountID, DebtorID).
--   - BankAccountID must be an active company GIRO bank (CF_CompanyGiroBank, IsCurrentGiroBank = Y in STEP 2).
--   - Company: AllowGiroProcess = 'Y'.
--   - Debtor GIRO info is set only when GiroAccountNo is NULL (real setup is never overwritten);
--     AllowGiroProcess = 'Y' is set for all test debtors.
--   - Test GIRO account no = 99900 + DebtorID (marker used by REVERT).
--   - @SwiftCodeID: optional (SWIFT dropdown ID on THIS server; NULL = leave empty, list does not need it).
-----------------------------------------------------------------------------------------
DECLARE @Setup TABLE (CompanyID INT, BankAccountID INT, DebtorID INT);
INSERT INTO @Setup (CompanyID, BankAccountID, DebtorID) VALUES   -- values of the last local test (S36, bank 588)
    (195, 588, 1812)   -- Rental           IndoStop Singapore Pte Ltd
  , (195, 588, 1818)   -- Rental           TT Quick Massage Pte. Ltd.
  , (195, 588, 2156)   -- Other Receivable Balestier Tower Pte Ltd
  , (195, 588, 613)    -- Construction     Milano Central Pte. Ltd.
  , (195, 588, 579)    -- Construction     De Arte Hair Studio Pte Ltd
  , (0, 0, 0);         -- <== Property Sales (no PS debtor with bills in S36 last time)

DECLARE @SwiftCodeID INT = 12474;   -- CITISGSG (last test); check the list of STEP 2b

DELETE FROM @Setup WHERE CompanyID = 0 OR BankAccountID = 0 OR DebtorID = 0;

-- checks
SELECT 'Bank not in company' AS Problem, s.* FROM @Setup s
WHERE NOT EXISTS (SELECT 1 FROM dbo.CF_BankAccount ba WHERE ba.BankAccountID = s.BankAccountID AND ba.CompanyID = s.CompanyID)
UNION ALL
SELECT 'Bank is not a company GIRO bank (set it up in Company Structure first)', s.* FROM @Setup s
WHERE NOT EXISTS (SELECT 1 FROM dbo.CF_CompanyGiroBank g
                  WHERE g.CompanyID = s.CompanyID AND g.GiroBankAccountID = s.BankAccountID AND g.RecordStatus = 'Active')
UNION ALL
SELECT 'Debtor already has GIRO setup (kept as is)', s.* FROM @Setup s
JOIN dbo.AR_Debtor d ON d.DebtorID = s.DebtorID
WHERE d.GiroAccountNo IS NOT NULL
UNION ALL
SELECT 'Debtor has no Identity No in account profile (D35) -> GIRO Batch Generation will be blocked', s.* FROM @Setup s
JOIN dbo.AR_Debtor d ON d.DebtorID = s.DebtorID
JOIN dbo.CF_Account a ON a.AccountID = d.AccountID
WHERE ISNULL(a.IdentityNo, '') = '';

BEGIN TRAN;

UPDATE com SET com.AllowGiroProcess = 'Y'
FROM   dbo.CF_Company com
WHERE  com.CompanyID IN (SELECT CompanyID FROM @Setup)
  AND  ISNULL(com.AllowGiroProcess, 'N') <> 'Y';

UPDATE d SET d.GiroAccountNo       = CAST(99900 AS VARCHAR(10)) + CAST(d.DebtorID AS VARCHAR(10)),
             d.GiroBankSwiftCodeID = ISNULL(@SwiftCodeID, d.GiroBankSwiftCodeID)
FROM   dbo.AR_Debtor d
       JOIN @Setup s ON s.DebtorID = d.DebtorID
WHERE  d.GiroAccountNo IS NULL;

UPDATE d SET d.AllowGiroProcess = 'Y'
FROM   dbo.AR_Debtor d
WHERE  d.DebtorID IN (SELECT DebtorID FROM @Setup)
  AND  ISNULL(d.AllowGiroProcess, 'N') <> 'Y';

COMMIT TRAN;

-- result: what the GIRO list will show per company / bank / module
SELECT v.CompanyID, v.GIROBankAccountID, v.Module, v.DebtorID, v.DebtorName, v.Currency,
       COUNT(*) AS BillCount, SUM(v.BalanceAmt) AS TotalBalance
FROM   dbo.View_CB_GIROCollectionPending v
WHERE  v.DebtorID IN (SELECT DebtorID FROM @Setup)
GROUP BY v.CompanyID, v.GIROBankAccountID, v.Module, v.DebtorID, v.DebtorName, v.Currency
ORDER BY v.CompanyID, v.Module;
GO

-----------------------------------------------------------------------------------------
-- STEP 4: REVERT (run when the real master setup is ready)
--   Debtors: only those carrying the test marker (GiroAccountNo starts with 99900).
--   Companies: list the companies set by STEP 3 in @RevertCompany (AllowGiroProcess cleared; GIRO bank master untouched).
-----------------------------------------------------------------------------------------
/*
DECLARE @RevertCompany TABLE (CompanyID INT);
INSERT INTO @RevertCompany VALUES (0);   -- <== same company as STEP 3 (only if it was not GIRO before)

BEGIN TRAN;
UPDATE dbo.AR_Debtor SET AllowGiroProcess = NULL, GiroBankSwiftCodeID = NULL, GiroAccountNo = NULL
WHERE  GiroAccountNo LIKE '99900%';

UPDATE com SET com.AllowGiroProcess = NULL
FROM   dbo.CF_Company com JOIN @RevertCompany r ON r.CompanyID = com.CompanyID;
COMMIT TRAN;
*/
