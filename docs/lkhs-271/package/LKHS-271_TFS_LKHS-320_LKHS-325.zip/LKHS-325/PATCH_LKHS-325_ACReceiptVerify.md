# LKHS-325: hướng dẫn sửa màn Collection Verification

Sửa tay 2 file **có sẵn**, chỉ **thêm** code, không xoá hay đổi dòng cũ:

| Đợt | File | Mục |
|---|---|---|
| 2a | `CashFlow/ACReceiptVerify.aspx.cs` | 1, 2 |
| 2a | `CashFlow/ACReceiptVerify.aspx` | 3, 4 |
| 2b | chỉ `CashFlow/ACReceiptVerify.aspx` | 5, 6 (sửa tiếp trên bản đã sửa 2a) |
| 2c | `CashFlow/ACReceiptVerify.aspx.cs` | 7 (sửa tiếp trên bản đã sửa 2a/2b) |
| 2c | `CashFlow/ACReceiptVerify.aspx` | 8 (sửa tiếp trên bản đã sửa 2a/2b) |
| 2d | chỉ `CashFlow/ACReceiptVerify.aspx` | 9 (nút Cancel sáng/mờ theo cột GIRO, cần script 12 + 13) |

- Mọi đoạn thêm vào đều có comment `LKHS-325 GIRO` để dễ tìm và so với TFS.
- Số dòng ghi trong file này là theo bản gốc anh gửi ngày 04/11, dùng để tham khảo; nên tìm theo **dòng mốc**.
- Nút **GIRO Batch Generation** trên toolbar được tạo bằng script `08_Config_CB_GIROBatchGenerate.sql`, không cần sửa file.

---

## 1. `ACReceiptVerify.aspx.cs`: hàm `ReceiptVerify` chặn phiếu GIRO (khoảng dòng 110)

**Dòng mốc:**
```csharp
        string selectReceiptIDs = str[1];
```

**Thêm ngay sau dòng mốc:**
```csharp
        // LKHS-325 GIRO: GIRO receipts are verified by Import GIRO Batch only
        string giroDocs = Convert.ToString(DataAccessHelper.ExecuteScalar(string.Format(
            "select STUFF((select ','+DocNo from CB_Receipt where IsGiroReceipt = 'Y' and CBReceiptID in ({0}) FOR XML PATH('')),1,1,'')", selectReceiptIDs)));
        if (!string.IsNullOrEmpty(giroDocs))
            return Strings.GetString("CB.GIRO_VerifyBlocked") + "<br>" + giroDocs;
        // LKHS-325 GIRO end
```

## 2. `ACReceiptVerify.aspx.cs`: hàm `VerifyAll` bỏ qua phiếu GIRO (khoảng dòng 199)

**Dòng mốc** (trong `public static string VerifyAll(string filter)`):
```csharp
        string strMessage = "";
        string strSql = string.Empty;
```

**Thêm ngay sau 2 dòng mốc:**
```csharp
        // LKHS-325 GIRO: Verify All skips GIRO receipts (verified by Import GIRO Batch)
        filter = "(" + filter + ") and CBReceiptID not in (select CBReceiptID from CB_Receipt where IsGiroReceipt = 'Y')";
```

`filter` được dùng cho cả câu kiểm tra Cash Account lẫn 2 câu UPDATE phía dưới, nên chỉ cần thêm 1 dòng này.

## 3. `ACReceiptVerify.aspx`: hàm `OnBeforeMenu` để nút GIRO luôn sáng (khoảng dòng 677)

Mặc định `OnBeforeMenu` tắt mọi nút khi chưa chọn dòng. Nút GIRO Batch Generation không cần chọn dòng.

**Dòng mốc:**
```javascript
             else if(pc[i] =="ItemProfile"||pc[i]=="VerifyAll")
```

**Thêm ngay TRƯỚC dòng mốc:**
```javascript
             else if(pc[i]=="GIROBatchGenerate")   // LKHS-325 GIRO: no row needed
             {
                document.getElementById(pc[i]).disabled=0;
                PubPrive=PubPrive+"0";
             }
```

Kết quả sau khi sửa:
```javascript
             if(pc[i]=="Journal")
             {
                ...
             }
             else if(pc[i]=="GIROBatchGenerate")   // LKHS-325 GIRO: no row needed
             {
                document.getElementById(pc[i]).disabled=0;
                PubPrive=PubPrive+"0";
             }
             else if(pc[i] =="ItemProfile"||pc[i]=="VerifyAll")
             {
```

## 4. `ACReceiptVerify.aspx`: thêm 2 hàm JS (khoảng dòng 712)

**Dòng mốc:**
```javascript
function f_VerifyAll()
```

**Thêm ngay TRƯỚC dòng mốc:**
```javascript
// LKHS-325 GIRO: GIRO Batch Generation popup (opens blank, user selects the GIRO bank there)
function f_GIROBatchGenerate()
{
    var companyID = document.getElementById("<% =this.CompanyID.ClientID%>").value;
    if (companyID == null || companyID == "")
    {
        var MsgWarnCollection = {Title:"<%=Strings.GetString("CommonSaveTitle") %>",Tip:"<%=Strings.GetString("CB.GIROBatch_SelectCompany")%>",Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("Ok") %>",Event:""}]};
        MessageShow(MsgWarnCollection);
        return;
    }
    sysf_opensubonewin("../CashFlow/ARGIROBatchGenerate.aspx?CompanyID=" + companyID, 950, 650, "yes");
}

// LKHS-325 GIRO: called by the popup after a batch is saved -> reload the list (same filter as refresh(), without message)
function f_GIROAfterBatch()
{
    var filter = " ";
    if(document.getElementById("<% =this.CompanyID.ClientID%>").value!="")
    {
       filter = "CompanyID= " + document.getElementById("<% =this.CompanyID.ClientID%>").value;
    }
    if(document.getElementById("<% =this.CurrPayMethod.ClientID%>").value!="")
    {
       if(filter.length>0)filter=filter+" and ";
       filter=filter+" payMethod="+document.getElementById("<% =this.CurrPayMethod.ClientID%>").value;
    }
    f_ReLoad(GetFilter(filter));
}
// LKHS-325 GIRO end

```

---

## Ghi chú
- Phân quyền: nút mới có `IsNeedPrivilege = 'N'`, giống các nút GIRO ở bước 6. Nếu nút không hiện thì kiểm tra quyền menu `mcorp-15-07` của role.
- Popup cần chọn company trên cây bên trái trước khi bấm nút (dùng ô ẩn `CompanyID` có sẵn của trang).

---

# Đợt 2b: thêm nút GIRO Batch Listing

Nút **GIRO Batch Listing** trên toolbar do script `10_Config_CB_GIROBatchList.sql` tạo. Ở file `ACReceiptVerify.aspx` sửa thêm 2 chỗ, chỉ thêm code, không đụng các dòng cũ.

## 5. `ACReceiptVerify.aspx`: `OnBeforeMenu` cho nút Listing luôn sáng

**Dòng mốc** (đã thêm ở mục 3, đợt 2a):
```javascript
             else if(pc[i]=="GIROBatchGenerate")   // LKHS-325 GIRO: no row needed
```

**Sửa thành:**
```javascript
             else if(pc[i]=="GIROBatchGenerate"||pc[i]=="GIROBatchListing")   // LKHS-325 GIRO: no row needed
```

## 6. `ACReceiptVerify.aspx`: thêm hàm mở trang Listing

**Dòng mốc** (đã thêm ở mục 4, đợt 2a):
```javascript
// LKHS-325 GIRO: called by the popup after a batch is saved -> reload the list (same filter as refresh(), without message)
```

**Thêm ngay TRƯỚC dòng mốc:**
```javascript
// LKHS-325 GIRO: GIRO Batch Listing popup (Reset / Import / Complete (All Success))
function f_GIROBatchListing()
{
    var companyID = document.getElementById("<% =this.CompanyID.ClientID%>").value;
    if (companyID == null || companyID == "")
    {
        var MsgWarnCollection = {Title:"<%=Strings.GetString("CommonSaveTitle") %>",Tip:"<%=Strings.GetString("CB.GIROBatch_SelectCompany")%>",Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("Ok") %>",Event:""}]};
        MessageShow(MsgWarnCollection);
        return;
    }
    sysf_opensubonewin("../CashFlow/ARGIROBatchLst.aspx?CompanyID=" + companyID, 1100, 600, "yes");
}

```
Trang Listing gọi lại `f_GIROAfterBatch()` (đã có từ đợt 2a) sau khi Reset / Complete, để tải lại danh sách phiếu.


---

# Đợt 2c: thêm nút Cancel (Cancel Receipt Action cho phiếu GIRO chưa vào batch)

Nút **Cancel** trên toolbar do script `11_Config_CB_GIROBatchImport.sql` tạo (`ContextMnuNo = GIROCancel`). Theo tài liệu Stanley, nút chỉ dùng cho phiếu GIRO có Group No trống và trạng thái Generated. Việc kiểm tra này làm ở server: nếu tick phiếu không hợp lệ thì báo danh sách phiếu và không huỷ phiếu nào. Nút sáng/mờ theo quy tắc mặc định của trang (sáng khi có tick), **không cần sửa `OnBeforeMenu`**.

## 7. `ACReceiptVerify.aspx.cs`: thêm WebMethod huỷ phiếu GIRO

**Dòng mốc:**
```csharp
    [WebMethod(true)]
    public static string VerifyAll(string filter)
```

**Thêm ngay TRƯỚC dòng mốc:**
```csharp
    // LKHS-325 GIRO: Cancel button = Cancel Receipt Action for GIRO receipts not yet in a batch (Generated)
    [WebMethod(true)]
    public static string GIROCancelReceipt(string receiptIDs)
    {
        try
        {
            return new GIROBatchService().CancelGeneratedReceipts(receiptIDs, int.Parse(IFCA.Framework.UI.SysContext.CurrentUserId));
        }
        catch (GIROException ex)
        {
            return ex.Message;
        }
    }
    // LKHS-325 GIRO end

```

## 8. `ACReceiptVerify.aspx`: thêm 3 hàm JS cho nút Cancel

**Dòng mốc** (hàm gốc của trang):
```javascript
function f_VerifyAll()
```

**Thêm ngay TRƯỚC dòng mốc** (tức là sau các hàm GIRO đã thêm ở đợt 2a/2b):
```javascript
// LKHS-325 GIRO: Cancel = Cancel Receipt Action (void + release bills) for ticked GIRO receipts not yet in a batch
function f_GIROCancel()
{
    var selectid = gridManager2.GetSelectedRowIds();
    if (selectid == null || selectid.length == 0)
    {
        alert("<%=Strings.GetString("MustSelectReceipt") %>!");
        return;
    }
    var msg = {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:"<%=Strings.GetString("CB.GIROCancel_Confirm")%>",Pic:"Remind",
               Buttons:[{Name:"<%=Strings.GetString("OK")%>",Event:"f_DoGIROCancel('" + selectid + "')"},{Name:"<%=Strings.GetString("Cancel") %>",Event:""}]};
    MessageShow(msg);
}
function f_DoGIROCancel(selectid)
{
    f_MessageWait();
    PageMethods.GIROCancelReceipt(selectid.toString(), f_GIROCancelDone, f_OnCallWebServiceFailure);
}
function f_GIROCancelDone(result)
{
    MessageClose();
    refresh(result);   // message + reload the list (same as Verify)
}
// LKHS-325 GIRO end

```


---

# Đợt 2d: nút Cancel sáng/mờ theo cột GIRO

Sau khi chạy script `12_Alter_View_AC_Receipt_GIRO.sql` và `13_Config_AC_Receipt_GIRO.sql`, grid Collection Verification có thêm 3 cột `Is GIRO Receipt`, `GIRO Batch No`, `GIRO Status`. Nút Cancel lúc này **chỉ sáng** khi mọi dòng đang tick đều là phiếu GIRO, Group No trống, GIRO Status = Generated (theo tài liệu Stanley). Server vẫn kiểm tra lại khi bấm.

## 9. `ACReceiptVerify.aspx`: `OnBeforeMenu` cho nút Cancel

**Dòng mốc** (code gốc của trang, trong `OnBeforeMenu`):
```javascript
             else if(pc[i] =="ItemProfile"||pc[i]=="VerifyAll")
```

**Thêm ngay TRƯỚC dòng mốc** (sau đoạn `GIROBatchGenerate||GIROBatchListing` của đợt 2a/2b):
```javascript
             else if(pc[i]=="GIROCancel")   // LKHS-325 GIRO: only ticked GIRO receipts, Group No empty, Generated
             {
                var giroOk = f_GIROCanCancel(selectRowId);
                document.getElementById(pc[i]).disabled = giroOk ? 0 : 1;
                PubPrive = PubPrive + (giroOk ? "0" : "1");
             }
```

**Thêm hàm** ngay TRƯỚC dòng mốc `function f_VerifyAll()` (cạnh các hàm GIRO của mục 8):
```javascript
// LKHS-325 GIRO: Cancel enabled only when every ticked row is a GIRO receipt not yet in a batch (Generated)
function f_GIROCanCancel(ids)
{
    if (ids == null || ids.toString() == "") return false;
    var arr = ids.toString().split(",");
    var rows = gridManager2.GetValidRows();
    var found = 0;
    for (var m = 0; m < rows.length; m++)
    {
        var id = String(gridManager2.GetValueByName(rows[m], "cbreceiptid"));
        if (("," + arr.join(",") + ",").indexOf("," + id + ",") < 0) continue;
        found++;
        if (gridManager2.GetValueByName(rows[m], "isgiroreceipt") != "Y") return false;
        if ((gridManager2.GetValueByName(rows[m], "groupno") || "") != "") return false;
        if (gridManager2.GetValueByName(rows[m], "girorecordstatus") != "Generated") return false;
    }
    return found == arr.length;
}
// LKHS-325 GIRO end

```

Ghi chú: `OnBeforeMenu` của trang chỉ chạy khi click dòng (`AfterRowActivate`), không chạy khi chỉ tick checkbox. Đây là hành vi sẵn có của mọi nút trên trang nên giữ nguyên. Nếu tick xong mà nút chưa đổi, click vào 1 dòng để trang cập nhật.
