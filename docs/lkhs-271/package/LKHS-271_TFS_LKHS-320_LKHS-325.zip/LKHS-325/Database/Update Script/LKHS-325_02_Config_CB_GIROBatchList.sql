-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - dot 2b: GIRO Batch Listing (popup CashFlow/ARGIROBatchLst.aspx)
-- Script 10: Sys_ framework config + strings
--   BseNo / LstNo / MnuClass CB.GIROBatchList (criteria + batch grid + Import / Verify / Reset / Close - doc v01.01)
--   Collection Verification (mcorp-15-07 / AC.ReceiptVerify): new toolbar button GIROBatchListing (only this row is deleted / inserted)
-- Re-runnable: each block deletes existing rows then inserts again.
-- Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------

-- Sys_Base
IF EXISTS (SELECT TOP 1 1 FROM Sys_Base WITH (NOLOCK) WHERE BseNo = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_Base WHERE BseNo = N'CB.GIROBatchList';
END

INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROBatchList', N'GIRO Batch Listing', N'Sys_Base_Name_CB.GIROBatchList', N'View_CB_ReceiptGroup_GIRO', N'CB_ReceiptGroup', N'GIRO Batch Listing', N'Sys_Base_Desc_CB.GIROBatchList', N'CBReceiptGroupID', NULL, NULL, NULL);

-- Sys_BaseDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo = N'CB.GIROBatchList';
END

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CBReceiptGroupID', N'Batch ID', N'Batch ID', N'CB.GIROBatchList_CBReceiptGroupID', N'CB.GIROBatchList_CBReceiptGroupID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 1, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROBatchList_CompanyID', N'CB.GIROBatchList_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 2, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'BankName', N'Bank Name', N'Bank Name', N'CB.GIROBatchList_BankName', N'CB.GIROBatchList_BankName', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 3, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'ACNo', N'Account No', N'Account No', N'CB.GIROBatchList_ACNo', N'CB.GIROBatchList_ACNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 4, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROBatchList_CurrencyID', N'CB.GIROBatchList_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 5, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'Currency', N'Currency', N'Currency', N'CB.GIROBatchList_Currency', N'CB.GIROBatchList_Currency', 40, N'L2', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 6, NULL, N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'GroupNo', N'GIRO Batch No', N'GIRO Batch No', N'CB.GIROBatchList_GroupNo', N'CB.GIROBatchList_GroupNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 7, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'ReferenceNo', N'Reference No', N'Reference No', N'CB.GIROBatchList_ReferenceNo', N'CB.GIROBatchList_ReferenceNo', 35, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 8, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'DocumentDate', N'Payment Date', N'Payment Date', N'CB.GIROBatchList_DocumentDate', N'CB.GIROBatchList_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 9, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'PurposeCode', N'Purpose Code', N'Purpose Code', N'CB.GIROBatchList_PurposeCode', N'CB.GIROBatchList_PurposeCode', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 10, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'TotalDebtor', N'Total No Debtor', N'Total No Debtor', N'CB.GIROBatchList_TotalDebtor', N'CB.GIROBatchList_TotalDebtor', 8, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 11, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'TotalAmt', N'Total Amount', N'Total Amount', N'CB.GIROBatchList_TotalAmt', N'CB.GIROBatchList_TotalAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 12, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CreatedBy', N'Created By', N'Created By', N'CB.GIROBatchList_CreatedBy', N'CB.GIROBatchList_CreatedBy', 100, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 13, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CreateDate', N'Create Date', N'Create Date', N'CB.GIROBatchList_CreateDate', N'CB.GIROBatchList_CreateDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 14, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'RecordStatus', N'Status', N'Status', N'CB.GIROBatchList_RecordStatus', N'CB.GIROBatchList_RecordStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 15, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'Filename', N'File Name', N'File Name', N'CB.GIROBatchList_Filename', N'CB.GIROBatchList_Filename', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 16, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'TotalReceipt', N'Total No Receipt', N'Total No Receipt', N'CB.GIROBatchList_TotalReceipt', N'CB.GIROBatchList_TotalReceipt', 8, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 17, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'BankAccountID', N'Bank Account ID', N'Bank Account ID', N'CB.GIROBatchList_BankAccountID', N'CB.GIROBatchList_BankAccountID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 18, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'RecordType', N'Record Type', N'Record Type', N'CB.GIROBatchList_RecordType', N'CB.GIROBatchList_RecordType', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 19, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'CreateUserID', N'Create User ID', N'Create User ID', N'CB.GIROBatchList_CreateUserID', N'CB.GIROBatchList_CreateUserID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 20, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchList', N'ModifyDate', N'Modify Date', N'Modify Date', N'CB.GIROBatchList_ModifyDate', N'CB.GIROBatchList_ModifyDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'0', NULL, 21, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

-- Sys_List
IF EXISTS (SELECT TOP 1 1 FROM Sys_List WITH (NOLOCK) WHERE LstNo = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_List WHERE LstNo = N'CB.GIROBatchList';
END

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROBatchList', -1, N'GIRO Batch Listing', N'Sys_List_Name_CB.GIROBatchList_-1', N'GIRO Batch Listing', N'Sys_List_Title_CB.GIROBatchList_-1', N'CB.GIROBatchList', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROBatchList', 1, N'GIRO Batch Listing', N'Sys_List_Name_CB.GIROBatchList_1', N'GIRO Batch Listing', N'Sys_List_Title_CB.GIROBatchList_1', N'CB.GIROBatchList', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);

-- Sys_ListDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROBatchList';
END

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'BankName', N'Bank Name', NULL, N'CB.GIROBatchList_BankName', N'CB.GIROBatchList_BankName', 200, 140, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'ACNo', N'Account No', NULL, N'CB.GIROBatchList_ACNo', N'CB.GIROBatchList_ACNo', 50, 130, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'Currency', N'Currency', NULL, N'CB.GIROBatchList_Currency', N'CB.GIROBatchList_Currency', 40, 50, N'left', NULL, N'L2', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'GroupNo', N'GIRO Batch No', NULL, N'CB.GIROBatchList_GroupNo', N'CB.GIROBatchList_GroupNo', 50, 80, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'ReferenceNo', N'Reference No', NULL, N'CB.GIROBatchList_ReferenceNo', N'CB.GIROBatchList_ReferenceNo', 35, 110, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'DocumentDate', N'Payment Date', NULL, N'CB.GIROBatchList_DocumentDate', N'CB.GIROBatchList_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'PurposeCode', N'Purpose Code', NULL, N'CB.GIROBatchList_PurposeCode', N'CB.GIROBatchList_PurposeCode', 20, 70, N'left', NULL, N'S', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'TotalDebtor', N'Total No Debtor', NULL, N'CB.GIROBatchList_TotalDebtor', N'CB.GIROBatchList_TotalDebtor', 8, 70, N'right', NULL, N'I', N'1', 8, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'TotalAmt', N'Total Amount', NULL, N'CB.GIROBatchList_TotalAmt', N'CB.GIROBatchList_TotalAmt', 13, 110, N'right', NULL, N'FM', N'1', 9, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'CreatedBy', N'Created By', NULL, N'CB.GIROBatchList_CreatedBy', N'CB.GIROBatchList_CreatedBy', 100, 100, N'left', NULL, N'S', N'1', 10, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'CreateDate', N'Create Date', NULL, N'CB.GIROBatchList_CreateDate', N'CB.GIROBatchList_CreateDate', 8, 80, N'center', NULL, N'D', N'1', 11, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'RecordStatus', N'Status', NULL, N'CB.GIROBatchList_RecordStatus', N'CB.GIROBatchList_RecordStatus', 20, 70, N'left', NULL, N'S', N'1', 12, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', -1, N'Filename', N'File Name', NULL, N'CB.GIROBatchList_Filename', N'CB.GIROBatchList_Filename', 200, 250, N'left', NULL, N'S', N'1', 13, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'BankName', N'Bank Name', NULL, N'CB.GIROBatchList_BankName', N'CB.GIROBatchList_BankName', 200, 140, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'ACNo', N'Account No', NULL, N'CB.GIROBatchList_ACNo', N'CB.GIROBatchList_ACNo', 50, 130, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'Currency', N'Currency', NULL, N'CB.GIROBatchList_Currency', N'CB.GIROBatchList_Currency', 40, 50, N'left', NULL, N'L2', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'GroupNo', N'GIRO Batch No', NULL, N'CB.GIROBatchList_GroupNo', N'CB.GIROBatchList_GroupNo', 50, 80, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'ReferenceNo', N'Reference No', NULL, N'CB.GIROBatchList_ReferenceNo', N'CB.GIROBatchList_ReferenceNo', 35, 110, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'DocumentDate', N'Payment Date', NULL, N'CB.GIROBatchList_DocumentDate', N'CB.GIROBatchList_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'PurposeCode', N'Purpose Code', NULL, N'CB.GIROBatchList_PurposeCode', N'CB.GIROBatchList_PurposeCode', 20, 70, N'left', NULL, N'S', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'TotalDebtor', N'Total No Debtor', NULL, N'CB.GIROBatchList_TotalDebtor', N'CB.GIROBatchList_TotalDebtor', 8, 70, N'right', NULL, N'I', N'1', 8, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'TotalAmt', N'Total Amount', NULL, N'CB.GIROBatchList_TotalAmt', N'CB.GIROBatchList_TotalAmt', 13, 110, N'right', NULL, N'FM', N'1', 9, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'CreatedBy', N'Created By', NULL, N'CB.GIROBatchList_CreatedBy', N'CB.GIROBatchList_CreatedBy', 100, 100, N'left', NULL, N'S', N'1', 10, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'CreateDate', N'Create Date', NULL, N'CB.GIROBatchList_CreateDate', N'CB.GIROBatchList_CreateDate', 8, 80, N'center', NULL, N'D', N'1', 11, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'RecordStatus', N'Status', NULL, N'CB.GIROBatchList_RecordStatus', N'CB.GIROBatchList_RecordStatus', 20, 70, N'left', NULL, N'S', N'1', 12, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchList', 1, N'Filename', N'File Name', NULL, N'CB.GIROBatchList_Filename', N'CB.GIROBatchList_Filename', 200, 250, N'left', NULL, N'S', N'1', 13, N'1', NULL, NULL, NULL);

-- Sys_Filter (search fields above the list)
IF EXISTS (SELECT TOP 1 1 FROM Sys_Filter WITH (NOLOCK) WHERE FltBseNo = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_Filter WHERE FltBseNo = N'CB.GIROBatchList';
END

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 1, 0, N'ACNo');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 2, 0, N'BankName');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 3, 0, N'Currency');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 4, 0, N'GroupNo');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 5, 0, N'ReferenceNo');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'D', NULL, 0, 1, NULL, NULL, 1, NULL, 6, 0, N'DocumentDate');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 7, 0, N'PurposeCode');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROBatchList', N'CB.GIROBatchList', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 8, 0, N'RecordStatus');

-- Sys_ContextMenuClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenuClass WITH (NOLOCK) WHERE MnuClass = N'CB.GIROBatchList')
BEGIN
    DELETE FROM Sys_ContextMenuClass WHERE MnuClass = N'CB.GIROBatchList';
END

INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROBatchList', N'MnuClass_CB.GIROBatchList');

-- Sys_ContextMenu (Import / Verify / Reset / Close)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'CB.GIROBatchList' AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE MnuClass = N'CB.GIROBatchList' AND MnuNo = N'mcorp-15-07';
END

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Import', N'CB.GIROBatchList', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchList_Import', N'f_GIROBatchImport()', NULL, 1, N'N', N'N', NULL, NULL, 1);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Verify', N'CB.GIROBatchList', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchList_Verify', N'f_GIROBatchVerify()', NULL, 1, N'N', N'N', NULL, NULL, 2);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Reset', N'CB.GIROBatchList', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchList_Reset', N'f_GIROBatchReset()', NULL, 1, N'N', N'N', NULL, NULL, 3);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROBatchList', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchList_Close', N'f_Close()', NULL, 1, N'N', N'N', NULL, NULL, 4);

-- Sys_ContextMenu: Collection Verification toolbar - new button 'GIROBatchListing' (other buttons untouched; SeqNo = last + 1)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE ContextMnuNo = N'GIROBatchListing' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE ContextMnuNo = N'GIROBatchListing' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';
END
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
SELECT N'GIROBatchListing', N'AC.ReceiptVerify', N'mcorp-15-07', N'mcorp-15-07_AC.ReceiptVerify_GIROBatchListing', N'f_GIROBatchListing()', NULL, 1, N'N', N'N', N'btn_selectall.gif', NULL, ISNULL(MAX(SeqNo), 0) + 1
FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';


-- CF_String
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (
    N'CB.GIROBatchList_CBReceiptGroupID',
    N'CB.GIROBatchList_CompanyID',
    N'CB.GIROBatchList_BankName',
    N'CB.GIROBatchList_ACNo',
    N'CB.GIROBatchList_CurrencyID',
    N'CB.GIROBatchList_Currency',
    N'CB.GIROBatchList_GroupNo',
    N'CB.GIROBatchList_ReferenceNo',
    N'CB.GIROBatchList_DocumentDate',
    N'CB.GIROBatchList_PurposeCode',
    N'CB.GIROBatchList_TotalDebtor',
    N'CB.GIROBatchList_TotalAmt',
    N'CB.GIROBatchList_CreatedBy',
    N'CB.GIROBatchList_CreateDate',
    N'CB.GIROBatchList_RecordStatus',
    N'CB.GIROBatchList_Filename',
    N'CB.GIROBatchList_TotalReceipt',
    N'CB.GIROBatchList_BankAccountID',
    N'CB.GIROBatchList_RecordType',
    N'CB.GIROBatchList_CreateUserID',
    N'CB.GIROBatchList_ModifyDate',
    N'Sys_Base_Name_CB.GIROBatchList',
    N'Sys_Base_Desc_CB.GIROBatchList',
    N'Sys_List_Name_CB.GIROBatchList_-1',
    N'Sys_List_Title_CB.GIROBatchList_-1',
    N'Sys_List_Name_CB.GIROBatchList_1',
    N'Sys_List_Title_CB.GIROBatchList_1',
    N'MnuClass_CB.GIROBatchList',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchListing',
    N'mcorp-15-07_CB.GIROBatchList_Import',
    N'mcorp-15-07_CB.GIROBatchList_Verify',
    N'mcorp-15-07_CB.GIROBatchList_Reset',
    N'mcorp-15-07_CB.GIROBatchList_Close',
    N'CB.GIROBatchList_Title',
    N'CB.GIROBatch_SelectOneBatch',
    N'CB.GIROBatch_ViewOnly',
    N'CB.GIROBatch_NotFound',
    N'CB.GIROBatch_NotExported',
    N'CB.GIROBatch_ResetConfirm',
    N'CB.GIROBatch_ResetSuccess',
    N'CB.GIROBatch_ReceiptNotExported'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (
    N'CB.GIROBatchList_CBReceiptGroupID',
    N'CB.GIROBatchList_CompanyID',
    N'CB.GIROBatchList_BankName',
    N'CB.GIROBatchList_ACNo',
    N'CB.GIROBatchList_CurrencyID',
    N'CB.GIROBatchList_Currency',
    N'CB.GIROBatchList_GroupNo',
    N'CB.GIROBatchList_ReferenceNo',
    N'CB.GIROBatchList_DocumentDate',
    N'CB.GIROBatchList_PurposeCode',
    N'CB.GIROBatchList_TotalDebtor',
    N'CB.GIROBatchList_TotalAmt',
    N'CB.GIROBatchList_CreatedBy',
    N'CB.GIROBatchList_CreateDate',
    N'CB.GIROBatchList_RecordStatus',
    N'CB.GIROBatchList_Filename',
    N'CB.GIROBatchList_TotalReceipt',
    N'CB.GIROBatchList_BankAccountID',
    N'CB.GIROBatchList_RecordType',
    N'CB.GIROBatchList_CreateUserID',
    N'CB.GIROBatchList_ModifyDate',
    N'Sys_Base_Name_CB.GIROBatchList',
    N'Sys_Base_Desc_CB.GIROBatchList',
    N'Sys_List_Name_CB.GIROBatchList_-1',
    N'Sys_List_Title_CB.GIROBatchList_-1',
    N'Sys_List_Name_CB.GIROBatchList_1',
    N'Sys_List_Title_CB.GIROBatchList_1',
    N'MnuClass_CB.GIROBatchList',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchListing',
    N'mcorp-15-07_CB.GIROBatchList_Import',
    N'mcorp-15-07_CB.GIROBatchList_Verify',
    N'mcorp-15-07_CB.GIROBatchList_Reset',
    N'mcorp-15-07_CB.GIROBatchList_Close',
    N'CB.GIROBatchList_Title',
    N'CB.GIROBatch_SelectOneBatch',
    N'CB.GIROBatch_ViewOnly',
    N'CB.GIROBatch_NotFound',
    N'CB.GIROBatch_NotExported',
    N'CB.GIROBatch_ResetConfirm',
    N'CB.GIROBatch_ResetSuccess',
    N'CB.GIROBatch_ReceiptNotExported');
END
-- obsolete labels (renamed to the doc names: TotalDebtor, CreatedBy, CreateDate)
DELETE FROM CF_String WHERE StringCode IN (N'CB.GIROBatchList_TotalTrx', N'CB.GIROBatchList_GeneratedBy', N'CB.GIROBatchList_FileCreationDate');
-- obsolete since doc v01.01 (Complete (All Success) replaced by Verify -> Pre-Check -> Confirm, script 11)
DELETE FROM CF_String WHERE StringCode IN (N'mcorp-15-07_CB.GIROBatchList_CompleteAll', N'CB.GIROBatch_CompleteConfirm', N'CB.GIROBatch_CompleteSuccess',
    N'CB.GIROBatch_CompleteBeforePaymentDate', N'CB.GIROBatch_ImportNotReady');

-- field labels (Field + Help)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CBReceiptGroupID', N'Batch ID', N'Batch ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CBReceiptGroupID', N'Batch ID', N'Batch ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_BankName', N'Bank Name', N'Bank Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_BankName', N'Bank Name', N'Bank Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_ACNo', N'Account No', N'Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_ACNo', N'Account No', N'Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_GroupNo', N'GIRO Batch No', N'GIRO Batch No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_GroupNo', N'GIRO Batch No', N'GIRO Batch No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_PurposeCode', N'Purpose Code', N'Purpose Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_PurposeCode', N'Purpose Code', N'Purpose Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_TotalDebtor', N'Total No Debtor', N'Total No Debtor', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_TotalDebtor', N'Total No Debtor', N'Total No Debtor', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CreatedBy', N'Created By', N'Created By', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CreatedBy', N'Created By', N'Created By', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CreateDate', N'Create Date', N'Create Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CreateDate', N'Create Date', N'Create Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_Filename', N'File Name', N'File Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_Filename', N'File Name', N'File Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_TotalReceipt', N'Total No Receipt', N'Total No Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_TotalReceipt', N'Total No Receipt', N'Total No Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_RecordType', N'Record Type', N'Record Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_RecordType', N'Record Type', N'Record Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_CreateUserID', N'Create User ID', N'Create User ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_CreateUserID', N'Create User ID', N'Create User ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchList_ModifyDate', N'Modify Date', N'Modify Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchList_ModifyDate', N'Modify Date', N'Modify Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- names / buttons: StringType + RefTable copied from an equivalent existing string
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROBatchList', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROBatchList', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROBatchList_-1', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROBatchList_-1', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROBatchList_1', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROBatchList_1', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROBatchList', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_AC.ReceiptVerify_GIROBatchListing', N'GIRO Batch Listing', N'GIRO Batch Listing', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.Pay_Select' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchList_Import', N'Import (Reject)', N'Import (Reject)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchList_Verify', N'Import (Success)', N'Import (Success)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchList_Reset', N'Reset', N'Reset', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchList_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

-- messages used in code (Strings.GetString)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatchList_Title', N'GIRO Batch Reset / Import', N'GIRO Batch Reset / Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_SelectOneBatch', N'Please tick one batch only.', N'Please tick one batch only.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ViewOnly', N'GIRO Batch {0} is {1} (view only). Only an Exported batch can be processed.', N'GIRO Batch {0} is {1} (view only). Only an Exported batch can be processed.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NotFound', N'The GIRO batch is not found.', N'The GIRO batch is not found.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NotExported', N'GIRO Batch {0} is {1}. Only an Exported batch can be processed.', N'GIRO Batch {0} is {1}. Only an Exported batch can be processed.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ResetConfirm', N'Reset this GIRO batch? The batch will be cancelled and its receipts will go back to Generated (the exported file is kept).', N'Reset this GIRO batch? The batch will be cancelled and its receipts will go back to Generated (the exported file is kept).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ResetSuccess', N'GIRO Batch {0} has been reset: {1} receipt(s) back to Generated.', N'GIRO Batch {0} has been reset: {1} receipt(s) back to Generated.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ReceiptNotExported', N'These receipts of the batch are no longer Active / Exported, please check:', N'These receipts of the batch are no longer Active / Exported, please check:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- Check
SELECT N'Sys_Base' AS Tbl, COUNT(*) AS Cnt FROM Sys_Base WHERE BseNo = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_BaseDt', COUNT(*) FROM Sys_BaseDt WHERE BdtBseNo = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_List', COUNT(*) FROM Sys_List WHERE LstNo = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_Filter', COUNT(*) FROM Sys_Filter WHERE FltBseNo = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_ContextMenuClass', COUNT(*) FROM Sys_ContextMenuClass WHERE MnuClass = N'CB.GIROBatchList'
UNION ALL SELECT N'Sys_ContextMenu', COUNT(*) FROM Sys_ContextMenu WHERE (MnuClass = N'CB.GIROBatchList' AND MnuNo = N'mcorp-15-07') OR (ContextMnuNo = N'GIROBatchListing' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07')
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (
    N'CB.GIROBatchList_CBReceiptGroupID',
    N'CB.GIROBatchList_CompanyID',
    N'CB.GIROBatchList_BankName',
    N'CB.GIROBatchList_ACNo',
    N'CB.GIROBatchList_CurrencyID',
    N'CB.GIROBatchList_Currency',
    N'CB.GIROBatchList_GroupNo',
    N'CB.GIROBatchList_ReferenceNo',
    N'CB.GIROBatchList_DocumentDate',
    N'CB.GIROBatchList_PurposeCode',
    N'CB.GIROBatchList_TotalDebtor',
    N'CB.GIROBatchList_TotalAmt',
    N'CB.GIROBatchList_CreatedBy',
    N'CB.GIROBatchList_CreateDate',
    N'CB.GIROBatchList_RecordStatus',
    N'CB.GIROBatchList_Filename',
    N'CB.GIROBatchList_TotalReceipt',
    N'CB.GIROBatchList_BankAccountID',
    N'CB.GIROBatchList_RecordType',
    N'CB.GIROBatchList_CreateUserID',
    N'CB.GIROBatchList_ModifyDate',
    N'Sys_Base_Name_CB.GIROBatchList',
    N'Sys_Base_Desc_CB.GIROBatchList',
    N'Sys_List_Name_CB.GIROBatchList_-1',
    N'Sys_List_Title_CB.GIROBatchList_-1',
    N'Sys_List_Name_CB.GIROBatchList_1',
    N'Sys_List_Title_CB.GIROBatchList_1',
    N'MnuClass_CB.GIROBatchList',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchListing',
    N'mcorp-15-07_CB.GIROBatchList_Import',
    N'mcorp-15-07_CB.GIROBatchList_Verify',
    N'mcorp-15-07_CB.GIROBatchList_Reset',
    N'mcorp-15-07_CB.GIROBatchList_Close',
    N'CB.GIROBatchList_Title',
    N'CB.GIROBatch_SelectOneBatch',
    N'CB.GIROBatch_ViewOnly',
    N'CB.GIROBatch_NotFound',
    N'CB.GIROBatch_NotExported',
    N'CB.GIROBatch_ResetConfirm',
    N'CB.GIROBatch_ResetSuccess',
    N'CB.GIROBatch_ReceiptNotExported');
-- expected: Sys_Base 1, Sys_BaseDt 21, Sys_List 2, Sys_ListDt 26, Sys_Filter 8, Sys_ContextMenuClass 1, Sys_ContextMenu 5, CF_String 62
