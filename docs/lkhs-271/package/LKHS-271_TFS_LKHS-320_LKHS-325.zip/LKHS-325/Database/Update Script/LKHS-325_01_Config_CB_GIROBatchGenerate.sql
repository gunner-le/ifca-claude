-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - popup GIRO Batch Generation
-- Script 08: Sys_ framework config + strings
--   Header  : BseNo / TabNo / MnuClass CB.GIROBatchGenerate  (SysTabEdit)
--   Detail  : BseNo / LstNo CB.GIROBatchDetail  (SysList2 in iframe, checkbox = receipts of the batch)
--   Container CB.GIROBatchGen / card CB.GIROBatchCard
--   Collection Verification (mcorp-15-07 / AC.ReceiptVerify): new toolbar button GIROBatchGenerate (only this row is deleted / inserted)
-- Re-runnable: each block deletes existing rows then inserts again.
-- Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------

-- Sys_Base
IF EXISTS (SELECT TOP 1 1 FROM Sys_Base WITH (NOLOCK) WHERE BseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail'))
BEGIN
    DELETE FROM Sys_Base WHERE BseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail');
END

INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROBatchGenerate', N'GIRO Batch Generation', N'Sys_Base_Name_CB.GIROBatchGenerate', N'View_CB_ReceiptGroupGenerate', N'CB_ReceiptGroup', N'GIRO Batch Generation', N'Sys_Base_Desc_CB.GIROBatchGenerate', N'CBReceiptGroupID', NULL, NULL, NULL);
INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROBatchDetail', N'GIRO Batch Receipt', N'Sys_Base_Name_CB.GIROBatchDetail', N'View_CB_Receipt_GIRO', N'CB_Receipt', N'GIRO Batch Receipt', N'Sys_Base_Desc_CB.GIROBatchDetail', N'CBReceiptID', NULL, NULL, NULL);

-- Sys_BaseDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail'))
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail');
END

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'GiroBankStringCode', N'Bank', N'Bank', N'CB.GIROBatchGenerate_GiroBankStringCode', N'CB.GIROBatchGenerate_GiroBankStringCode', 150, N'L', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 1, N'PayMethod', N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'GiroBank', 1, N'1', N'1', NULL, NULL, N'CB_ReceiptGroup', N'BankAccountID', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'ACNo', N'Account No.', N'Account No.', N'CB.GIROBatchGenerate_ACNo', N'CB.GIROBatchGenerate_ACNo', 50, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 2, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'Currency', N'Currency', N'Currency', N'CB.GIROBatchGenerate_Currency', N'CB.GIROBatchGenerate_Currency', 40, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 3, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'PurposeCodeStringCode', N'Purpose of Payment', N'Purpose of Payment', N'CB.GIROBatchGenerate_PurposeCodeStringCode', N'CB.GIROBatchGenerate_PurposeCodeStringCode', 150, N'L', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 4, N'PayMethod', N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'PurposeCode', 1, N'1', N'1', NULL, NULL, N'CB_ReceiptGroup', N'PurposeCode', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'ReferenceNo', N'Reference No', N'Reference No', N'CB.GIROBatchGenerate_ReferenceNo', N'CB.GIROBatchGenerate_ReferenceNo', 35, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, N'1', N'1', NULL, NULL, N'CB_ReceiptGroup', N'ReferenceNo', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'DocumentDate', N'Payment Date', N'Payment Date', N'CB.GIROBatchGenerate_DocumentDate', N'CB.GIROBatchGenerate_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 6, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 80, NULL, 1, N'1', N'1', NULL, NULL, N'CB_ReceiptGroup', N'DocumentDate', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'DocumentCount', N'No. of Receipts', N'No. of Receipts', N'CB.GIROBatchGenerate_DocumentCount', N'CB.GIROBatchGenerate_DocumentCount', 8, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 7, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'TotalAmt', N'Total Amount', N'Total Amount', N'CB.GIROBatchGenerate_TotalAmt', N'CB.GIROBatchGenerate_TotalAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 8, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'CBReceiptGroupID', N'Batch ID', N'Batch ID', N'CB.GIROBatchGenerate_CBReceiptGroupID', N'CB.GIROBatchGenerate_CBReceiptGroupID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 20, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROBatchGenerate_CompanyID', N'CB.GIROBatchGenerate_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 21, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, N'CB_ReceiptGroup', N'CompanyID', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'GroupNo', N'GIRO Batch', N'GIRO Batch', N'CB.GIROBatchGenerate_GroupNo', N'CB.GIROBatchGenerate_GroupNo', 50, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 22, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'BankAccountID', N'Bank Account ID', N'Bank Account ID', N'CB.GIROBatchGenerate_BankAccountID', N'CB.GIROBatchGenerate_BankAccountID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 23, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROBatchGenerate_CurrencyID', N'CB.GIROBatchGenerate_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 24, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'PurposeCode', N'Purpose Code', N'Purpose Code', N'CB.GIROBatchGenerate_PurposeCode', N'CB.GIROBatchGenerate_PurposeCode', 20, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 25, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchGenerate', N'RecordStatus', N'Status', N'Status', N'CB.GIROBatchGenerate_RecordStatus', N'CB.GIROBatchGenerate_RecordStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 26, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'CBReceiptID', N'Receipt ID', N'Receipt ID', N'CB.GIROBatchDetail_CBReceiptID', N'CB.GIROBatchDetail_CBReceiptID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROBatchDetail_CompanyID', N'CB.GIROBatchDetail_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'BankAccountID', N'Bank Account ID', N'Bank Account ID', N'CB.GIROBatchDetail_BankAccountID', N'CB.GIROBatchDetail_BankAccountID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROBatchDetail_CurrencyID', N'CB.GIROBatchDetail_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'Module', N'Module', N'Module', N'CB.GIROBatchDetail_Module', N'CB.GIROBatchDetail_Module', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'ReceiptType', N'Receipt Type', N'Receipt Type', N'CB.GIROBatchDetail_ReceiptType', N'CB.GIROBatchDetail_ReceiptType', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'DebtorID', N'Debtor ID', N'Debtor ID', N'CB.GIROBatchDetail_DebtorID', N'CB.GIROBatchDetail_DebtorID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'DebtorAccount', N'Debtor Account', N'Debtor Account', N'CB.GIROBatchDetail_DebtorAccount', N'CB.GIROBatchDetail_DebtorAccount', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'DebtorName', N'Debtor Name', N'Debtor Name', N'CB.GIROBatchDetail_DebtorName', N'CB.GIROBatchDetail_DebtorName', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'DocumentNo', N'Document No', N'Document No', N'CB.GIROBatchDetail_DocumentNo', N'CB.GIROBatchDetail_DocumentNo', 60, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'DocumentDate', N'Document Date', N'Document Date', N'CB.GIROBatchDetail_DocumentDate', N'CB.GIROBatchDetail_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'ReferenceNo', N'Reference No', N'Reference No', N'CB.GIROBatchDetail_ReferenceNo', N'CB.GIROBatchDetail_ReferenceNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'Currency', N'Currency', N'Currency', N'CB.GIROBatchDetail_Currency', N'CB.GIROBatchDetail_Currency', 40, N'L2', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'ReceiptAmt', N'Receipt Amount', N'Receipt Amount', N'CB.GIROBatchDetail_ReceiptAmt', N'CB.GIROBatchDetail_ReceiptAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'GiroAccountNo', N'GIRO Account No', N'GIRO Account No', N'CB.GIROBatchDetail_GiroAccountNo', N'CB.GIROBatchDetail_GiroAccountNo', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'SwiftCode', N'SWIFT Code', N'SWIFT Code', N'CB.GIROBatchDetail_SwiftCode', N'CB.GIROBatchDetail_SwiftCode', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'IdentityNo', N'Identity No', N'Identity No', N'CB.GIROBatchDetail_IdentityNo', N'CB.GIROBatchDetail_IdentityNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'GIRORecordStatus', N'GIRO Status', N'GIRO Status', N'CB.GIROBatchDetail_GIRORecordStatus', N'CB.GIROBatchDetail_GIRORecordStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'GroupNo', N'GIRO Batch', N'GIRO Batch', N'CB.GIROBatchDetail_GroupNo', N'CB.GIROBatchDetail_GroupNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROBatchDetail', N'RecordStatus', N'Status', N'Status', N'CB.GIROBatchDetail_RecordStatus', N'CB.GIROBatchDetail_RecordStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

-- Sys_Tab
IF EXISTS (SELECT TOP 1 1 FROM Sys_Tab WITH (NOLOCK) WHERE TabNo = N'CB.GIROBatchGenerate')
BEGIN
    DELETE FROM Sys_Tab WHERE TabNo = N'CB.GIROBatchGenerate';
END

INSERT INTO Sys_Tab ([TabNo], [TabName], [TabBseNo], [TabNameStringCode])
VALUES (N'CB.GIROBatchGenerate', N'GIRO Batch', N'CB.GIROBatchGenerate', N'Sys_Tab_Name_CB.GIROBatchGenerate');

-- Sys_TabClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabClass WITH (NOLOCK) WHERE TcsTabNo = N'CB.GIROBatchGenerate')
BEGIN
    DELETE FROM Sys_TabClass WHERE TcsTabNo = N'CB.GIROBatchGenerate';
END

INSERT INTO Sys_TabClass ([TcsTabNo], [TcsNo], [TcsName], [TcsNameEN], [TcsNameStringCode], [TcsClass], [TcsListNum])
VALUES (N'CB.GIROBatchGenerate', N'GIRO0002', N'GIRO Batch Generation', N'GIRO Batch Generation', N'TabClass_CB.GIROBatchGenerate_GIRO0002', NULL, 2);

-- Sys_TabDt (2 fields per row)
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabDt WITH (NOLOCK) WHERE TdtTabNo = N'CB.GIROBatchGenerate')
BEGIN
    DELETE FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROBatchGenerate';
END

INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'GiroBankStringCode', N'Bank', N'CB.GIROBatchGenerate_GiroBankStringCode', N'CB.GIROBatchGenerate_GiroBankStringCode', N'1', 1, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'ACNo', N'Account No.', N'CB.GIROBatchGenerate_ACNo', N'CB.GIROBatchGenerate_ACNo', NULL, 2, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'Currency', N'Currency', N'CB.GIROBatchGenerate_Currency', N'CB.GIROBatchGenerate_Currency', NULL, 3, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'PurposeCodeStringCode', N'Purpose of Payment', N'CB.GIROBatchGenerate_PurposeCodeStringCode', N'CB.GIROBatchGenerate_PurposeCodeStringCode', N'1', 4, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'ReferenceNo', N'Reference No', N'CB.GIROBatchGenerate_ReferenceNo', N'CB.GIROBatchGenerate_ReferenceNo', N'1', 5, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'DocumentDate', N'Payment Date', N'CB.GIROBatchGenerate_DocumentDate', N'CB.GIROBatchGenerate_DocumentDate', N'1', 6, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'DocumentCount', N'No. of Receipts', N'CB.GIROBatchGenerate_DocumentCount', N'CB.GIROBatchGenerate_DocumentCount', NULL, 7, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROBatchGenerate', N'CB.GIROBatchGenerate', N'GIRO0002', N'TotalAmt', N'Total Amount', N'CB.GIROBatchGenerate_TotalAmt', N'CB.GIROBatchGenerate_TotalAmt', NULL, 8, NULL, NULL, NULL, NULL);

-- Sys_TabCard (receipt grid container)
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabCard WITH (NOLOCK) WHERE TcdTabNo = N'CB.GIROBatchGen')
BEGIN
    DELETE FROM Sys_TabCard WHERE TcdTabNo = N'CB.GIROBatchGen';
END

INSERT INTO Sys_TabCard ([TcdTabNo], [TcdCardNo], [TcdStringCode], [TcdScript], [TcdOrder], [MnuClass], [MnuNo])
VALUES (N'CB.GIROBatchGen', N'CB.GIROBatchCard', N'CB.GIROBatchCard_Title', NULL, 1, N'CB.GIROBatchCard', N'mcorp-15-07');

-- Sys_List (receipt grid)
IF EXISTS (SELECT TOP 1 1 FROM Sys_List WITH (NOLOCK) WHERE LstNo = N'CB.GIROBatchDetail')
BEGIN
    DELETE FROM Sys_List WHERE LstNo = N'CB.GIROBatchDetail';
END

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROBatchDetail', -1, N'GIRO Batch Receipt', N'Sys_List_Name_CB.GIROBatchDetail_-1', N'GIRO Batch Receipt', N'Sys_List_Title_CB.GIROBatchDetail_-1', N'CB.GIROBatchDetail', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROBatchDetail', 1, N'GIRO Batch Receipt', N'Sys_List_Name_CB.GIROBatchDetail_1', N'GIRO Batch Receipt', N'Sys_List_Title_CB.GIROBatchDetail_1', N'CB.GIROBatchDetail', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);

-- Sys_ListDt (receipt grid)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo = N'CB.GIROBatchDetail')
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROBatchDetail';
END

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'Module', N'Module', NULL, N'CB.GIROBatchDetail_Module', N'CB.GIROBatchDetail_Module', 50, 140, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROBatchDetail_DebtorAccount', N'CB.GIROBatchDetail_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROBatchDetail_DebtorName', N'CB.GIROBatchDetail_DebtorName', 200, 220, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'DocumentNo', N'Document No', NULL, N'CB.GIROBatchDetail_DocumentNo', N'CB.GIROBatchDetail_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROBatchDetail_DocumentDate', N'CB.GIROBatchDetail_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'ReferenceNo', N'Reference No', NULL, N'CB.GIROBatchDetail_ReferenceNo', N'CB.GIROBatchDetail_ReferenceNo', 50, 110, N'left', NULL, N'S', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'Currency', N'Currency', NULL, N'CB.GIROBatchDetail_Currency', N'CB.GIROBatchDetail_Currency', 40, 50, N'left', NULL, N'L2', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', -1, N'ReceiptAmt', N'Receipt Amount', NULL, N'CB.GIROBatchDetail_ReceiptAmt', N'CB.GIROBatchDetail_ReceiptAmt', 13, 100, N'right', NULL, N'FM', N'1', 8, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'Module', N'Module', NULL, N'CB.GIROBatchDetail_Module', N'CB.GIROBatchDetail_Module', 50, 140, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROBatchDetail_DebtorAccount', N'CB.GIROBatchDetail_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROBatchDetail_DebtorName', N'CB.GIROBatchDetail_DebtorName', 200, 220, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'DocumentNo', N'Document No', NULL, N'CB.GIROBatchDetail_DocumentNo', N'CB.GIROBatchDetail_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROBatchDetail_DocumentDate', N'CB.GIROBatchDetail_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'ReferenceNo', N'Reference No', NULL, N'CB.GIROBatchDetail_ReferenceNo', N'CB.GIROBatchDetail_ReferenceNo', 50, 110, N'left', NULL, N'S', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'Currency', N'Currency', NULL, N'CB.GIROBatchDetail_Currency', N'CB.GIROBatchDetail_Currency', 40, 50, N'left', NULL, N'L2', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROBatchDetail', 1, N'ReceiptAmt', N'Receipt Amount', NULL, N'CB.GIROBatchDetail_ReceiptAmt', N'CB.GIROBatchDetail_ReceiptAmt', 13, 100, N'right', NULL, N'FM', N'1', 8, N'1', NULL, NULL, NULL);

-- Sys_ContextMenuClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenuClass WITH (NOLOCK) WHERE MnuClass IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchCard'))
BEGIN
    DELETE FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchCard');
END

INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROBatchGenerate', N'MnuClass_CB.GIROBatchGenerate');
INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROBatchCard', N'MnuClass_CB.GIROBatchCard');

-- Sys_ContextMenu (Save / Close on popup toolbar)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'CB.GIROBatchGenerate' AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE MnuClass = N'CB.GIROBatchGenerate' AND MnuNo = N'mcorp-15-07';
END

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Save', N'CB.GIROBatchGenerate', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchGenerate_Save', N' if(!f_SaveData()) return ', NULL, 1, N'N', N'N', N'btn_save.gif', NULL, 2);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROBatchGenerate', N'mcorp-15-07', N'mcorp-15-07_CB.GIROBatchGenerate_Close', N'f_Close()', NULL, 1, N'N', N'N', N'btn_exit.gif', NULL, 3);

-- Sys_ContextMenu: Collection Verification toolbar - new button 'GIROBatchGenerate' (other buttons untouched; SeqNo = last + 1)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE ContextMnuNo = N'GIROBatchGenerate' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE ContextMnuNo = N'GIROBatchGenerate' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';
END
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
SELECT N'GIROBatchGenerate', N'AC.ReceiptVerify', N'mcorp-15-07', N'mcorp-15-07_AC.ReceiptVerify_GIROBatchGenerate', N'f_GIROBatchGenerate()', NULL, 1, N'N', N'N', N'btn_selectall.gif', NULL, ISNULL(MAX(SeqNo), 0) + 1
FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';


-- CF_String
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (
    N'CB.GIROBatchGenerate_GiroBankStringCode',
    N'CB.GIROBatchGenerate_ACNo',
    N'CB.GIROBatchGenerate_Currency',
    N'CB.GIROBatchGenerate_PurposeCodeStringCode',
    N'CB.GIROBatchGenerate_ReferenceNo',
    N'CB.GIROBatchGenerate_DocumentDate',
    N'CB.GIROBatchGenerate_DocumentCount',
    N'CB.GIROBatchGenerate_TotalAmt',
    N'CB.GIROBatchGenerate_CBReceiptGroupID',
    N'CB.GIROBatchGenerate_CompanyID',
    N'CB.GIROBatchGenerate_GroupNo',
    N'CB.GIROBatchGenerate_BankAccountID',
    N'CB.GIROBatchGenerate_CurrencyID',
    N'CB.GIROBatchGenerate_PurposeCode',
    N'CB.GIROBatchGenerate_RecordStatus',
    N'CB.GIROBatchDetail_CBReceiptID',
    N'CB.GIROBatchDetail_CompanyID',
    N'CB.GIROBatchDetail_BankAccountID',
    N'CB.GIROBatchDetail_CurrencyID',
    N'CB.GIROBatchDetail_Module',
    N'CB.GIROBatchDetail_ReceiptType',
    N'CB.GIROBatchDetail_DebtorID',
    N'CB.GIROBatchDetail_DebtorAccount',
    N'CB.GIROBatchDetail_DebtorName',
    N'CB.GIROBatchDetail_DocumentNo',
    N'CB.GIROBatchDetail_DocumentDate',
    N'CB.GIROBatchDetail_ReferenceNo',
    N'CB.GIROBatchDetail_Currency',
    N'CB.GIROBatchDetail_ReceiptAmt',
    N'CB.GIROBatchDetail_GiroAccountNo',
    N'CB.GIROBatchDetail_SwiftCode',
    N'CB.GIROBatchDetail_IdentityNo',
    N'CB.GIROBatchDetail_GIRORecordStatus',
    N'CB.GIROBatchDetail_GroupNo',
    N'CB.GIROBatchDetail_RecordStatus',
    N'Sys_Base_Name_CB.GIROBatchGenerate',
    N'Sys_Base_Desc_CB.GIROBatchGenerate',
    N'Sys_Base_Name_CB.GIROBatchDetail',
    N'Sys_Base_Desc_CB.GIROBatchDetail',
    N'Sys_List_Name_CB.GIROBatchDetail_-1',
    N'Sys_List_Title_CB.GIROBatchDetail_-1',
    N'Sys_List_Name_CB.GIROBatchDetail_1',
    N'Sys_List_Title_CB.GIROBatchDetail_1',
    N'Sys_Tab_Name_CB.GIROBatchGenerate',
    N'TabClass_CB.GIROBatchGenerate_GIRO0002',
    N'CB.GIROBatchCard_Title',
    N'MnuClass_CB.GIROBatchGenerate',
    N'MnuClass_CB.GIROBatchCard',
    N'mcorp-15-07_CB.GIROBatchGenerate_Save',
    N'mcorp-15-07_CB.GIROBatchGenerate_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchGenerate',
    N'CB.GIROBatch_Title',
    N'CB.GIROBatch_SelectCompany',
    N'CB.GIROBatch_NoGIROBank',
    N'CB.GIROBatch_BankRequired',
    N'CB.GIROBatch_PurposeRequired',
    N'CB.GIROBatch_NoReceipt',
    N'CB.GIROBatch_BankNotSetup',
    N'CB.GIROBatch_ExportPathRequired',
    N'CB.GIROBatch_NoNumberStructure',
    N'CB.GIROBatch_ExportFailed',
    N'CB.GIROBatch_ReceiptChanged',
    N'CB.GIROBatch_SaveSuccess',
    N'CB.GIRO_VerifyBlocked'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (
    N'CB.GIROBatchGenerate_GiroBankStringCode',
    N'CB.GIROBatchGenerate_ACNo',
    N'CB.GIROBatchGenerate_Currency',
    N'CB.GIROBatchGenerate_PurposeCodeStringCode',
    N'CB.GIROBatchGenerate_ReferenceNo',
    N'CB.GIROBatchGenerate_DocumentDate',
    N'CB.GIROBatchGenerate_DocumentCount',
    N'CB.GIROBatchGenerate_TotalAmt',
    N'CB.GIROBatchGenerate_CBReceiptGroupID',
    N'CB.GIROBatchGenerate_CompanyID',
    N'CB.GIROBatchGenerate_GroupNo',
    N'CB.GIROBatchGenerate_BankAccountID',
    N'CB.GIROBatchGenerate_CurrencyID',
    N'CB.GIROBatchGenerate_PurposeCode',
    N'CB.GIROBatchGenerate_RecordStatus',
    N'CB.GIROBatchDetail_CBReceiptID',
    N'CB.GIROBatchDetail_CompanyID',
    N'CB.GIROBatchDetail_BankAccountID',
    N'CB.GIROBatchDetail_CurrencyID',
    N'CB.GIROBatchDetail_Module',
    N'CB.GIROBatchDetail_ReceiptType',
    N'CB.GIROBatchDetail_DebtorID',
    N'CB.GIROBatchDetail_DebtorAccount',
    N'CB.GIROBatchDetail_DebtorName',
    N'CB.GIROBatchDetail_DocumentNo',
    N'CB.GIROBatchDetail_DocumentDate',
    N'CB.GIROBatchDetail_ReferenceNo',
    N'CB.GIROBatchDetail_Currency',
    N'CB.GIROBatchDetail_ReceiptAmt',
    N'CB.GIROBatchDetail_GiroAccountNo',
    N'CB.GIROBatchDetail_SwiftCode',
    N'CB.GIROBatchDetail_IdentityNo',
    N'CB.GIROBatchDetail_GIRORecordStatus',
    N'CB.GIROBatchDetail_GroupNo',
    N'CB.GIROBatchDetail_RecordStatus',
    N'Sys_Base_Name_CB.GIROBatchGenerate',
    N'Sys_Base_Desc_CB.GIROBatchGenerate',
    N'Sys_Base_Name_CB.GIROBatchDetail',
    N'Sys_Base_Desc_CB.GIROBatchDetail',
    N'Sys_List_Name_CB.GIROBatchDetail_-1',
    N'Sys_List_Title_CB.GIROBatchDetail_-1',
    N'Sys_List_Name_CB.GIROBatchDetail_1',
    N'Sys_List_Title_CB.GIROBatchDetail_1',
    N'Sys_Tab_Name_CB.GIROBatchGenerate',
    N'TabClass_CB.GIROBatchGenerate_GIRO0002',
    N'CB.GIROBatchCard_Title',
    N'MnuClass_CB.GIROBatchGenerate',
    N'MnuClass_CB.GIROBatchCard',
    N'mcorp-15-07_CB.GIROBatchGenerate_Save',
    N'mcorp-15-07_CB.GIROBatchGenerate_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchGenerate',
    N'CB.GIROBatch_Title',
    N'CB.GIROBatch_SelectCompany',
    N'CB.GIROBatch_NoGIROBank',
    N'CB.GIROBatch_BankRequired',
    N'CB.GIROBatch_PurposeRequired',
    N'CB.GIROBatch_NoReceipt',
    N'CB.GIROBatch_BankNotSetup',
    N'CB.GIROBatch_ExportPathRequired',
    N'CB.GIROBatch_NoNumberStructure',
    N'CB.GIROBatch_ExportFailed',
    N'CB.GIROBatch_ReceiptChanged',
    N'CB.GIROBatch_SaveSuccess',
    N'CB.GIRO_VerifyBlocked');
END

-- field labels (Field + Help)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_GiroBankStringCode', N'Bank', N'Bank', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_GiroBankStringCode', N'Bank', N'Bank', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_ACNo', N'Account No.', N'Account No.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_ACNo', N'Account No.', N'Account No.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_PurposeCodeStringCode', N'Purpose of Payment', N'Purpose of Payment', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_PurposeCodeStringCode', N'Purpose of Payment', N'Purpose of Payment', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_DocumentCount', N'No. of Receipts', N'No. of Receipts', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_DocumentCount', N'No. of Receipts', N'No. of Receipts', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CBReceiptGroupID', N'Batch ID', N'Batch ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CBReceiptGroupID', N'Batch ID', N'Batch ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_GroupNo', N'GIRO Batch', N'GIRO Batch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_GroupNo', N'GIRO Batch', N'GIRO Batch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_PurposeCode', N'Purpose Code', N'Purpose Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_PurposeCode', N'Purpose Code', N'Purpose Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchGenerate_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchGenerate_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReceiptAmt', N'Receipt Amount', N'Receipt Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_ReceiptAmt', N'Receipt Amount', N'Receipt Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_SwiftCode', N'SWIFT Code', N'SWIFT Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_SwiftCode', N'SWIFT Code', N'SWIFT Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_IdentityNo', N'Identity No', N'Identity No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_IdentityNo', N'Identity No', N'Identity No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_GIRORecordStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_GIRORecordStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_GroupNo', N'GIRO Batch', N'GIRO Batch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_GroupNo', N'GIRO Batch', N'GIRO Batch', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROBatchDetail_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROBatchDetail_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- names / buttons: StringType + RefTable copied from the equivalent Generate Payment string
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROBatchGenerate', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROBatchGenerate', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROBatchDetail', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROBatchDetail', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROBatchDetail_-1', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROBatchDetail_-1', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROBatchDetail_1', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROBatchDetail_1', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Tab_Name_CB.GIROBatchGenerate', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Tab_Name_AC.PaymentConfirm' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'TabClass_CB.GIROBatchGenerate_GIRO0002', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'TabClass_AC.PaymentConfirm_AC00073' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'CB.GIROBatchCard_Title', N'Receipt Detail', N'Receipt Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'AC.Pay_Title' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROBatchGenerate', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROBatchCard', N'GIRO Batch Receipt', N'GIRO Batch Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchGenerate_Save', N'Save', N'Save', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Save' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROBatchGenerate_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_AC.ReceiptVerify_GIROBatchGenerate', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.Pay_Select' ORDER BY [StringType];

-- messages used in code (Strings.GetString)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_Title', N'GIRO Batch Generation', N'GIRO Batch Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_SelectCompany', N'Please select a company first.', N'Please select a company first.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NoGIROBank', N'No GIRO bank is set up for this company (Company Structure).', N'No GIRO bank is set up for this company (Company Structure).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_BankRequired', N'Bank is required.', N'Bank is required.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_PurposeRequired', N'Purpose of Payment is required.', N'Purpose of Payment is required.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NoReceipt', N'Please tick at least one receipt.', N'Please tick at least one receipt.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_BankNotSetup', N'The selected bank is not an active GIRO bank of this company.', N'The selected bank is not an active GIRO bank of this company.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ExportPathRequired', N'AR Export Path of the GIRO bank is not set up (Company Structure).', N'AR Export Path of the GIRO bank is not set up (Company Structure).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NoNumberStructure', N'Number Structure {0} (GIRO Batch No) is not set up for this company. Please set it up: Serial only, length 5, padded 0 (DBS Batch ID 00001-99999).', N'Number Structure {0} (GIRO Batch No) is not set up for this company. Please set it up: Serial only, length 5, padded 0 (DBS Batch ID 00001-99999).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ExportFailed', N'Cannot write the GIRO file to {0}. Nothing has been saved.', N'Cannot write the GIRO file to {0}. Nothing has been saved.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ReceiptChanged', N'These receipts are no longer pending GIRO (changed by another user). Please reload and try again:', N'These receipts are no longer pending GIRO (changed by another user). Please reload and try again:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_SaveSuccess', N'GIRO Batch {0} created: {1} receipt(s), {2} line(s), total amount {3}.<br>File: {4}', N'GIRO Batch {0} created: {1} receipt(s), {2} line(s), total amount {3}.<br>File: {4}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_VerifyBlocked', N'GIRO receipts cannot be verified here, they are verified by Import GIRO Batch:', N'GIRO receipts cannot be verified here, they are verified by Import GIRO Batch:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- Check
SELECT N'Sys_Base' AS Tbl, COUNT(*) AS Cnt FROM Sys_Base WHERE BseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail')
UNION ALL SELECT N'Sys_BaseDt', COUNT(*) FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchDetail')
UNION ALL SELECT N'Sys_Tab', COUNT(*) FROM Sys_Tab WHERE TabNo = N'CB.GIROBatchGenerate'
UNION ALL SELECT N'Sys_TabClass', COUNT(*) FROM Sys_TabClass WHERE TcsTabNo = N'CB.GIROBatchGenerate'
UNION ALL SELECT N'Sys_TabDt', COUNT(*) FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROBatchGenerate'
UNION ALL SELECT N'Sys_TabCard', COUNT(*) FROM Sys_TabCard WHERE TcdTabNo = N'CB.GIROBatchGen'
UNION ALL SELECT N'Sys_List', COUNT(*) FROM Sys_List WHERE LstNo = N'CB.GIROBatchDetail'
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROBatchDetail'
UNION ALL SELECT N'Sys_ContextMenuClass', COUNT(*) FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROBatchGenerate', N'CB.GIROBatchCard')
UNION ALL SELECT N'Sys_ContextMenu', COUNT(*) FROM Sys_ContextMenu WHERE (MnuClass = N'CB.GIROBatchGenerate' AND MnuNo = N'mcorp-15-07') OR (ContextMnuNo = N'GIROBatchGenerate' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07')
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (
    N'CB.GIROBatchGenerate_GiroBankStringCode',
    N'CB.GIROBatchGenerate_ACNo',
    N'CB.GIROBatchGenerate_Currency',
    N'CB.GIROBatchGenerate_PurposeCodeStringCode',
    N'CB.GIROBatchGenerate_ReferenceNo',
    N'CB.GIROBatchGenerate_DocumentDate',
    N'CB.GIROBatchGenerate_DocumentCount',
    N'CB.GIROBatchGenerate_TotalAmt',
    N'CB.GIROBatchGenerate_CBReceiptGroupID',
    N'CB.GIROBatchGenerate_CompanyID',
    N'CB.GIROBatchGenerate_GroupNo',
    N'CB.GIROBatchGenerate_BankAccountID',
    N'CB.GIROBatchGenerate_CurrencyID',
    N'CB.GIROBatchGenerate_PurposeCode',
    N'CB.GIROBatchGenerate_RecordStatus',
    N'CB.GIROBatchDetail_CBReceiptID',
    N'CB.GIROBatchDetail_CompanyID',
    N'CB.GIROBatchDetail_BankAccountID',
    N'CB.GIROBatchDetail_CurrencyID',
    N'CB.GIROBatchDetail_Module',
    N'CB.GIROBatchDetail_ReceiptType',
    N'CB.GIROBatchDetail_DebtorID',
    N'CB.GIROBatchDetail_DebtorAccount',
    N'CB.GIROBatchDetail_DebtorName',
    N'CB.GIROBatchDetail_DocumentNo',
    N'CB.GIROBatchDetail_DocumentDate',
    N'CB.GIROBatchDetail_ReferenceNo',
    N'CB.GIROBatchDetail_Currency',
    N'CB.GIROBatchDetail_ReceiptAmt',
    N'CB.GIROBatchDetail_GiroAccountNo',
    N'CB.GIROBatchDetail_SwiftCode',
    N'CB.GIROBatchDetail_IdentityNo',
    N'CB.GIROBatchDetail_GIRORecordStatus',
    N'CB.GIROBatchDetail_GroupNo',
    N'CB.GIROBatchDetail_RecordStatus',
    N'Sys_Base_Name_CB.GIROBatchGenerate',
    N'Sys_Base_Desc_CB.GIROBatchGenerate',
    N'Sys_Base_Name_CB.GIROBatchDetail',
    N'Sys_Base_Desc_CB.GIROBatchDetail',
    N'Sys_List_Name_CB.GIROBatchDetail_-1',
    N'Sys_List_Title_CB.GIROBatchDetail_-1',
    N'Sys_List_Name_CB.GIROBatchDetail_1',
    N'Sys_List_Title_CB.GIROBatchDetail_1',
    N'Sys_Tab_Name_CB.GIROBatchGenerate',
    N'TabClass_CB.GIROBatchGenerate_GIRO0002',
    N'CB.GIROBatchCard_Title',
    N'MnuClass_CB.GIROBatchGenerate',
    N'MnuClass_CB.GIROBatchCard',
    N'mcorp-15-07_CB.GIROBatchGenerate_Save',
    N'mcorp-15-07_CB.GIROBatchGenerate_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROBatchGenerate',
    N'CB.GIROBatch_Title',
    N'CB.GIROBatch_SelectCompany',
    N'CB.GIROBatch_NoGIROBank',
    N'CB.GIROBatch_BankRequired',
    N'CB.GIROBatch_PurposeRequired',
    N'CB.GIROBatch_NoReceipt',
    N'CB.GIROBatch_BankNotSetup',
    N'CB.GIROBatch_ExportPathRequired',
    N'CB.GIROBatch_NoNumberStructure',
    N'CB.GIROBatch_ExportFailed',
    N'CB.GIROBatch_ReceiptChanged',
    N'CB.GIROBatch_SaveSuccess',
    N'CB.GIRO_VerifyBlocked');
-- expected: Sys_Base 2, Sys_BaseDt 35, Sys_Tab 1, Sys_TabClass 1, Sys_TabDt 8, Sys_TabCard 1, Sys_List 2, Sys_ListDt 16, Sys_ContextMenuClass 2, Sys_ContextMenu 3, CF_String 99
