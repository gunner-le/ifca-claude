-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - doc v01.01: Import / Verify of the GIRO Batch Listing
-- Script 11: Sys_ framework config + strings of 2 new popups
--   CB.GIROImportFile : Upload Screen (CashFlow/ARGIROBatchImport.aspx)   - grid Filename, buttons Select / Close
--   CB.GIROPreCheck : GIRO Batch Pre-Check Screen (CashFlow/ARGIROBatchPreCheck.aspx)
--         grid Document No / Debtor Name / Amount / GIRO Status (+ Return Reason), buttons Confirm / Close
--   + messages of Import / Verify / Confirm (GIROBatchService)
--   + Collection Verification button 'GIROCancel' (Stanley doc: Cancel = Cancel Receipt Action for Generated GIRO receipts)
-- Grid rows are built in code (file names / GIRO Status are not in a table): read table of the base = view used by the page.
-- Re-runnable: each block deletes existing rows then inserts again.
-- Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------

-- Sys_Base
IF EXISTS (SELECT TOP 1 1 FROM Sys_Base WITH (NOLOCK) WHERE BseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck'))
BEGIN
    DELETE FROM Sys_Base WHERE BseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck');
END

INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROImportFile', N'GIRO Batch Import', N'Sys_Base_Name_CB.GIROImportFile', N'View_CB_ReceiptGroup_GIRO', N'CB_ReceiptGroup', N'GIRO Batch Import', N'Sys_Base_Desc_CB.GIROImportFile', N'FileNo', NULL, NULL, NULL);
INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROPreCheck', N'GIRO Batch Pre-Check', N'Sys_Base_Name_CB.GIROPreCheck', N'View_CB_Receipt_GIRO', N'CB_Receipt', N'GIRO Batch Pre-Check', N'Sys_Base_Desc_CB.GIROPreCheck', N'CBReceiptID', NULL, NULL, NULL);

-- Sys_BaseDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck'))
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck');
END

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROImportFile', N'FileNo', N'File No', N'File No', N'CB.GIROImportFile_FileNo', N'CB.GIROImportFile_FileNo', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 1, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROImportFile', N'Filename', N'Filename', N'Filename', N'CB.GIROImportFile_Filename', N'CB.GIROImportFile_Filename', 260, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 2, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'CBReceiptID', N'Receipt ID', N'Receipt ID', N'CB.GIROPreCheck_CBReceiptID', N'CB.GIROPreCheck_CBReceiptID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 1, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'DocumentNo', N'Document No', N'Document No', N'CB.GIROPreCheck_DocumentNo', N'CB.GIROPreCheck_DocumentNo', 60, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 2, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'DebtorName', N'Debtor Name', N'Debtor Name', N'CB.GIROPreCheck_DebtorName', N'CB.GIROPreCheck_DebtorName', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 3, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'ReceiptAmt', N'Amount', N'Amount', N'CB.GIROPreCheck_ReceiptAmt', N'CB.GIROPreCheck_ReceiptAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 4, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'GIROStatus', N'GIRO Status', N'GIRO Status', N'CB.GIROPreCheck_GIROStatus', N'CB.GIROPreCheck_GIROStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'ReturnReason', N'Return Reason', N'Return Reason', N'CB.GIROPreCheck_ReturnReason', N'CB.GIROPreCheck_ReturnReason', 255, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 6, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'DebtorAccount', N'Debtor Account', N'Debtor Account', N'CB.GIROPreCheck_DebtorAccount', N'CB.GIROPreCheck_DebtorAccount', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 7, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROPreCheck', N'GiroAccountNo', N'GIRO Account No', N'GIRO Account No', N'CB.GIROPreCheck_GiroAccountNo', N'CB.GIROPreCheck_GiroAccountNo', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 8, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

-- Sys_List
IF EXISTS (SELECT TOP 1 1 FROM Sys_List WITH (NOLOCK) WHERE LstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck'))
BEGIN
    DELETE FROM Sys_List WHERE LstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck');
END

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROImportFile', -1, N'GIRO Batch Import', N'Sys_List_Name_CB.GIROImportFile_-1', N'GIRO Batch Import', N'Sys_List_Title_CB.GIROImportFile_-1', N'CB.GIROImportFile', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROImportFile', 1, N'GIRO Batch Import', N'Sys_List_Name_CB.GIROImportFile_1', N'GIRO Batch Import', N'Sys_List_Title_CB.GIROImportFile_1', N'CB.GIROImportFile', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROPreCheck', -1, N'GIRO Batch Pre-Check', N'Sys_List_Name_CB.GIROPreCheck_-1', N'GIRO Batch Pre-Check', N'Sys_List_Title_CB.GIROPreCheck_-1', N'CB.GIROPreCheck', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROPreCheck', 1, N'GIRO Batch Pre-Check', N'Sys_List_Name_CB.GIROPreCheck_1', N'GIRO Batch Pre-Check', N'Sys_List_Title_CB.GIROPreCheck_1', N'CB.GIROPreCheck', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);

-- Sys_ListDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck'))
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck');
END

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROImportFile', -1, N'Filename', N'Filename', NULL, N'CB.GIROImportFile_Filename', N'CB.GIROImportFile_Filename', 260, 450, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROImportFile', 1, N'Filename', N'Filename', NULL, N'CB.GIROImportFile_Filename', N'CB.GIROImportFile_Filename', 260, 450, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', -1, N'DocumentNo', N'Document No', NULL, N'CB.GIROPreCheck_DocumentNo', N'CB.GIROPreCheck_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', -1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROPreCheck_DebtorName', N'CB.GIROPreCheck_DebtorName', 200, 250, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', -1, N'ReceiptAmt', N'Amount', NULL, N'CB.GIROPreCheck_ReceiptAmt', N'CB.GIROPreCheck_ReceiptAmt', 13, 110, N'right', NULL, N'FM', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', -1, N'GIROStatus', N'GIRO Status', NULL, N'CB.GIROPreCheck_GIROStatus', N'CB.GIROPreCheck_GIROStatus', 20, 90, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', -1, N'ReturnReason', N'Return Reason', NULL, N'CB.GIROPreCheck_ReturnReason', N'CB.GIROPreCheck_ReturnReason', 255, 300, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', 1, N'DocumentNo', N'Document No', NULL, N'CB.GIROPreCheck_DocumentNo', N'CB.GIROPreCheck_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', 1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROPreCheck_DebtorName', N'CB.GIROPreCheck_DebtorName', 200, 250, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', 1, N'ReceiptAmt', N'Amount', NULL, N'CB.GIROPreCheck_ReceiptAmt', N'CB.GIROPreCheck_ReceiptAmt', 13, 110, N'right', NULL, N'FM', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', 1, N'GIROStatus', N'GIRO Status', NULL, N'CB.GIROPreCheck_GIROStatus', N'CB.GIROPreCheck_GIROStatus', 20, 90, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROPreCheck', 1, N'ReturnReason', N'Return Reason', NULL, N'CB.GIROPreCheck_ReturnReason', N'CB.GIROPreCheck_ReturnReason', 255, 300, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);

-- Sys_ContextMenuClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenuClass WITH (NOLOCK) WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck'))
BEGIN
    DELETE FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck');
END

INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROImportFile', N'MnuClass_CB.GIROImportFile');
INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROPreCheck', N'MnuClass_CB.GIROPreCheck');

-- Sys_ContextMenu (Upload: Select / Close - Pre-Check: Confirm / Close)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck') AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck') AND MnuNo = N'mcorp-15-07';
END

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Select', N'CB.GIROImportFile', N'mcorp-15-07', N'mcorp-15-07_CB.GIROImportFile_Select', N'f_SelectFile()', NULL, 1, N'N', N'N', NULL, NULL, 1);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROImportFile', N'mcorp-15-07', N'mcorp-15-07_CB.GIROImportFile_Close', N'f_Close()', NULL, 1, N'N', N'N', NULL, NULL, 2);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Confirm', N'CB.GIROPreCheck', N'mcorp-15-07', N'mcorp-15-07_CB.GIROPreCheck_Confirm', N'f_GIROPreCheckConfirm()', NULL, 1, N'N', N'N', NULL, NULL, 1);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROPreCheck', N'mcorp-15-07', N'mcorp-15-07_CB.GIROPreCheck_Close', N'f_Close()', NULL, 1, N'N', N'N', NULL, NULL, 2);

-- Sys_ContextMenu: Collection Verification toolbar - new button 'GIROCancel' (Stanley doc: Cancel; other buttons untouched; SeqNo = last + 1)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE ContextMnuNo = N'GIROCancel' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE ContextMnuNo = N'GIROCancel' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';
END
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
SELECT N'GIROCancel', N'AC.ReceiptVerify', N'mcorp-15-07', N'mcorp-15-07_AC.ReceiptVerify_GIROCancel', N'f_GIROCancel()', NULL, 1, N'N', N'N', N'btn_selectall.gif', NULL, ISNULL(MAX(SeqNo), 0) + 1
FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07';


-- CF_String
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (
    N'CB.GIROImportFile_FileNo',
    N'CB.GIROImportFile_Filename',
    N'CB.GIROPreCheck_CBReceiptID',
    N'CB.GIROPreCheck_DocumentNo',
    N'CB.GIROPreCheck_DebtorName',
    N'CB.GIROPreCheck_ReceiptAmt',
    N'CB.GIROPreCheck_GIROStatus',
    N'CB.GIROPreCheck_ReturnReason',
    N'CB.GIROPreCheck_DebtorAccount',
    N'CB.GIROPreCheck_GiroAccountNo',
    N'Sys_Base_Name_CB.GIROImportFile',
    N'Sys_Base_Desc_CB.GIROImportFile',
    N'Sys_List_Name_CB.GIROImportFile_-1',
    N'Sys_List_Title_CB.GIROImportFile_-1',
    N'Sys_List_Name_CB.GIROImportFile_1',
    N'Sys_List_Title_CB.GIROImportFile_1',
    N'MnuClass_CB.GIROImportFile',
    N'mcorp-15-07_CB.GIROImportFile_Select',
    N'mcorp-15-07_CB.GIROImportFile_Close',
    N'Sys_Base_Name_CB.GIROPreCheck',
    N'Sys_Base_Desc_CB.GIROPreCheck',
    N'Sys_List_Name_CB.GIROPreCheck_-1',
    N'Sys_List_Title_CB.GIROPreCheck_-1',
    N'Sys_List_Name_CB.GIROPreCheck_1',
    N'Sys_List_Title_CB.GIROPreCheck_1',
    N'MnuClass_CB.GIROPreCheck',
    N'mcorp-15-07_CB.GIROPreCheck_Confirm',
    N'mcorp-15-07_CB.GIROPreCheck_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROCancel',
    N'CB.GIROImport_Title',
    N'CB.GIROImport_Path',
    N'CB.GIROImport_NoFile',
    N'CB.GIROImport_SelectOneFile',
    N'CB.GIROPreCheck_Title',
    N'CB.GIROPreCheck_Info',
    N'CB.GIROPreCheck_NoAttachment',
    N'CB.GIROPreCheck_CannotConfirm',
    N'CB.GIROPreCheck_ConfirmAsk',
    N'CB.GIROBatch_ConfirmSuccess',
    N'CB.GIROBatch_ConfirmBeforePaymentDate',
    N'CB.GIROCancel_RemarkRejected',
    N'CB.GIROCancel_RemarkVerification',
    N'CB.GIROCancel_OnlyGenerated',
    N'CB.GIROCancel_Confirm',
    N'CB.GIROCancel_Success',
    N'CB.GIROBatch_NoReceiptInBatch',
    N'CB.GIROBatch_FileNotFound',
    N'CB.GIROBatch_FileNotMatch',
    N'CB.GIROBatch_ImportPathRequired',
    N'CB.GIROBatch_ImportPathNotFound'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (
    N'CB.GIROImportFile_FileNo',
    N'CB.GIROImportFile_Filename',
    N'CB.GIROPreCheck_CBReceiptID',
    N'CB.GIROPreCheck_DocumentNo',
    N'CB.GIROPreCheck_DebtorName',
    N'CB.GIROPreCheck_ReceiptAmt',
    N'CB.GIROPreCheck_GIROStatus',
    N'CB.GIROPreCheck_ReturnReason',
    N'CB.GIROPreCheck_DebtorAccount',
    N'CB.GIROPreCheck_GiroAccountNo',
    N'Sys_Base_Name_CB.GIROImportFile',
    N'Sys_Base_Desc_CB.GIROImportFile',
    N'Sys_List_Name_CB.GIROImportFile_-1',
    N'Sys_List_Title_CB.GIROImportFile_-1',
    N'Sys_List_Name_CB.GIROImportFile_1',
    N'Sys_List_Title_CB.GIROImportFile_1',
    N'MnuClass_CB.GIROImportFile',
    N'mcorp-15-07_CB.GIROImportFile_Select',
    N'mcorp-15-07_CB.GIROImportFile_Close',
    N'Sys_Base_Name_CB.GIROPreCheck',
    N'Sys_Base_Desc_CB.GIROPreCheck',
    N'Sys_List_Name_CB.GIROPreCheck_-1',
    N'Sys_List_Title_CB.GIROPreCheck_-1',
    N'Sys_List_Name_CB.GIROPreCheck_1',
    N'Sys_List_Title_CB.GIROPreCheck_1',
    N'MnuClass_CB.GIROPreCheck',
    N'mcorp-15-07_CB.GIROPreCheck_Confirm',
    N'mcorp-15-07_CB.GIROPreCheck_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROCancel',
    N'CB.GIROImport_Title',
    N'CB.GIROImport_Path',
    N'CB.GIROImport_NoFile',
    N'CB.GIROImport_SelectOneFile',
    N'CB.GIROPreCheck_Title',
    N'CB.GIROPreCheck_Info',
    N'CB.GIROPreCheck_NoAttachment',
    N'CB.GIROPreCheck_CannotConfirm',
    N'CB.GIROPreCheck_ConfirmAsk',
    N'CB.GIROBatch_ConfirmSuccess',
    N'CB.GIROBatch_ConfirmBeforePaymentDate',
    N'CB.GIROCancel_RemarkRejected',
    N'CB.GIROCancel_RemarkVerification',
    N'CB.GIROCancel_OnlyGenerated',
    N'CB.GIROCancel_Confirm',
    N'CB.GIROCancel_Success',
    N'CB.GIROBatch_NoReceiptInBatch',
    N'CB.GIROBatch_FileNotFound',
    N'CB.GIROBatch_FileNotMatch',
    N'CB.GIROBatch_ImportPathRequired',
    N'CB.GIROBatch_ImportPathNotFound');
END

-- obsolete (Confirm with Failed receipts was blocked before the Cancel Receipt Action)
DELETE FROM CF_String WHERE StringCode = N'CB.GIROBatch_CancelNotReady';

-- field labels (Field + Help)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROImportFile_FileNo', N'File No', N'File No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROImportFile_FileNo', N'File No', N'File No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROImportFile_Filename', N'Filename', N'Filename', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROImportFile_Filename', N'Filename', N'Filename', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_ReceiptAmt', N'Amount', N'Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_ReceiptAmt', N'Amount', N'Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_GIROStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_GIROStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_ReturnReason', N'Return Reason', N'Return Reason', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_ReturnReason', N'Return Reason', N'Return Reason', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROPreCheck_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROPreCheck_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- names / buttons: StringType + RefTable copied from an equivalent existing string
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROImportFile', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROImportFile', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROImportFile_-1', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROImportFile_-1', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROImportFile_1', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROImportFile_1', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROImportFile', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROImportFile_Select', N'Select', N'Select', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROImportFile_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROPreCheck', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROPreCheck', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROPreCheck_-1', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROPreCheck_-1', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROPreCheck_1', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROPreCheck_1', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROPreCheck', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROPreCheck_Confirm', N'Confirm', N'Confirm', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_CB.GIROPreCheck_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'mcorp-15-07_AC.ReceiptVerify_GIROCancel', N'Cancel', N'Cancel', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

-- messages used in code (Strings.GetString)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROImport_Title', N'GIRO Batch Import', N'GIRO Batch Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROImport_Path', N'Import Path:', N'Import Path:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROImport_NoFile', N'There is no file in the Import Path.', N'There is no file in the Import Path.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROImport_SelectOneFile', N'Please tick one file only.', N'Please tick one file only.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROPreCheck_Title', N'GIRO Batch Pre-Check', N'GIRO Batch Pre-Check', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROPreCheck_Info', N'GIRO Batch {0} | Bank {1} ({2}) | Payment Date {3} | Attachment: {4} | Success: {5} | Failed: {6}', N'GIRO Batch {0} | Bank {1} ({2}) | Payment Date {3} | Attachment: {4} | Success: {5} | Failed: {6}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROPreCheck_NoAttachment', N'none (all Success)', N'none (all Success)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROPreCheck_CannotConfirm', N'The batch cannot be confirmed, please check the message in red.', N'The batch cannot be confirmed, please check the message in red.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROPreCheck_ConfirmAsk', N'Confirm this GIRO batch? The batch will be Completed: Success receipts will be verified, Failed receipts will be voided and their bills released.', N'Confirm this GIRO batch? The batch will be Completed: Success receipts will be verified, Failed receipts will be voided and their bills released.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ConfirmSuccess', N'GIRO Batch {0} completed: {1} receipt(s) Success (verified), {2} receipt(s) Failed.', N'GIRO Batch {0} completed: {1} receipt(s) Success (verified), {2} receipt(s) Failed.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ConfirmBeforePaymentDate', N'GIRO Batch {0} cannot be confirmed before its Payment Date {1}.', N'GIRO Batch {0} cannot be confirmed before its Payment Date {1}.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROCancel_RemarkRejected', N'GIRO Batch {0} rejected by DBS: {1}', N'GIRO Batch {0} rejected by DBS: {1}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROCancel_RemarkVerification', N'GIRO receipt cancelled on Collection Verification', N'GIRO receipt cancelled on Collection Verification', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROCancel_OnlyGenerated', N'Only GIRO receipts not yet in a GIRO batch (Generated) can be cancelled here, please check:', N'Only GIRO receipts not yet in a GIRO batch (Generated) can be cancelled here, please check:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROCancel_Confirm', N'Cancel the ticked GIRO receipt(s)? They will be voided and their bills released.', N'Cancel the ticked GIRO receipt(s)? They will be voided and their bills released.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROCancel_Success', N'{0} GIRO receipt(s) cancelled (voided):', N'{0} GIRO receipt(s) cancelled (voided):', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_NoReceiptInBatch', N'The GIRO batch has no receipt.', N'The GIRO batch has no receipt.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_FileNotFound', N'File {0} is not found in the Import Path.', N'File {0} is not found in the Import Path.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_FileNotMatch', N'{0} record(s) of the file do not match this GIRO batch (wrong file?):', N'{0} record(s) of the file do not match this GIRO batch (wrong file?):', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ImportPathRequired', N'Import Path is not set up for the GIRO bank of this batch (Company GIRO Bank setup).', N'Import Path is not set up for the GIRO bank of this batch (Company GIRO Bank setup).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIROBatch_ImportPathNotFound', N'Import Path {0} is not found or cannot be accessed.', N'Import Path {0} is not found or cannot be accessed.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- Check
SELECT N'Sys_Base' AS Tbl, COUNT(*) AS Cnt FROM Sys_Base WHERE BseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck')
UNION ALL SELECT N'Sys_BaseDt', COUNT(*) FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck')
UNION ALL SELECT N'Sys_List', COUNT(*) FROM Sys_List WHERE LstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck')
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo IN (N'CB.GIROImportFile', N'CB.GIROPreCheck')
UNION ALL SELECT N'Sys_ContextMenuClass', COUNT(*) FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck')
UNION ALL SELECT N'Sys_ContextMenu', COUNT(*) FROM Sys_ContextMenu WHERE MnuClass IN (N'CB.GIROImportFile', N'CB.GIROPreCheck') AND MnuNo = N'mcorp-15-07'
UNION ALL SELECT N'Sys_ContextMenu GIROCancel', COUNT(*) FROM Sys_ContextMenu WHERE ContextMnuNo = N'GIROCancel' AND MnuClass = N'AC.ReceiptVerify' AND MnuNo = N'mcorp-15-07'
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (
    N'CB.GIROImportFile_FileNo',
    N'CB.GIROImportFile_Filename',
    N'CB.GIROPreCheck_CBReceiptID',
    N'CB.GIROPreCheck_DocumentNo',
    N'CB.GIROPreCheck_DebtorName',
    N'CB.GIROPreCheck_ReceiptAmt',
    N'CB.GIROPreCheck_GIROStatus',
    N'CB.GIROPreCheck_ReturnReason',
    N'CB.GIROPreCheck_DebtorAccount',
    N'CB.GIROPreCheck_GiroAccountNo',
    N'Sys_Base_Name_CB.GIROImportFile',
    N'Sys_Base_Desc_CB.GIROImportFile',
    N'Sys_List_Name_CB.GIROImportFile_-1',
    N'Sys_List_Title_CB.GIROImportFile_-1',
    N'Sys_List_Name_CB.GIROImportFile_1',
    N'Sys_List_Title_CB.GIROImportFile_1',
    N'MnuClass_CB.GIROImportFile',
    N'mcorp-15-07_CB.GIROImportFile_Select',
    N'mcorp-15-07_CB.GIROImportFile_Close',
    N'Sys_Base_Name_CB.GIROPreCheck',
    N'Sys_Base_Desc_CB.GIROPreCheck',
    N'Sys_List_Name_CB.GIROPreCheck_-1',
    N'Sys_List_Title_CB.GIROPreCheck_-1',
    N'Sys_List_Name_CB.GIROPreCheck_1',
    N'Sys_List_Title_CB.GIROPreCheck_1',
    N'MnuClass_CB.GIROPreCheck',
    N'mcorp-15-07_CB.GIROPreCheck_Confirm',
    N'mcorp-15-07_CB.GIROPreCheck_Close',
    N'mcorp-15-07_AC.ReceiptVerify_GIROCancel',
    N'CB.GIROImport_Title',
    N'CB.GIROImport_Path',
    N'CB.GIROImport_NoFile',
    N'CB.GIROImport_SelectOneFile',
    N'CB.GIROPreCheck_Title',
    N'CB.GIROPreCheck_Info',
    N'CB.GIROPreCheck_NoAttachment',
    N'CB.GIROPreCheck_CannotConfirm',
    N'CB.GIROPreCheck_ConfirmAsk',
    N'CB.GIROBatch_ConfirmSuccess',
    N'CB.GIROBatch_ConfirmBeforePaymentDate',
    N'CB.GIROCancel_RemarkRejected',
    N'CB.GIROCancel_RemarkVerification',
    N'CB.GIROCancel_OnlyGenerated',
    N'CB.GIROCancel_Confirm',
    N'CB.GIROCancel_Success',
    N'CB.GIROBatch_NoReceiptInBatch',
    N'CB.GIROBatch_FileNotFound',
    N'CB.GIROBatch_FileNotMatch',
    N'CB.GIROBatch_ImportPathRequired',
    N'CB.GIROBatch_ImportPathNotFound');
-- expected: Sys_Base 2, Sys_BaseDt 10, Sys_List 4, Sys_ListDt 12, Sys_ContextMenuClass 2, Sys_ContextMenu 4, Sys_ContextMenu GIROCancel 1, CF_String 60
