-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - Collection Verification: GIRO criteria / columns (Stanley doc v01.01)
-- Script 13: base / list AC.Receipt (standard, used by Collection Verification) + 3 fields of View_AC_Receipt (script 12):
--   IsGiroReceipt / GroupNo (GIRO Batch No) / GIRORecordStatus (GIRO Status): grid columns (list order 1 and 2, at the end)
--   + criteria (text search, same type as the other text criteria of the page)
-- Only these 3 field names are deleted / inserted; existing AC.Receipt config untouched. Re-runnable. Run after view View_AC_Receipt.
-----------------------------------------------------------------------------------------

-- Sys_BaseDt (3 GIRO fields only)
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo = N'AC.Receipt' AND BdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus'))
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo = N'AC.Receipt' AND BdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus');
END

DECLARE @o INT = (SELECT ISNULL(MAX(BdtFldOrder), 0) FROM Sys_BaseDt WHERE BdtBseNo = N'AC.Receipt');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'AC.Receipt', N'IsGiroReceipt', N'Is GIRO Receipt', N'Is GIRO Receipt', N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_IsGiroReceipt', 1, N'L3', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, @o + 1, NULL, N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'IsGiroReceipt', 1, NULL, NULL, NULL, N'CB.GIROYesNo', NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'AC.Receipt', N'GroupNo', N'GIRO Batch No', N'GIRO Batch No', N'AC.Receipt_GroupNo', N'AC.Receipt_GroupNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, @o + 2, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'AC.Receipt', N'GIRORecordStatus', N'GIRO Status', N'GIRO Status', N'AC.Receipt_GIRORecordStatus', N'AC.Receipt_GIRORecordStatus', 20, N'L3', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, @o + 3, NULL, N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'GIRORecordStatus', 1, NULL, NULL, NULL, N'CB.GIROReceiptStatus', NULL, NULL, NULL, N'N', N'N');

-- Sys_Select (dropdown lists of the 2 criteria, same structure as CB.ReceiptStatus)
IF EXISTS (SELECT TOP 1 1 FROM Sys_Select WITH (NOLOCK) WHERE SelNo IN (N'CB.GIROYesNo', N'CB.GIROReceiptStatus'))
BEGIN
    DELETE FROM Sys_Select WHERE SelNo IN (N'CB.GIROYesNo', N'CB.GIROReceiptStatus');
END

INSERT INTO Sys_Select ([SelNo], [SelLstNo], [SelDesc], [SelTable], [SelType], [SelPage], [SelSql], [SelSort], [SelFilter], [SelFldReturn], [SelFldUpdate])
VALUES (N'CB.GIROYesNo', N'CB.GIROYesNo', N'CB.GIROYesNo', N'CF_PopupLstElement', 1, 0, N'select ''Yes'' as IsGiroReceiptDesc, ''Y'' as IsGiroReceipt union all select ''No'', ''N''', NULL, NULL, N'IsGiroReceipt,IsGiroReceiptDesc', N'IsGiroReceipt,IsGiroReceipt');
INSERT INTO Sys_Select ([SelNo], [SelLstNo], [SelDesc], [SelTable], [SelType], [SelPage], [SelSql], [SelSort], [SelFilter], [SelFldReturn], [SelFldUpdate])
VALUES (N'CB.GIROReceiptStatus', N'CB.GIROReceiptStatus', N'CB.GIROReceiptStatus', N'CF_PopupLstElement', 1, 0, N'select ''Generated'' as GIRORecordStatusDesc, ''Generated'' as GIRORecordStatus union all select ''Exported'', ''Exported'' union all select ''Success'', ''Success'' union all select ''Failed'', ''Failed'' union all select ''Cancel'', ''Cancel''', NULL, NULL, N'GIRORecordStatus,GIRORecordStatusDesc', N'GIRORecordStatus,GIRORecordStatus');

-- Sys_ListDt (grid columns, list order 1 and 2, at the end)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo = N'AC.Receipt' AND LdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus'))
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo = N'AC.Receipt' AND LdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus');
END

SET @o = (SELECT ISNULL(MAX(LdtFldOrder), 0) FROM Sys_ListDt WHERE LdtLstNo = N'AC.Receipt' AND LdtLstOrder = 1);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 1, N'IsGiroReceipt', N'Is GIRO Receipt', NULL, N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_IsGiroReceipt', 1, 60, N'center', NULL, N'S', N'1', @o + 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 1, N'GroupNo', N'GIRO Batch No', NULL, N'AC.Receipt_GroupNo', N'AC.Receipt_GroupNo', 50, 90, N'left', NULL, N'S', N'1', @o + 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 1, N'GIRORecordStatus', N'GIRO Status', NULL, N'AC.Receipt_GIRORecordStatus', N'AC.Receipt_GIRORecordStatus', 20, 80, N'left', NULL, N'S', N'1', @o + 3, N'1', NULL, NULL, NULL);
SET @o = (SELECT ISNULL(MAX(LdtFldOrder), 0) FROM Sys_ListDt WHERE LdtLstNo = N'AC.Receipt' AND LdtLstOrder = 2);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 2, N'IsGiroReceipt', N'Is GIRO Receipt', NULL, N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_IsGiroReceipt', 1, 60, N'center', NULL, N'S', N'1', @o + 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 2, N'GroupNo', N'GIRO Batch No', NULL, N'AC.Receipt_GroupNo', N'AC.Receipt_GroupNo', 50, 90, N'left', NULL, N'S', N'1', @o + 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'AC.Receipt', 2, N'GIRORecordStatus', N'GIRO Status', NULL, N'AC.Receipt_GIRORecordStatus', N'AC.Receipt_GIRORecordStatus', 20, 80, N'left', NULL, N'S', N'1', @o + 3, N'1', NULL, NULL, NULL);

-- Sys_Filter (criteria, after the existing ones)
IF EXISTS (SELECT TOP 1 1 FROM Sys_Filter WITH (NOLOCK) WHERE FltBseNo = N'AC.Receipt' AND FltLstNo = N'AC.Receipt' AND FltName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus'))
BEGIN
    DELETE FROM Sys_Filter WHERE FltBseNo = N'AC.Receipt' AND FltLstNo = N'AC.Receipt' AND FltName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus');
END

SET @o = (SELECT ISNULL(MAX(FltOrder), 0) FROM Sys_Filter WHERE FltBseNo = N'AC.Receipt' AND FltLstNo = N'AC.Receipt');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'AC.Receipt', N'AC.Receipt', NULL, N'L3', NULL, 1, 0, NULL, NULL, 1, NULL, @o + 1, 0, N'IsGiroReceipt');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'AC.Receipt', N'AC.Receipt', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, @o + 2, 0, N'GroupNo');
INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'AC.Receipt', N'AC.Receipt', NULL, N'L3', NULL, 1, 0, NULL, NULL, 1, NULL, @o + 3, 0, N'GIRORecordStatus');

-- CF_String (labels)
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_GroupNo', N'AC.Receipt_GIRORecordStatus'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_GroupNo', N'AC.Receipt_GIRORecordStatus');
END

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'AC.Receipt_IsGiroReceipt', N'Is GIRO Receipt', N'Is GIRO Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'AC.Receipt_IsGiroReceipt', N'Is GIRO Receipt', N'Is GIRO Receipt', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'AC.Receipt_GroupNo', N'GIRO Batch No', N'GIRO Batch No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'AC.Receipt_GroupNo', N'GIRO Batch No', N'GIRO Batch No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'AC.Receipt_GIRORecordStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'AC.Receipt_GIRORecordStatus', N'GIRO Status', N'GIRO Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

GO
-- Check
SELECT N'Sys_BaseDt' AS Tbl, COUNT(*) AS Cnt FROM Sys_BaseDt WHERE BdtBseNo = N'AC.Receipt' AND BdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus')
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo = N'AC.Receipt' AND LdtFldName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus')
UNION ALL SELECT N'Sys_Filter', COUNT(*) FROM Sys_Filter WHERE FltBseNo = N'AC.Receipt' AND FltName IN (N'IsGiroReceipt', N'GroupNo', N'GIRORecordStatus')
UNION ALL SELECT N'Sys_Select', COUNT(*) FROM Sys_Select WHERE SelNo IN (N'CB.GIROYesNo', N'CB.GIROReceiptStatus')
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (N'AC.Receipt_IsGiroReceipt', N'AC.Receipt_GroupNo', N'AC.Receipt_GIRORecordStatus');
-- expected: Sys_BaseDt 3, Sys_ListDt 6, Sys_Filter 3, Sys_Select 2, CF_String 6
