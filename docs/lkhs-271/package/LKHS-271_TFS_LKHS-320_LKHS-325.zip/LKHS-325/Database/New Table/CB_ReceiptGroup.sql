-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch: CB_ReceiptGroup
-- 1 row = 1 GIRO batch / exported DBS file
-- Generate GIRO Batch Collection v01.00, columns approved by Stanley 02/11/2026
-- GroupNo generated with DocCode '316_ReceiptGroup' (CF_DocCode: TableName CB_ReceiptGroup, PrimaryKey CBReceiptGroupID, CodeField GroupNo)
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 1. CB_ReceiptGroup ---------------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroup', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CB_ReceiptGroup
    (
        CBReceiptGroupID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CB_ReceiptGroup PRIMARY KEY,  -- = CF_DocCode.PrimaryKey of 316_ReceiptGroup
        GroupNo         NVARCHAR(50)  NOT NULL,          -- GIRO Batch No (DBS Batch ID D07)
        DocumentDate    DATETIME      NULL,              -- Payment Date (D08)
        RecordType      VARCHAR(20)   NOT NULL,          -- 'GIRO'
        RecordStatus    VARCHAR(20)   NOT NULL,          -- Exported / Completed / Cancel
        CompanyID       INT           NOT NULL,
        BankAccountID   INT           NULL,              -- company AR GIRO bank (CF_BankAccount)
        CurrencyID      INT           NULL,              -- bank currency (D04 / D06)
        ReferenceNo     NVARCHAR(35)  NULL,              -- D34
        PurposeCode     NVARCHAR(20)  NULL,              -- D43 (DBS Purpose Code)
        Filename        NVARCHAR(200) NULL,              -- exported file name
        CreateUserID    INT           NOT NULL,
        CreateDate      DATETIME      NOT NULL,
        ModifyUserID    INT           NOT NULL,
        ModifyDate      DATETIME      NOT NULL
    )
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CB_ReceiptGroup_Company_GroupNo' AND object_id = OBJECT_ID('dbo.CB_ReceiptGroup'))
    CREATE INDEX IX_CB_ReceiptGroup_Company_GroupNo ON dbo.CB_ReceiptGroup (CompanyID, GroupNo);
GO
