-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch: CB_ReceiptGroupDetail
-- receipts in a batch (history kept after Reset), ReturnReason = DBS reject reason
-- Generate GIRO Batch Collection v01.00, columns approved by Stanley 02/11/2026
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 2. CB_ReceiptGroupDetail ---------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroupDetail', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CB_ReceiptGroupDetail
    (
        ReceiptGroupDetailID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CB_ReceiptGroupDetail PRIMARY KEY,
        ReceiptGroupID       INT           NOT NULL,     -- CB_ReceiptGroup.CBReceiptGroupID
        ReceiptID            INT           NOT NULL,     -- CB_Receipt.CBReceiptID
        RecordStatus         VARCHAR(20)   NOT NULL,     -- Active / Cancel (follows the batch)
        ReturnReason         NVARCHAR(255) NULL,         -- DBS reject reason (import)
        CreateUserID         INT           NOT NULL,
        CreateDate           DATETIME      NOT NULL,
        ModifyUserID         INT           NOT NULL,
        ModifyDate           DATETIME      NOT NULL
    )
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CB_ReceiptGroupDetail_Group' AND object_id = OBJECT_ID('dbo.CB_ReceiptGroupDetail'))
    CREATE INDEX IX_CB_ReceiptGroupDetail_Group ON dbo.CB_ReceiptGroupDetail (ReceiptGroupID, ReceiptID);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CB_ReceiptGroupDetail_Receipt' AND object_id = OBJECT_ID('dbo.CB_ReceiptGroupDetail'))
    CREATE INDEX IX_CB_ReceiptGroupDetail_Receipt ON dbo.CB_ReceiptGroupDetail (ReceiptID);
GO
