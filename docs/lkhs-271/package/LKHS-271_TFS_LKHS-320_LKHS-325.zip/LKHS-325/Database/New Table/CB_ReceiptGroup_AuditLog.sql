-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch: CB_ReceiptGroup_AuditLog
-- Generate / Reset / Import / Verify / Cancel actions
-- Generate GIRO Batch Collection v01.00, columns approved by Stanley 02/11/2026
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 3. CB_ReceiptGroup_AuditLog ------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroup_AuditLog', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CB_ReceiptGroup_AuditLog
    (
        AuditLogID      INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CB_ReceiptGroup_AuditLog PRIMARY KEY,
        ReceiptGroupID  INT           NULL,              -- CB_ReceiptGroup.CBReceiptGroupID; NULL for Cancel of a receipt not yet in a batch
        ProcessUserID   INT           NOT NULL,
        ProcessDateTime DATETIME      NOT NULL,
        Action          VARCHAR(20)   NOT NULL,          -- Generate / Export / Reset / Cancel / Import
        Remark          NVARCHAR(500) NULL,              -- e.g. file name, number of receipts
        CreateUserID    INT           NOT NULL,
        CreateDate      DATETIME      NOT NULL,
        ModifyUserID    INT           NOT NULL,
        ModifyDate      DATETIME      NOT NULL
    )
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CB_ReceiptGroup_AuditLog_Group' AND object_id = OBJECT_ID('dbo.CB_ReceiptGroup_AuditLog'))
    CREATE INDEX IX_CB_ReceiptGroup_AuditLog_Group ON dbo.CB_ReceiptGroup_AuditLog (ReceiptGroupID);
GO
