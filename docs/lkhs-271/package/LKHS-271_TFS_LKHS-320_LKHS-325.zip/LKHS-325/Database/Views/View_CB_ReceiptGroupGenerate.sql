-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch: View_CB_ReceiptGroupGenerate
-- read view of the popup header of GIRO Batch Generation (SysTabEdit)
-- Requires: table CB_ReceiptGroup
-- Re-runnable.
-----------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroup', 'U') IS NULL
BEGIN
    RAISERROR('LKHS-325: create table CB_ReceiptGroup first.', 16, 1)
    SET NOEXEC ON
END
GO

-- 3. Popup header (opened with key 0 -> no row; columns give the field structure) ----
IF OBJECT_ID('dbo.View_CB_ReceiptGroupGenerate', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_ReceiptGroupGenerate
GO

CREATE VIEW dbo.View_CB_ReceiptGroupGenerate
AS
-- LKHS-325: header of popup ARGIROBatchGenerate.aspx
SELECT  g.CBReceiptGroupID,
        g.CompanyID,
        g.GroupNo,
        g.BankAccountID,
        CAST(NULL AS NVARCHAR(150))     AS GiroBankStringCode,     -- Bank dropdown (filled in code)
        ba.AccountNo                    AS ACNo,
        g.CurrencyID,
        c.ISOCode                       AS Currency,
        g.ReferenceNo,                                             -- D34
        g.DocumentDate,                                            -- Payment Date D08
        g.PurposeCode,
        CAST(NULL AS NVARCHAR(150))     AS PurposeCodeStringCode,  -- Purpose dropdown (filled in code)
        CAST(NULL AS INT)               AS DocumentCount,
        CAST(NULL AS DECIMAL(22,2))     AS TotalAmt,
        g.RecordStatus
FROM    dbo.CB_ReceiptGroup g WITH (NOLOCK)
        LEFT JOIN dbo.CF_BankAccount ba WITH (NOLOCK) ON ba.BankAccountID = g.BankAccountID
        LEFT JOIN dbo.CF_Currency    c  WITH (NOLOCK) ON c.CurrencyID     = g.CurrencyID
GO

SET NOEXEC OFF
GO
