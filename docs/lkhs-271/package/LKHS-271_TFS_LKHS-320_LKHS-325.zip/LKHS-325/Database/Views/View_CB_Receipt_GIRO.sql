-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO: View_CB_Receipt_GIRO
-- GIRO receipts (CB_Receipt IsGiroReceipt = Y) + debtor GIRO data for the DBS UFF file
-- D35 Identity No = CF_Account.IdentityNo (Gunner 09/11)
-- Requires: CB_Receipt GIRO columns, view View_CB_GIROLookup
-- Re-runnable.
-----------------------------------------------------------------------------------------
IF COL_LENGTH('dbo.CB_Receipt', 'GIRORecordStatus') IS NULL OR OBJECT_ID('dbo.View_CB_GIROLookup', 'V') IS NULL
BEGIN
    RAISERROR('LKHS-325: run Table Change CB_Receipt_GIRO and view View_CB_GIROLookup first.', 16, 1)
    SET NOEXEC ON
END
GO

-- 2. GIRO receipts --------------------------------------------------------------------
IF OBJECT_ID('dbo.View_CB_Receipt_GIRO', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_Receipt_GIRO
GO

CREATE VIEW dbo.View_CB_Receipt_GIRO
AS
-- LKHS-325: receipts created by Generate GIRO Collection (step 6)
-- Batch popup grid = GIRORecordStatus 'Generated' + RecordStatus 'Active' of the selected company / GIRO bank.
SELECT  r.CBReceiptID,
        r.CompanyID,
        r.BankAccountID,
        r.CurrencyID,
        c.ISOCode                               AS Currency,
        CAST(CASE r.ReceiptType
                 WHEN 'MC_Fee'     THEN 'Rental Management'
                 WHEN 'OD_Receipt' THEN 'Other Receivable'
                 WHEN 'PM_Receipt' THEN 'Construction Management'
                 WHEN 'PS_Payment' THEN 'Property Sales'
                 ELSE r.ReceiptType
             END AS NVARCHAR(50))               AS Module,
        r.ReceiptType,
        r.DebtorID,
        d.DebtorAcct                            AS DebtorAccount,
        a.Name                                  AS DebtorName,
        r.DocNo                                 AS DocumentNo,
        r.DocumentDate,
        r.ReferenceNo,
        r.DocumentAmt                           AS ReceiptAmt,
        d.GiroAccountNo,                                        -- D16
        sw.LookupCode                           AS SwiftCode,   -- D21
        a.IdentityNo                            AS IdentityNo,  -- D35: debtor account profile CF_Account.IdentityNo (Gunner 09/11)
        r.GIRORecordStatus,
        r.GroupNo,
        r.RecordStatus
FROM    dbo.CB_Receipt r WITH (NOLOCK)
        INNER JOIN dbo.AR_Debtor  d WITH (NOLOCK) ON d.DebtorID   = r.DebtorID
        INNER JOIN dbo.CF_Account a WITH (NOLOCK) ON a.AccountID  = d.AccountID
        LEFT  JOIN dbo.CF_Currency c WITH (NOLOCK) ON c.CurrencyID = r.CurrencyID
        LEFT  JOIN dbo.View_CB_GIROLookup sw ON sw.LookupType = 'SWIFT' AND sw.LookupID = d.GiroBankSwiftCodeID
WHERE   r.IsGiroReceipt = 'Y'
GO

SET NOEXEC OFF
GO

-- Check
SELECT GIRORecordStatus, COUNT(*) AS Cnt FROM dbo.View_CB_Receipt_GIRO GROUP BY GIRORecordStatus;
