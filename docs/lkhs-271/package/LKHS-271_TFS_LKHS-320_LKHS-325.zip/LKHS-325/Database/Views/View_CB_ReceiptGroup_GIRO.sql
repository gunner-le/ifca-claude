-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - dot 2b
-- Script 09: View_CB_ReceiptGroup_GIRO = GIRO Batch Listing (Stanley doc v01.00)
--   one row per batch: bank, GIRO batch no, reference, payment date, purpose,
--   Total No Debtor (= lines of the UFF file), Total Amount, Created By, Create Date, file name, status
--   (columns / labels = Stanley doc Generate_GIRO_Batch_Collection_v01.00, GIRO Batch Listing Page)
-- "Created By" = View_CF_User.UserName (users linked to an employee), else CF_User.LoginName (e.g. admin user 1).
-- Re-runnable. Run after 06 / 07.
-----------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroup', 'U') IS NULL
BEGIN
    RAISERROR('LKHS-325: run script 06 first.', 16, 1)
    SET NOEXEC ON
END
GO

IF OBJECT_ID('dbo.View_CB_ReceiptGroup_GIRO', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_ReceiptGroup_GIRO
GO

CREATE VIEW dbo.View_CB_ReceiptGroup_GIRO
AS
-- LKHS-325: GIRO Batch Listing (ARGIROBatchLst.aspx). All batches listed, Exported first; actions only on Exported.
SELECT  g.CBReceiptGroupID,
        g.CompanyID,
        g.GroupNo,                                   -- GIRO Batch (DBS Batch ID D07)
        g.BankAccountID,
        ca.Name                         AS BankName,
        ba.AccountNo                    AS ACNo,
        g.CurrencyID,
        c.ISOCode                       AS Currency,
        g.ReferenceNo,
        g.DocumentDate,                              -- Payment Date
        g.PurposeCode,
        ISNULL(d.TotalDebtor, 0)        AS TotalDebtor,              -- Total No Debtor
        ISNULL(d.TotalAmt, 0)           AS TotalAmt,                 -- Total Amount
        ISNULL(d.TotalReceipt, 0)       AS TotalReceipt,
        COALESCE(vu.UserName, cu.LoginName) AS CreatedBy,           -- View_CF_User (users linked to an employee), else CF_User (e.g. admin)
        g.CreateDate,
        g.Filename,
        g.RecordType,
        g.RecordStatus,
        g.CreateUserID,
        g.ModifyDate
FROM    dbo.CB_ReceiptGroup g WITH (NOLOCK)
        LEFT JOIN dbo.CF_BankAccount ba WITH (NOLOCK) ON ba.BankAccountID = g.BankAccountID
        LEFT JOIN dbo.CF_Account     ca WITH (NOLOCK) ON ca.AccountID     = ba.AccountID
        LEFT JOIN dbo.CF_Currency    c  WITH (NOLOCK) ON c.CurrencyID     = g.CurrencyID
        LEFT JOIN dbo.View_CF_User   vu ON vu.UserID = g.CreateUserID
        LEFT JOIN dbo.CF_User        cu WITH (NOLOCK) ON cu.UserID = g.CreateUserID
        OUTER APPLY (SELECT COUNT(DISTINCT r.DebtorID) AS TotalDebtor, COUNT(*) AS TotalReceipt, SUM(r.DocumentAmt) AS TotalAmt
                     FROM dbo.CB_ReceiptGroupDetail gd WITH (NOLOCK)
                          INNER JOIN dbo.CB_Receipt r WITH (NOLOCK) ON r.CBReceiptID = gd.ReceiptID
                     WHERE gd.ReceiptGroupID = g.CBReceiptGroupID
                       AND (gd.RecordStatus <> 'Cancel' OR g.RecordStatus = 'Cancel')) d   -- reset batch: count its receipts at creation (history)
WHERE   g.RecordType = 'GIRO'
GO

SET NOEXEC OFF
GO

-- Check
SELECT CBReceiptGroupID, GroupNo, BankName, ACNo, Currency, ReferenceNo, DocumentDate, PurposeCode,
       TotalDebtor, TotalReceipt, TotalAmt, CreatedBy, CreateDate, RecordStatus
FROM dbo.View_CB_ReceiptGroup_GIRO ORDER BY CBReceiptGroupID DESC;