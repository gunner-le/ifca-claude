-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - dot 2b
-- Script 09: View_CB_ReceiptGroup_GIRO = GIRO Batch Listing (Stanley doc v01.00)
--   one row per batch: bank, GIRO batch no, reference, payment date, purpose,
--   Total No Debtor (= lines of the UFF file), Total Amount, Created By, Create Date, file name, status
--   (columns / labels = Stanley doc Generate_GIRO_Batch_Collection_v01.00, GIRO Batch Listing Page)
-- "Created By" = user name column of View_CF_User found at run time (no column name guessed),
--   else CF_User.LoginName (if the table / column exist), else blank (no UserID shown).
-- Re-runnable. Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.CB_ReceiptGroup', 'U') IS NULL
BEGIN
    RAISERROR('LKHS-325: create table CB_ReceiptGroup first.', 16, 1)
    SET NOEXEC ON
END
GO

IF OBJECT_ID('dbo.View_CB_ReceiptGroup_GIRO', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_ReceiptGroup_GIRO
GO

DECLARE @userCol SYSNAME =
    (SELECT TOP 1 c.name
     FROM sys.columns c
     WHERE c.object_id = OBJECT_ID('dbo.View_CF_User')
       AND c.name IN ('UserName', 'LoginName', 'UserCode', 'Name')
     ORDER BY CASE c.name WHEN 'UserName' THEN 1 WHEN 'LoginName' THEN 2 WHEN 'UserCode' THEN 3 ELSE 4 END);

-- fallback: LoginName of the base table CF_User (View_CF_User only lists users linked to an employee), else blank
DECLARE @fallback NVARCHAR(400) =
    CASE WHEN COL_LENGTH('dbo.CF_User', 'LoginName') IS NOT NULL AND COL_LENGTH('dbo.CF_User', 'UserID') IS NOT NULL
         THEN N'(SELECT TOP 1 CAST(cu.LoginName AS NVARCHAR(100)) FROM dbo.CF_User cu WHERE cu.UserID = g.CreateUserID)'
         ELSE N'CAST(NULL AS NVARCHAR(100))'
    END;

DECLARE @generatedBy NVARCHAR(1000) =
    CASE WHEN @userCol IS NULL
         THEN @fallback
         ELSE N'COALESCE((SELECT TOP 1 CAST(u.' + QUOTENAME(@userCol) + N' AS NVARCHAR(100)) FROM dbo.View_CF_User u WHERE u.UserID = g.CreateUserID), ' + @fallback + N')'
    END;

DECLARE @sql NVARCHAR(MAX) = N'
CREATE VIEW dbo.View_CB_ReceiptGroup_GIRO
AS
-- LKHS-325: GIRO Batch Listing (ARGIROBatchLst.aspx). All batches listed, Exported first; actions only on Exported.
SELECT  g.CBReceiptGroupID,
        g.CompanyID,
        g.GroupNo,                                   -- GIRO Batch (DBS Batch ID D07)
        g.BankAccountID,
        ca.Name                         AS BankName,
        ba.AccountNo                    AS ACNo,
        g.CurrencyID,
        c.ISOCode                       AS Currency,
        g.ReferenceNo,
        g.DocumentDate,                              -- Payment Date
        g.PurposeCode,
        ISNULL(d.TotalDebtor, 0)        AS TotalDebtor,              -- Total No Debtor
        ISNULL(d.TotalAmt, 0)           AS TotalAmt,                 -- Total Amount
        ISNULL(d.TotalReceipt, 0)       AS TotalReceipt,
        ' + @generatedBy + N'           AS CreatedBy,
        g.CreateDate,
        g.Filename,
        g.RecordType,
        g.RecordStatus,
        g.CreateUserID,
        g.ModifyDate
FROM    dbo.CB_ReceiptGroup g WITH (NOLOCK)
        LEFT JOIN dbo.CF_BankAccount ba WITH (NOLOCK) ON ba.BankAccountID = g.BankAccountID
        LEFT JOIN dbo.CF_Account     ca WITH (NOLOCK) ON ca.AccountID     = ba.AccountID
        LEFT JOIN dbo.CF_Currency    c  WITH (NOLOCK) ON c.CurrencyID     = g.CurrencyID
        OUTER APPLY (SELECT COUNT(DISTINCT r.DebtorID) AS TotalDebtor, COUNT(*) AS TotalReceipt, SUM(r.DocumentAmt) AS TotalAmt
                     FROM dbo.CB_ReceiptGroupDetail gd WITH (NOLOCK)
                          INNER JOIN dbo.CB_Receipt r WITH (NOLOCK) ON r.CBReceiptID = gd.ReceiptID
                     WHERE gd.ReceiptGroupID = g.CBReceiptGroupID
                       AND (gd.RecordStatus <> ''Cancel'' OR g.RecordStatus = ''Cancel'')) d   -- reset batch: count its receipts at creation (history)
WHERE   g.RecordType = ''GIRO''';

EXEC (@sql);
GO

SET NOEXEC OFF
GO

-- Check
SELECT CBReceiptGroupID, GroupNo, BankName, ACNo, Currency, ReferenceNo, DocumentDate, PurposeCode,
       TotalDebtor, TotalReceipt, TotalAmt, CreatedBy, CreateDate, RecordStatus
FROM dbo.View_CB_ReceiptGroup_GIRO ORDER BY CBReceiptGroupID DESC;
