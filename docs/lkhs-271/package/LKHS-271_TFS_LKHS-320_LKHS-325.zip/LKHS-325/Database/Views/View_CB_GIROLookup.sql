-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO: View_CB_GIROLookup
-- SWIFT code / DBS Purpose Code lists (ONLY place that knows where they are stored)
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 1. Lookup lists ---------------------------------------------------------------------
IF OBJECT_ID('dbo.View_CB_GIROLookup', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_GIROLookup
GO

CREATE VIEW dbo.View_CB_GIROLookup
AS
-- LKHS-325: dropdown lists set up by master (Cash Mgmt > Customized Setup > Dropdown List), stored in CF_PopupLstElement
--   'SWIFT'   : list "Bank SWIFT Code"  (TitleStringCode 'SCSWIFTCode_%'),      AR_Debtor.GiroBankSwiftCodeID = PopupLstElementID
--               ElementCode = bank code (e.g. 9742), TitleCN = SWIFT BIC (D21, e.g. ANTPSGSG), TitleEN = bank name
--   'PURPOSE' : list "DBS Purpose Code" (TitleStringCode 'SCDBSPurposeCode_%')
--               ElementCode = purpose code (D43, e.g. RENT), TitleEN = description
-- Lists found by TitleStringCode prefix (PopupLstID may differ between databases).
SELECT  CAST('SWIFT' AS VARCHAR(10))                    AS LookupType,
        e.PopupLstElementID                             AS LookupID,
        CAST(LTRIM(RTRIM(e.TitleCN)) AS NVARCHAR(50))   AS LookupCode,
        CAST(e.TitleEN AS NVARCHAR(200))                AS LookupName,
        e.RecordStatus
FROM    dbo.CF_PopupLstElement e WITH (NOLOCK)
WHERE   e.TitleStringCode LIKE 'SCSWIFTCode[_]%'
UNION ALL
SELECT  CAST('PURPOSE' AS VARCHAR(10)),
        e.PopupLstElementID,
        CAST(LTRIM(RTRIM(e.ElementCode)) AS NVARCHAR(50)),
        CAST(e.TitleEN AS NVARCHAR(200)),
        e.RecordStatus
FROM    dbo.CF_PopupLstElement e WITH (NOLOCK)
WHERE   e.TitleStringCode LIKE 'SCDBSPurposeCode[_]%'
GO

-- Check
SELECT LookupType, LookupID, LookupCode, LookupName, RecordStatus FROM dbo.View_CB_GIROLookup ORDER BY LookupType, LookupCode;
