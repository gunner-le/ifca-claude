-----------------------------------------------------------------------------------------
-- LKHS-325 - GIRO Batch (step 7) - Collection Verification: GIRO criteria / columns (Stanley doc v01.01)
-- Script 12: View_AC_Receipt (STANDARD view of Collection Verification, list AC.Receipt) + 3 columns at the END
--   of each of the 4 UNION parts:  IsGiroReceipt (Y/N), GroupNo (GIRO Batch No), GIRORecordStatus (GIRO Status)
-- Everything else = the LKHS definition sent by Gunner 06/11 (sp_helptext), unchanged; lines marked "LKHS-325 GIRO".
-- Requires Table Change CB_Receipt_GIRO (CB_Receipt.IsGiroReceipt / GroupNo / GIRORecordStatus). Re-runnable (ALTER VIEW).
-----------------------------------------------------------------------------------------
ALTER VIEW [dbo].[view_AC_Receipt]
AS
SELECT     dbo.CB_Receipt.CBReceiptID, dbo.CB_Receipt.CompanyID, dbo.CB_Receipt.DocNo, dbo.CB_Receipt.BankAccountID
          ,dbo.GetBankName(dbo.CB_Receipt.BankAccountID) AS BankName,cba.BankCode
          , dbo.CB_Receipt.DebtorID,CASE WHEN dbo.CF_Account.Name = 'Other Receivable' THEN dbo.CB_Receipt.PaidBy ELSE dbo.CF_Account.Name END AS Debtor, 'Y' AS IsDebtor,
          'CommonY' AS IsDebtorStringCode, dbo.CB_Receipt.PaidByOthersID, --CF_Account_2.Name AS PaidByOthers,
    CASE WHEN CF_Account_2.Name IS NULL THEN dbo.CB_Receipt.PaidBy ELSE CF_Account_2.Name END AS PaidByOthers,
    dbo.CB_Receipt.PaidBy,
          dbo.CB_Receipt.ReferenceNo, dbo.CB_Receipt.AllocSpecID, dbo.AR_AllocSpec.Name AS AllocSpecName, dbo.CB_Receipt.BankInByID,
          A.EmployeeName AS BankInBy, dbo.CB_Receipt.BankInDate, dbo.CB_Receipt.ReceiptType,
          dbo.CF_PopupLstElement.TitleStringCode AS ReceiptTypeStringCode, dbo.CB_Receipt.PayMethod,
          CF_PopupLstElement_1.TitleStringCode AS PayMethodStringCode, dbo.CB_Receipt.DocumentDate, dbo.CB_Receipt.TransactionDate,
          dbo.CB_Receipt.CurrencyID, dbo.CF_Currency.ISOCode AS Currency, dbo.CF_Currency.Name AS CurrencyName, dbo.CB_Receipt.ExchangeRate,
          CB_Receipt.DocumentAmt,dbo.CB_Receipt.BaseAmt, dbo.CB_Receipt.AllocBalance, dbo.CB_Receipt.TaxInvoiceNo,
          dbo.CB_Receipt.TaxInvoiceDate, dbo.CB_Receipt.Remark, dbo.CB_Receipt.VoidDate, dbo.CB_Receipt.VoidUserID,
          dbo.View_CF_User.EmployeeName AS VoidUser, dbo.CB_Receipt.RecordStatus
          --, ISNULL(dbo.CB_Trx.AdminChargeAmt, 0) AS AdminChargeAmt
          ,dbo.CB_Receipt.BankCharge AS AdminChargeAmt
          , 'Receipt' + dbo.CB_Receipt.RecordStatus AS RecordStatusStringCode,ChequeIssueDate,ChequeExpiryDate,
          case when cb_Receipt.ActualAmt=0 or cb_Receipt.ActualAmt is null then cb_Receipt.DocumentAmt else cb_Receipt.ActualAmt end  as ActualAmt,
          case when cb_Receipt.ActualBaseAmt=0 or cb_Receipt.ActualBaseAmt is null then cb_Receipt.BaseAmt else cb_Receipt.ActualBaseAmt end  as ActualBaseAmt,
          CB_Receipt.cbtrxid,dbo.CB_Receipt.CreditCardTypeID,cba.AccountNo,dbo.CB_Receipt.CreateDate,ISNULL(artrx.TaxAmt,0) AS TaxAmt,  cu.LoginName,
          (SELECT TOP 1 A.TaxID FROM AR_Allocation  (NOLOCK) AS alloc LEFT JOIN dbo.AR_Trx  (NOLOCK) AS A  ON A.BillID = alloc.BillID LEFT JOIN dbo.CF_Tax (NOLOCK) AS C ON A.TaxID = C.TaxID WHERE CB_Receipt.CBReceiptID=alloc.ReceiptID AND C.TaxCode <> 'N/A'
   GROUP
   BY alloc.ReceiptID, A.TaxID) AS TaxID,
   CB_Receipt.IsCustomer, CB_Receipt.DebtorName, CB_Receipt.DebtorGSTNo, CB_Receipt.DebtorROCNo
          -- LKHS-325 GIRO: GIRO columns for Collection Verification (criteria / grid / Cancel button rule)
          ,ISNULL(CB_Receipt.IsGiroReceipt, 'N') AS IsGiroReceipt, CB_Receipt.GroupNo, CB_Receipt.GIRORecordStatus
 FROM  dbo.CB_Receipt (NOLOCK) INNER JOIN
      dbo.AR_Debtor (NOLOCK) ON dbo.CB_Receipt.DebtorID = dbo.AR_Debtor.DebtorID INNER JOIN
      dbo.CF_Account (NOLOCK) ON dbo.AR_Debtor.AccountID = dbo.CF_Account.AccountID INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) ON dbo.CB_Receipt.ReceiptType = dbo.CF_PopupLstElement.ElementCode INNER JOIN
      cf_Popuplst (NOLOCK) on CF_PopupLstElement.popuplstid=cf_Popuplst.popuplstid and cf_Popuplst.[Type]='MC_ReceiptType' INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_1 ON dbo.CB_Receipt.PayMethod = CF_PopupLstElement_1.PopupLstElementID INNER JOIN
      dbo.CF_Currency (NOLOCK) ON dbo.CB_Receipt.CurrencyID = dbo.CF_Currency.CurrencyID LEFT OUTER JOIN
      dbo.View_CF_User ON dbo.CB_Receipt.VoidUserID = dbo.View_CF_User.UserID LEFT OUTER JOIN
      dbo.AR_AllocSpec (NOLOCK) ON dbo.CB_Receipt.AllocSpecID = dbo.AR_AllocSpec.AllocSpecID LEFT OUTER JOIN
      dbo.CF_Financier (NOLOCK) AS CF_Financier ON dbo.CB_Receipt.PaidByOthersID = CF_Financier.FinancierID LEFT OUTER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_2 ON CF_Financier.AccountID = CF_Account_2.AccountID LEFT OUTER JOIN
      dbo.View_CF_User AS A ON dbo.CB_Receipt.BankInByID = A.UserID LEFT OUTER JOIN
      dbo.CF_BankAccount (NOLOCK) cba ON dbo.CB_Receipt.BankAccountID=cba.BankAccountID
   --LEFT JOIN (SELECT DocumentNo, ISNULL(SUM(TaxAmt),0) AS TaxAmt FROM ar_trx (NOLOCK) WHERE RecordStatus <> 'Inactive' GROUP BY DocumentNo) AS artrx
   LEFT JOIN dbo.View_CF_User (NOLOCK) AS cu ON dbo.CB_Receipt.createuserid=cu.UserID
   LEFT JOIN (SELECT aa.ReceiptID, ISNULL(SUM(at.TaxAmt),0) AS TaxAmt FROM ar_allocation(NOLOCK)  aa inner join ar_trx (NOLOCK) at on at.billid=aa.billid WHERE at.RecordStatus <> 'Inactive' and aa.RecordStatus <> 'Inactive'  GROUP BY aa.ReceiptID) AS artrx
   ON artrx.ReceiptID = dbo.CB_Receipt.cbreceiptid
   WHERE dbo.CB_Receipt.RecordStatus <> 'Voided'
UNION  all
SELECT     CB_Receipt_2.CBReceiptID, CB_Receipt_2.CompanyID, CB_Receipt_2.DocNo, CB_Receipt_2.BankAccountID,
      dbo.GetBankName(CB_Receipt_2.BankAccountID) AS BankName,cba.BankCode, CB_Receipt_2.CreditorID AS DebtorID, CASE WHEN CF_Account_1.Name = 'Other Receivable' THEN CB_Receipt_2.PaidBy ELSE CF_Account_1.Name END AS Debtor,
      'N' AS IsDebtor, 'CommonN' AS IsDebtorStringCode, CB_Receipt_2.PaidByOthersID, --CF_Account_2.Name AS PaidByOthers,
   CASE WHEN CF_Account_2.Name IS NULL THEN CB_Receipt_2.PaidBy ELSE CF_Account_2.Name END AS PaidByOthers,
   CB_Receipt_2.PaidBy,
      CB_Receipt_2.ReferenceNo, CB_Receipt_2.AllocSpecID, AR_AllocSpec_2.Name AS AllocSpecName, CB_Receipt_2.BankInByID,
      A.EmployeeName AS BankInBy, CB_Receipt_2.BankInDate, CB_Receipt_2.ReceiptType,
      CF_PopupLstElement_3.TitleStringCode AS ReceiptTypeStringCode, CB_Receipt_2.PayMethod,
      CF_PopupLstElement_1.TitleStringCode AS PayMethodStringCode, CB_Receipt_2.DocumentDate, CB_Receipt_2.TransactionDate,
      CB_Receipt_2.CurrencyID, CF_Currency_2.ISOCode AS Currency, CF_Currency_2.Name AS CurrencyName, CB_Receipt_2.ExchangeRate,
      CB_Receipt_2.DocumentAmt,CB_Receipt_2.BaseAmt, CB_Receipt_2.AllocBalance, CB_Receipt_2.TaxInvoiceNo, CB_Receipt_2.TaxInvoiceDate,
      CB_Receipt_2.Remark, CB_Receipt_2.VoidDate, CB_Receipt_2.VoidUserID, View_CF_User_2.EmployeeName AS VoidUser,
      CB_Receipt_2.RecordStatus
      --, ISNULL(CB_Trx_2.AdminChargeAmt, 0) AS AdminChargeAmt,
      ,CB_Receipt_2.BankCharge AS AdminChargeAmt
      ,'Receipt' + CB_Receipt_2.RecordStatus AS RecordStatusStringCode,ChequeIssueDate,ChequeExpiryDate,
          case when CB_Receipt_2.ActualAmt=0 or CB_Receipt_2.ActualAmt is null then CB_Receipt_2.DocumentAmt else CB_Receipt_2.ActualAmt end  as ActualAmt,
          case when CB_Receipt_2.ActualBaseAmt=0 or CB_Receipt_2.ActualBaseAmt is null then CB_Receipt_2.BaseAmt else CB_Receipt_2.ActualBaseAmt end  as ActualBaseAmt,CB_Receipt_2.cbtrxid
          ,CB_Receipt_2.CreditCardTypeID,cba.AccountNo,CB_Receipt_2.CreateDate,ISNULL(artrx.TaxAmt,0) AS TaxAmt, cu.LoginName,
          (SELECT TOP 1 A.TaxID FROM AR_Allocation (NOLOCK) AS alloc LEFT JOIN dbo.AR_Trx (NOLOCK) AS A  ON A.BillID = alloc.BillID LEFT JOIN dbo.CF_Tax (NOLOCK) AS C ON A.TaxID = C.TaxID WHERE CB_Receipt_2.CBReceiptID=alloc.ReceiptID AND C.TaxCode <> 'N/A' GROUP BY alloc.ReceiptID, A.TaxID) AS TaxID,
    CB_Receipt_2.IsCustomer, CB_Receipt_2.DebtorName, CB_Receipt_2.DebtorGSTNo, CB_Receipt_2.DebtorROCNo
          -- LKHS-325 GIRO: GIRO columns for Collection Verification (criteria / grid / Cancel button rule)
          ,ISNULL(CB_Receipt_2.IsGiroReceipt, 'N') AS IsGiroReceipt, CB_Receipt_2.GroupNo, CB_Receipt_2.GIRORecordStatus
FROM dbo.CB_Receipt (NOLOCK) AS CB_Receipt_2 INNER JOIN
      dbo.AP_Creditor (NOLOCK) ON dbo.AP_Creditor.CreditorID = CB_Receipt_2.CreditorID INNER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_1 ON dbo.AP_Creditor.AccountID = CF_Account_1.AccountID INNER JOIN
      dbo.CF_Currency (NOLOCK) AS CF_Currency_2 ON CB_Receipt_2.CurrencyID = CF_Currency_2.CurrencyID INNER JOIN
  dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_1 ON CB_Receipt_2.PayMethod = CF_PopupLstElement_1.PopupLstElementID INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_3 ON CB_Receipt_2.ReceiptType = CF_PopupLstElement_3.ElementCode inner join
      cf_Popuplst (NOLOCK) on CF_PopupLstElement_3.popuplstid=cf_Popuplst.popuplstid and cf_Popuplst.[Type]='MC_ReceiptType'  LEFT OUTER JOIN
      dbo.View_CF_User AS View_CF_User_2 ON CB_Receipt_2.VoidUserID = View_CF_User_2.UserID LEFT OUTER JOIN
      dbo.AR_AllocSpec (NOLOCK) AS AR_AllocSpec_2 ON CB_Receipt_2.AllocSpecID = AR_AllocSpec_2.AllocSpecID LEFT OUTER JOIN
      dbo.CF_Financier (NOLOCK) AS CF_Financier ON CB_Receipt_2.PaidByOthersID = CF_Financier.FinancierID LEFT OUTER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_2 ON CF_Financier.AccountID = CF_Account_2.AccountID LEFT OUTER JOIN
      dbo.View_CF_User AS A ON CB_Receipt_2.BankInByID = A.UserID  LEFT OUTER JOIN
      dbo.CF_BankAccount (NOLOCK) cba ON CB_Receipt_2.BankAccountID=cba.BankAccountID
      --LEFT JOIN (SELECT DocumentNo, ISNULL(SUM(TaxAmt),0) AS TaxAmt FROM ar_trx (NOLOCK) WHERE RecordStatus <> 'Inactive' GROUP BY DocumentNo) AS artrx
   LEFT JOIN dbo.View_CF_User (NOLOCK) AS cu ON CB_Receipt_2.createuserid=cu.UserID
   LEFT JOIN (SELECT aa.ReceiptID, ISNULL(SUM(at.TaxAmt),0) AS TaxAmt FROM ar_allocation(NOLOCK)  aa inner join ar_trx (NOLOCK) at on at.billid=aa.billid WHERE at.RecordStatus <> 'Inactive' and aa.RecordStatus <> 'Inactive'  GROUP BY aa.ReceiptID) AS artrx
   ON artrx.ReceiptID = CB_Receipt_2.cbreceiptid
WHERE     (CB_Receipt_2.DebtorID IS NULL) AND CB_Receipt_2.ReceiptType<>'PM_Deposit' AND CB_Receipt_2.RecordStatus <> 'Voided'
UNION  all
SELECT     CB_Receipt_1.CBReceiptID, CB_Receipt_1.CompanyID, CB_Receipt_1.DocNo, CB_Receipt_1.BankAccountID,
      dbo.GetBankName(CB_Receipt_1.BankAccountID) AS BankName,cba.BankCode, NULL AS DebtorID, CB_Receipt_1.PaidBy AS Debtor, 'N' AS IsDebtor,
      'CommonN' AS IsDebtorStringCode, CB_Receipt_1.PaidByOthersID, --CF_Account_2.Name AS PaidByOthers,
   CASE WHEN CF_Account_2.Name IS NULL THEN CB_Receipt_1.PaidBy ELSE CF_Account_2.Name END AS PaidByOthers,
   CB_Receipt_1.PaidBy,
      CB_Receipt_1.ReferenceNo, CB_Receipt_1.AllocSpecID, AR_AllocSpec_1.Name AS AllocSpecName, CB_Receipt_1.BankInByID,
      A.EmployeeName AS BankInBy, CB_Receipt_1.BankInDate, CB_Receipt_1.ReceiptType,
      CF_PopupLstElement_2.TitleStringCode AS ReceiptTypeStringCode, CB_Receipt_1.PayMethod,
      CF_PopupLstElement_1.TitleStringCode AS PayMethodStringCode, CB_Receipt_1.DocumentDate, CB_Receipt_1.TransactionDate,
      CB_Receipt_1.CurrencyID, CF_Currency_1.ISOCode AS Currency, CF_Currency_1.Name AS CurrencyName, CB_Receipt_1.ExchangeRate,
      CB_Receipt_1.DocumentAmt,CB_Receipt_1.BaseAmt, CB_Receipt_1.AllocBalance, CB_Receipt_1.TaxInvoiceNo, CB_Receipt_1.TaxInvoiceDate,
      CB_Receipt_1.Remark, CB_Receipt_1.VoidDate, CB_Receipt_1.VoidUserID, View_CF_User_1.EmployeeName AS VoidUser,
      CB_Receipt_1.RecordStatus
      --, ISNULL(CB_Trx_1.AdminChargeAmt, 0) AS AdminChargeAmt,
                  ,CB_Receipt_1.BankCharge AS AdminChargeAmt
      ,'Receipt' + CB_Receipt_1.RecordStatus AS RecordStatusStringCode,ChequeIssueDate,ChequeExpiryDate,
          case when CB_Receipt_1.ActualAmt=0 or CB_Receipt_1.ActualAmt is null then CB_Receipt_1.DocumentAmt else CB_Receipt_1.ActualAmt end  as ActualAmt,
          case when CB_Receipt_1.ActualBaseAmt=0 or CB_Receipt_1.ActualBaseAmt is null then CB_Receipt_1.BaseAmt else CB_Receipt_1.ActualBaseAmt end  as ActualBaseAmt,CB_Receipt_1.cbtrxid
,CB_Receipt_1.CreditCardTypeID,cba.AccountNo,CB_Receipt_1.CreateDate,ISNULL(artrx.TaxAmt,0) AS TaxAmt, cu.LoginName,
(SELECT TOP 1 A.TaxID FROM AR_Allocation (NOLOCK) AS alloc LEFT JOIN dbo.AR_Trx (NOLOCK) AS A  ON A.BillID = alloc.BillID LEFT JOIN dbo.CF_Tax (NOLOCK) AS C ON A.TaxID = C.TaxID WHERE CB_Receipt_1.CBReceiptID=alloc.ReceiptID AND C.TaxCode <> 'N/A'
GROUP BY alloc.ReceiptID, A.TaxID) AS TaxID,
   CB_Receipt_1.IsCustomer, CB_Receipt_1.DebtorName, CB_Receipt_1.DebtorGSTNo, CB_Receipt_1.DebtorROCNo
          -- LKHS-325 GIRO: GIRO columns for Collection Verification (criteria / grid / Cancel button rule)
          ,ISNULL(CB_Receipt_1.IsGiroReceipt, 'N') AS IsGiroReceipt, CB_Receipt_1.GroupNo, CB_Receipt_1.GIRORecordStatus
FROM         dbo.CB_Receipt (NOLOCK) AS CB_Receipt_1 INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_2 ON CB_Receipt_1.ReceiptType = CF_PopupLstElement_2.ElementCode inner join
      cf_Popuplst (NOLOCK) on CF_PopupLstElement_2.popuplstid=cf_Popuplst.popuplstid and cf_Popuplst.[Type]='MC_ReceiptType' INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_1 ON CB_Receipt_1.PayMethod = CF_PopupLstElement_1.PopupLstElementID INNER JOIN
      dbo.CF_Currency (NOLOCK) AS CF_Currency_1 ON CB_Receipt_1.CurrencyID = CF_Currency_1.CurrencyID LEFT OUTER JOIN
      dbo.View_CF_User AS View_CF_User_1 ON CB_Receipt_1.VoidUserID = View_CF_User_1.UserID LEFT OUTER JOIN
      dbo.AR_AllocSpec (NOLOCK) AS AR_AllocSpec_1 ON CB_Receipt_1.AllocSpecID = AR_AllocSpec_1.AllocSpecID LEFT OUTER JOIN
      dbo.CF_Financier (NOLOCK) AS CF_Financier ON CB_Receipt_1.PaidByOthersID = CF_Financier.FinancierID LEFT OUTER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_2 ON CF_Financier.AccountID = CF_Account_2.AccountID LEFT OUTER JOIN
      dbo.View_CF_User AS A ON CB_Receipt_1.BankInByID = A.UserID LEFT OUTER JOIN
      dbo.CF_BankAccount (NOLOCK) cba ON CB_Receipt_1.BankAccountID=cba.BankAccountID
      --LEFT JOIN (SELECT DocumentNo, ISNULL(SUM(TaxAmt),0) AS TaxAmt  FROM ar_trx (NOLOCK) WHERE RecordStatus <> 'Inactive' GROUP BY DocumentNo) AS artrx
   LEFT JOIN dbo.View_CF_User (NOLOCK) AS cu ON CB_Receipt_1.createuserid=cu.UserID
   LEFT JOIN (SELECT aa.ReceiptID, ISNULL(SUM(at.TaxAmt),0) AS TaxAmt FROM ar_allocation(NOLOCK)  aa inner join ar_trx (NOLOCK) at on at.billid=aa.billid WHERE at.RecordStatus <> 'Inactive' and aa.RecordStatus <> 'Inactive'  GROUP BY aa.ReceiptID) AS artrx
      ON artrx.ReceiptID = CB_Receipt_1.cbreceiptid
WHERE (CB_Receipt_1.DebtorID IS NULL) AND (CB_Receipt_1.CreditorID IS NULL) AND CB_Receipt_1.RecordStatus <> 'Voided'
UNION ALL
SELECT     CB_Receipt_2.CBReceiptID, CB_Receipt_2.CompanyID, CB_Receipt_2.DocNo, CB_Receipt_2.BankAccountID,
      dbo.GetBankName(CB_Receipt_2.BankAccountID) AS BankName,cba.BankCode, CB_Receipt_2.CreditorID AS DebtorID, CASE WHEN CF_Account_1.Name = 'Other Receivable' THEN CB_Receipt_2.PaidBy ELSE CF_Account_1.Name END AS Debtor,
      'N' AS IsDebtor, 'CommonN' AS IsDebtorStringCode, CB_Receipt_2.PaidByOthersID, --CF_Account_2.Name AS PaidByOthers,
   CASE WHEN CF_Account_2.Name IS NULL THEN CB_Receipt_2.PaidBy ELSE CF_Account_2.Name END AS PaidByOthers,
   CB_Receipt_2.PaidBy,
      CB_Receipt_2.ReferenceNo, CB_Receipt_2.AllocSpecID, AR_AllocSpec_2.Name AS AllocSpecName, CB_Receipt_2.BankInByID,
      A.EmployeeName AS BankInBy, CB_Receipt_2.BankInDate,
      CASE WHEN pd.RefTable ='PM_Tender' THEN 'TenderDeposit' WHEN pd.RefTable ='PM_SubContract' THEN 'CM_Deposit' ELSE CB_Receipt_2.ReceiptType END AS ReceiptType,
      (CASE WHEN pd.RefTable='PM_Tender' THEN 'ElemenCode_TenderDeposit' WHEN pd.RefTable ='PM_SubContract' THEN 'CM_Deposit' ELSE CF_PopupLstElement_3.TitleStringCode END) AS ReceiptTypeStringCode,
      --CF_PopupLstElement_3.TitleStringCode AS ReceiptTypeStringCode,
      CB_Receipt_2.PayMethod,
      CF_PopupLstElement_1.TitleStringCode AS PayMethodStringCode, CB_Receipt_2.DocumentDate, CB_Receipt_2.TransactionDate,
      CB_Receipt_2.CurrencyID, CF_Currency_2.ISOCode AS Currency, CF_Currency_2.Name AS CurrencyName, CB_Receipt_2.ExchangeRate,
      CB_Receipt_2.DocumentAmt,CB_Receipt_2.BaseAmt, CB_Receipt_2.AllocBalance, CB_Receipt_2.TaxInvoiceNo, CB_Receipt_2.TaxInvoiceDate,
      CB_Receipt_2.Remark, CB_Receipt_2.VoidDate, CB_Receipt_2.VoidUserID, View_CF_User_2.EmployeeName AS VoidUser,
      CB_Receipt_2.RecordStatus
      --, ISNULL(CB_Trx_2.AdminChargeAmt, 0) AS AdminChargeAmt,
      ,CB_Receipt_2.BankCharge AS AdminChargeAmt
      ,'Receipt' + CB_Receipt_2.RecordStatus AS RecordStatusStringCode,ChequeIssueDate,ChequeExpiryDate,
          case when CB_Receipt_2.ActualAmt=0 or CB_Receipt_2.ActualAmt is null then CB_Receipt_2.DocumentAmt else CB_Receipt_2.ActualAmt end  as ActualAmt,
          case when CB_Receipt_2.ActualBaseAmt=0 or CB_Receipt_2.ActualBaseAmt is null then CB_Receipt_2.BaseAmt else CB_Receipt_2.ActualBaseAmt end  as ActualBaseAmt,CB_Receipt_2.cbtrxid
          ,CB_Receipt_2.CreditCardTypeID ,cba.AccountNo,CB_Receipt_2.CreateDate,ISNULL(artrx.TaxAmt,0) AS TaxAmt,  cu.LoginName,
          (SELECT TOP 1 A.TaxID FROM AR_Allocation (NOLOCK) AS alloc LEFT JOIN dbo.AR_Trx (NOLOCK) AS A  ON A.BillID = alloc.BillID LEFT JOIN dbo.CF_Tax (NOLOCK) AS C ON A.TaxID = C.TaxID WHERE CB_Receipt_2.CBReceiptID=alloc.ReceiptID AND C.TaxCode <> 'N/A' GROUP BY alloc.ReceiptID, A.TaxID) AS TaxID,
    CB_Receipt_2.IsCustomer, CB_Receipt_2.DebtorName, CB_Receipt_2.DebtorGSTNo, CB_Receipt_2.DebtorROCNo
          -- LKHS-325 GIRO: GIRO columns for Collection Verification (criteria / grid / Cancel button rule)
          ,ISNULL(CB_Receipt_2.IsGiroReceipt, 'N') AS IsGiroReceipt, CB_Receipt_2.GroupNo, CB_Receipt_2.GIRORecordStatus
FROM dbo.CB_Receipt (NOLOCK) AS CB_Receipt_2 INNER JOIN
      dbo.AP_Creditor (NOLOCK) ON dbo.AP_Creditor.CreditorID = CB_Receipt_2.CreditorID INNER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_1 ON dbo.AP_Creditor.AccountID = CF_Account_1.AccountID INNER JOIN
      dbo.CF_Currency (NOLOCK) AS CF_Currency_2 ON CB_Receipt_2.CurrencyID = CF_Currency_2.CurrencyID INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_1 ON CB_Receipt_2.PayMethod = CF_PopupLstElement_1.PopupLstElementID INNER JOIN
      dbo.CF_PopupLstElement (NOLOCK) AS CF_PopupLstElement_3 ON CB_Receipt_2.ReceiptType = CF_PopupLstElement_3.ElementCode inner join
      cf_Popuplst (NOLOCK) on CF_PopupLstElement_3.popuplstid=cf_Popuplst.popuplstid and cf_Popuplst.[Type]='MC_ReceiptType'
      INNER JOIN dbo.CF_XRef (NOLOCK) AS ref ON CB_Receipt_2.CBReceiptID=ref.ToRefRecordID AND ToRefTable='CB_Receipt' AND ref.FromRefTable='PM_Deposit'
      INNER JOIN dbo.PM_Deposit (NOLOCK) AS pd ON ref.FromRefRecordID=pd.DepositID AND ref.FromRefTable='PM_Deposit'  LEFT OUTER JOIN
      dbo.View_CF_User AS View_CF_User_2 ON CB_Receipt_2.VoidUserID = View_CF_User_2.UserID LEFT OUTER JOIN
      dbo.AR_AllocSpec (NOLOCK) AS AR_AllocSpec_2 ON CB_Receipt_2.AllocSpecID = AR_AllocSpec_2.AllocSpecID LEFT OUTER JOIN
      dbo.CF_Financier (NOLOCK) AS CF_Financier ON CB_Receipt_2.PaidByOthersID = CF_Financier.FinancierID LEFT OUTER JOIN
      dbo.CF_Account (NOLOCK) AS CF_Account_2 ON CF_Financier.AccountID = CF_Account_2.AccountID LEFT OUTER JOIN
      dbo.View_CF_User AS A ON CB_Receipt_2.BankInByID = A.UserID LEFT OUTER JOIN
      dbo.CF_BankAccount (NOLOCK) cba ON CB_Receipt_2.BankAccountID=cba.BankAccountID
      --LEFT JOIN (SELECT DocumentNo, ISNULL(SUM(TaxAmt),0) AS TaxAmt FROM ar_trx (NOLOCK) WHERE RecordStatus <> 'Inactive' GROUP BY DocumentNo) AS artrx
   LEFT JOIN dbo.View_CF_User (NOLOCK) AS cu ON CB_Receipt_2.createuserid=cu.UserID
   LEFT JOIN (SELECT aa.ReceiptID, ISNULL(SUM(at.TaxAmt),0) AS TaxAmt FROM ar_allocation(NOLOCK)  aa inner join ar_trx (NOLOCK) at on at.billid=aa.billid WHERE at.RecordStatus <> 'Inactive' and aa.RecordStatus <> 'Inactive'  GROUP BY aa.ReceiptID) AS artrx
      ON artrx.ReceiptID = CB_Receipt_2.cbreceiptid
WHERE (CB_Receipt_2.DebtorID IS NULL) AND CB_Receipt_2.ReceiptType='PM_Deposit' AND CB_Receipt_2.RecordStatus <> 'Voided'
GO

-- Check
SELECT TOP 20 CBReceiptID, DocNo, RecordStatus, IsGiroReceipt, GroupNo, GIRORecordStatus FROM dbo.View_AC_Receipt WHERE IsGiroReceipt = 'Y' ORDER BY CBReceiptID DESC;
