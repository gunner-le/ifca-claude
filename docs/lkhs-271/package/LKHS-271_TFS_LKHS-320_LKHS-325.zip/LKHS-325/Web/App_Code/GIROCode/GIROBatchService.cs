using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Web.Common;
using IFCA.Business.Finance.Generic;

// LKHS-325 - GIRO Batch (step 7) - GIRO Batch Generation (popup ARGIROBatchGenerate.aspx, from Collection Verification)
// Stanley call 04/11: popup opens blank, user selects the GIRO bank -> all GIRO receipts 'Generated' of this bank are listed,
// user ticks receipts, keys in Reference No / Payment Date / Purpose -> Save = one new batch (GroupNo = DocCode 316_ReceiptGroup).
// Reference No / Payment Date are keyed in on the popup (Stanley doc: Textbox / Datetime) and used ONLY in the DBS file (D34 / D08);
// receipts keep the values of step 6 (Gunner 05/11: no overwrite - confusing on Collection Verification, not restored by Reset).
//
// Save, in ONE transaction:
//   1. lock + re-read the ticked receipts (still Generated / Active / same company + bank)
//   2. build the UFF file (GIROUffDbs) - all validation errors shown at once, nothing saved
//   3. GroupNo, insert CB_ReceiptGroup (Exported) + CB_ReceiptGroupDetail, update CB_Receipt (GroupNo, Exported)
//   4. audit log 'Generate'
//   5. write the file to CF_CompanyGiroBank.ARExportPath; error -> rollback (no batch without file)

public class GIROBatchRequest
{
    public int CompanyID;
    public int BankAccountID;          // CF_CompanyGiroBank.GiroBankAccountID
    public List<int> ReceiptIDs = new List<int>();
    public string ReferenceNo;         // D34
    public DateTime PaymentDate;       // D08
    public string PurposeCode;         // D43
    public int UserID;
}

public class GIROBatchResult
{
    public int ReceiptGroupID;
    public string GroupNo;
    public string FileName;
    public string FilePath;
    public int ReceiptCount;
    public int LineCount;              // debtors = lines in the file
    public decimal TotalAmt;
}

/// <summary>Company GIRO bank setup (CF_CompanyGiroBank + CF_BankAccount).</summary>
public class GIROBankSetup
{
    public int BankAccountID;
    public string AccountNo;
    public string BankName;
    public int CurrencyID;
    public string CurrencyCode;
    public string OrganizationID;
    public string OrganizationName;
    public string ARExportPath;
    public string ARImportPath;
}

/// <summary>One receipt of the batch in the Pre-Check screen.</summary>
public class GIROPreCheckLine
{
    public int ReceiptID;
    public int DebtorID;
    public string GIROStatus;          // Success / Failed
    public string ReturnReason;        // DBS reject reason (Failed)
}

public class GIROPreCheckResult
{
    public int ReceiptGroupID;
    public string FileName;            // null = Verify (no DBS return file)
    public List<GIROPreCheckLine> Lines = new List<GIROPreCheckLine>();
    public List<string> Unmatched = new List<string>();   // records of the file not in the batch
    public List<string> Errors = new List<string>();      // not empty -> Confirm blocked
    public bool CanConfirm { get { return Errors.Count == 0; } }
}

public class GIROBatchService
{
    public const string DocCode = "316_ReceiptGroup";
    public const string StatusGenerated = "Generated";
    public const string StatusExported = "Exported";

    /// <summary>Active GIRO banks of the company (popup Bank dropdown).</summary>
    public static DataTable GetCompanyBanks(int companyID)
    {
        return DataAccessHelper.ExecuteDataTable(string.Format(@"
            select cgb.GiroBankAccountID as BankAccountID, ba.AccountNo, ca.Name as BankName, ba.CurrencyID, c.ISOCode as Currency
            from CF_CompanyGiroBank cgb
                 inner join CF_BankAccount ba on ba.BankAccountID = cgb.GiroBankAccountID
                 left join CF_Account ca on ca.AccountID = ba.AccountID
                 left join CF_Currency c on c.CurrencyID = ba.CurrencyID
            where cgb.CompanyID = {0} and cgb.RecordStatus = 'Active' and cgb.GiroBankAccountID is not null
            order by ca.Name, ba.AccountNo", companyID));
    }

    /// <summary>DBS Purpose Code list (View_CB_GIROLookup, popup Purpose dropdown).</summary>
    public static DataTable GetPurposeCodes()
    {
        return DataAccessHelper.ExecuteDataTable(
            "select LookupCode, LookupName from View_CB_GIROLookup where LookupType = 'PURPOSE' and RecordStatus = 'Active' order by LookupCode");
    }

    public GIROBatchResult CreateBatch(GIROBatchRequest req)
    {
        // ---- input ----
        List<string> errors = new List<string>();
        string refNo = (req.ReferenceNo ?? "").Trim();
        string purpose = (req.PurposeCode ?? "").Trim();
        if (req.BankAccountID <= 0) errors.Add(Strings.GetString("CB.GIROBatch_BankRequired"));
        if (refNo == "") errors.Add(Strings.GetString("CB.GIRO_ReferenceNoRequired"));
        if (req.PaymentDate == DateTime.MinValue) errors.Add(Strings.GetString("CB.GIRO_PaymentDateRequired"));
        else if (req.PaymentDate.Date < DateTime.Today) errors.Add(Strings.GetString("CB.GIRO_PaymentDateMustNotPast"));
        if (purpose == "") errors.Add(Strings.GetString("CB.GIROBatch_PurposeRequired"));
        List<int> ids = req.ReceiptIDs == null ? new List<int>() : req.ReceiptIDs.Where(i => i > 0).Distinct().ToList();
        if (ids.Count == 0) errors.Add(Strings.GetString("CB.GIROBatch_NoReceipt"));
        if (errors.Count > 0) throw new GIROException(string.Join("<br>", errors.ToArray()));

        GIROBankSetup bank = LoadBank(req.CompanyID, req.BankAccountID);
        if (bank == null) throw new GIROException(Strings.GetString("CB.GIROBatch_BankNotSetup"));
        if (string.IsNullOrEmpty(bank.ARExportPath) || bank.ARExportPath.Trim().Trim('\\', '/') == "")
            throw new GIROException(Strings.GetString("CB.GIROBatch_ExportPathRequired"));

        string idList = string.Join(",", ids.Select(i => i.ToString()).ToArray());   // ints only
        SysCodeCollection docCode = null;
        string fullPath = null;
        bool fileWritten = false;

        DbConnection con = DataAccessHelper.CreateConnection();
        con.Open();
        DbTransaction tran = con.BeginTransaction();
        try
        {
            // 1. lock + re-read
            DataTable rcp = GIRODb.Table(tran, string.Format(@"
                select r.CBReceiptID, r.DocNo, r.DocumentDate
                from CB_Receipt r with (updlock, rowlock)
                where r.CBReceiptID in ({0}) and r.CompanyID = @CompanyID and r.BankAccountID = @BankAccountID
                  and r.IsGiroReceipt = 'Y' and r.GIRORecordStatus = @Generated and r.RecordStatus = 'Active'
                  and isnull(r.GroupNo, '') = ''", idList),
                "@CompanyID", req.CompanyID, "@BankAccountID", req.BankAccountID, "@Generated", StatusGenerated);
            if (rcp.Rows.Count != ids.Count)
            {
                HashSet<int> ok = new HashSet<int>(rcp.Rows.Cast<DataRow>().Select(r => Convert.ToInt32(r["CBReceiptID"])));
                List<string> docs = new List<string>();
                foreach (DataRow r in GIRODb.Table(tran, string.Format("select CBReceiptID, DocNo from CB_Receipt where CBReceiptID in ({0})", idList)).Rows)
                    if (!ok.Contains(Convert.ToInt32(r["CBReceiptID"]))) docs.Add(Convert.ToString(r["DocNo"]));
                throw new GIROException(Strings.GetString("CB.GIROBatch_ReceiptChanged") + "<br>" + string.Join(", ", docs.ToArray()));
            }

            // 2. data of the file
            DataTable dt = GIRODb.Table(tran, string.Format(@"
                select CBReceiptID, DebtorID, DebtorName, GiroAccountNo, SwiftCode, IdentityNo, ReceiptAmt
                from View_CB_Receipt_GIRO where CBReceiptID in ({0}) order by DebtorName, DocumentNo", idList));
            Dictionary<int, List<string>> invoices = LoadInvoiceNos(tran, idList);

            docCode = new SysCodeCollection(DocCode, DocAnchorType.Company, req.CompanyID, 1);
            string groupNo = docCode[0] == null ? "" : docCode[0].ToString();
            if (string.IsNullOrEmpty(groupNo))       // framework returns "" when the company has no format for the DocCode
                throw new GIROException(string.Format(Strings.GetString("CB.GIROBatch_NoNumberStructure"), DocCode));

            GIROUffBatch b = new GIROUffBatch();
            b.FileCreationDate = DateTime.Now;
            b.OrganizationID = bank.OrganizationID;
            b.OrganizationName = bank.OrganizationName;
            b.OriginatingAccountNo = bank.AccountNo;
            b.CurrencyCode = bank.CurrencyCode;
            b.BatchID = groupNo;
            b.PaymentDate = req.PaymentDate.Date;
            b.ReferenceNo = refNo;
            b.PurposeCode = purpose;
            b.AllowBlankIdentityNo = false;     // D35 Mandatory: CF_Account.IdentityNo (debtor account profile) - blank -> batch blocked (Gunner 09/11)
            foreach (DataRow r in dt.Rows)
            {
                GIROUffReceipt u = new GIROUffReceipt();
                u.ReceiptID = Convert.ToInt32(r["CBReceiptID"]);
                u.DebtorID = Convert.ToInt32(r["DebtorID"]);
                u.DebtorName = Convert.ToString(r["DebtorName"]);
                u.GiroAccountNo = Convert.ToString(r["GiroAccountNo"]);
                u.SwiftCode = Convert.ToString(r["SwiftCode"]);
                u.IdentityNo = Convert.ToString(r["IdentityNo"]);
                u.Amount = Convert.ToDecimal(r["ReceiptAmt"]);
                if (invoices.ContainsKey(u.ReceiptID)) u.InvoiceNos = invoices[u.ReceiptID];
                b.Receipts.Add(u);
            }
            GIROUffResult file = GIROUffDbs.Build(b);     // throws GIROException with every problem found

            string fileName = MakeFileName(bank.OrganizationID, GIROUffDbs.FormatBatchID(groupNo));   // already validated by Build
            DateTime now = DateTime.Now;

            // 3. batch + receipts
            int groupID = Convert.ToInt32(GIRODb.Scalar(tran, @"
                insert into CB_ReceiptGroup (GroupNo, DocumentDate, RecordType, RecordStatus, CompanyID, BankAccountID, CurrencyID,
                                             ReferenceNo, PurposeCode, Filename, CreateUserID, CreateDate, ModifyUserID, ModifyDate)
                values (@GroupNo, @DocumentDate, 'GIRO', @Status, @CompanyID, @BankAccountID, @CurrencyID,
                        @ReferenceNo, @PurposeCode, @Filename, @UserID, @Now, @UserID, @Now);
                select cast(scope_identity() as int);",
                "@GroupNo", groupNo, "@DocumentDate", req.PaymentDate.Date, "@Status", StatusExported, "@CompanyID", req.CompanyID,
                "@BankAccountID", req.BankAccountID, "@CurrencyID", bank.CurrencyID, "@ReferenceNo", refNo, "@PurposeCode", purpose,
                "@Filename", fileName, "@UserID", req.UserID, "@Now", now));

            GIRODb.Execute(tran, string.Format(@"
                insert into CB_ReceiptGroupDetail (ReceiptGroupID, ReceiptID, RecordStatus, CreateUserID, CreateDate, ModifyUserID, ModifyDate)
                select @GroupID, r.CBReceiptID, 'Active', @UserID, @Now, @UserID, @Now
                from CB_Receipt r where r.CBReceiptID in ({0});", idList),
                "@GroupID", groupID, "@UserID", req.UserID, "@Now", now);

            GIRODb.Execute(tran, string.Format(@"
                update CB_Receipt set GroupNo = @GroupNo, GIRORecordStatus = @Status, ModifyUserID = @UserID, ModifyDate = @Now
                where CBReceiptID in ({0});", idList),
                "@GroupNo", groupNo, "@Status", StatusExported, "@UserID", req.UserID, "@Now", now);

            // 4. audit log
            WriteAuditLog(tran, groupID, req.UserID, "Generate",
                string.Format("{0} receipt(s), {1} line(s), total {2}, file {3}", ids.Count, file.Lines.Count, GIROUffDbs.FormatAmount(file.TotalAmount), fileName));

            // 5. file, then commit
            fullPath = Path.Combine(bank.ARExportPath.Trim(), fileName);
            try
            {
                File.WriteAllBytes(fullPath, file.GetBytes());
                fileWritten = true;
            }
            catch (Exception ex)
            {
                throw new GIROException(string.Format(Strings.GetString("CB.GIROBatch_ExportFailed"), bank.ARExportPath) + "<br>" + ex.Message);
            }

            docCode.Submit(tran);
            tran.Commit();

            GIROBatchResult res = new GIROBatchResult();
            res.ReceiptGroupID = groupID;
            res.GroupNo = groupNo;
            res.FileName = fileName;
            res.FilePath = fullPath;
            res.ReceiptCount = ids.Count;
            res.LineCount = file.Lines.Count;
            res.TotalAmt = file.TotalAmount;
            return res;
        }
        catch
        {
            if (docCode != null) { try { docCode.Cancel(tran); } catch { } }
            try { tran.Rollback(); } catch { }
            if (fileWritten) { try { File.Delete(fullPath); } catch { } }
            throw;
        }
        finally
        {
            con.Close();
        }
    }

    // ===================================================================================
    // GIRO Batch Listing: Reset (dot 2b) / Import, Verify -> Pre-Check -> Confirm (v01.01). One batch per action.
    // ===================================================================================
    public const string StatusCompleted = "Completed";   // batch status (receipt: Success / Failed)
    public const string StatusCancel = "Cancel";

    /// <summary>Reset: batch -> Cancel (not listed any more), receipts back to Generated (GroupNo cleared)
    /// so they can go into another batch. Exported file is kept (it may already be uploaded to DBS).
    /// Reference No / Payment Date copied from the batch stay on the receipts.</summary>
    public string ResetBatch(int receiptGroupID, int userID)
    {
        DbConnection con = DataAccessHelper.CreateConnection();
        con.Open();
        DbTransaction tran = con.BeginTransaction();
        try
        {
            DataRow g = LockBatch(tran, receiptGroupID);
            string groupNo = Convert.ToString(g["GroupNo"]);
            DateTime now = DateTime.Now;

            int receipts = GIRODb.Execute(tran, @"
                update r set r.GroupNo = null, r.GIRORecordStatus = @Generated, r.ModifyUserID = @UserID, r.ModifyDate = @Now
                from CB_Receipt r inner join CB_ReceiptGroupDetail d on d.ReceiptID = r.CBReceiptID
                where d.ReceiptGroupID = @GroupID and d.RecordStatus <> 'Cancel'
                  and r.GroupNo = @GroupNo and r.GIRORecordStatus = @Exported",
                "@Generated", StatusGenerated, "@UserID", userID, "@Now", now, "@GroupID", receiptGroupID,
                "@GroupNo", groupNo, "@Exported", StatusExported);

            GIRODb.Execute(tran, @"
                update CB_ReceiptGroupDetail set RecordStatus = @Cancel, ModifyUserID = @UserID, ModifyDate = @Now
                where ReceiptGroupID = @GroupID and RecordStatus <> @Cancel;
                update CB_ReceiptGroup set RecordStatus = @Cancel, ModifyUserID = @UserID, ModifyDate = @Now
                where CBReceiptGroupID = @GroupID;",
                "@Cancel", StatusCancel, "@UserID", userID, "@Now", now, "@GroupID", receiptGroupID);

            WriteAuditLog(tran, receiptGroupID, userID, "Reset",
                string.Format("Batch {0}: {1} receipt(s) back to Generated, file {2} kept", groupNo, receipts, g["Filename"]));
            tran.Commit();
            return string.Format(Strings.GetString("CB.GIROBatch_ResetSuccess"), groupNo, receipts);
        }
        catch
        {
            try { tran.Rollback(); } catch { }
            throw;
        }
        finally
        {
            con.Close();
        }
    }

    // ===================================================================================
    // Import / Verify -> GIRO Batch Pre-Check -> Confirm (Stanley doc v01.01, 06/11)
    //   Import : user picks a CSV in the Import Path -> receipts of debtors in the file = Failed, others = Success
    //   Verify : no file (DBS sends no file when all succeed) -> all Success
    //   Confirm: batch Completed; Success -> GIRORecordStatus Success + Verified (same update as ACReceiptVerify);
    //            Failed -> GIRORecordStatus Failed + Cancel Receipt Action (dot 2c, not available yet)
    // ===================================================================================
    public const string StatusSuccess = "Success";
    public const string StatusFailed = "Failed";

    /// <summary>Files of the Import Path of the batch's GIRO bank (Upload Screen lists all of them, Stanley 06/11).</summary>
    public static List<string> ListImportFiles(int receiptGroupID)
    {
        string path = GetImportPath(receiptGroupID);
        List<string> files = new List<string>();
        foreach (string f in Directory.GetFiles(path).OrderByDescending(x => File.GetLastWriteTime(x)))
            files.Add(Path.GetFileName(f));
        return files;
    }

    /// <summary>Pre-Check: receipts of the batch with their GIRO Status (and blocking errors for Confirm).</summary>
    public static GIROPreCheckResult GetPreCheck(int receiptGroupID, string fileName)
    {
        return BuildPreCheck(null, receiptGroupID, fileName);
    }

    /// <summary>Confirm of the Pre-Check: everything re-checked on the server inside the transaction.</summary>
    public string ConfirmBatch(int receiptGroupID, string fileName, int userID)
    {
        DbConnection con = DataAccessHelper.CreateConnection();
        con.Open();
        DbTransaction tran = con.BeginTransaction();
        try
        {
            DataRow g = LockBatch(tran, receiptGroupID);
            string groupNo = Convert.ToString(g["GroupNo"]);
            DateTime paymentDate = Convert.ToDateTime(g["DocumentDate"]);
            if (paymentDate.Date > DateTime.Today)
                throw new GIROException(string.Format(Strings.GetString("CB.GIROBatch_ConfirmBeforePaymentDate"), groupNo, paymentDate.ToString("dd/MM/yyyy")));

            // every receipt of the batch must still be Active + Exported (not voided / verified elsewhere)
            DataTable bad = GIRODb.Table(tran, @"
                select r.DocNo from CB_Receipt r with (updlock, rowlock)
                inner join CB_ReceiptGroupDetail d on d.ReceiptID = r.CBReceiptID
                where d.ReceiptGroupID = @GroupID and d.RecordStatus <> 'Cancel'
                  and (r.RecordStatus <> 'Active' or isnull(r.GIRORecordStatus, '') <> @Exported or isnull(r.GroupNo, '') <> @GroupNo)",
                "@GroupID", receiptGroupID, "@Exported", StatusExported, "@GroupNo", groupNo);
            if (bad.Rows.Count > 0)
            {
                List<string> docs = new List<string>();
                foreach (DataRow r in bad.Rows) docs.Add(Convert.ToString(r["DocNo"]));
                throw new GIROException(Strings.GetString("CB.GIROBatch_ReceiptNotExported") + "<br>" + string.Join(", ", docs.ToArray()));
            }

            GIROPreCheckResult pc = BuildPreCheck(tran, receiptGroupID, fileName);
            if (pc.Errors.Count > 0)
                throw new GIROException(string.Join("<br>", pc.Errors.ToArray()));

            List<int> success = pc.Lines.Where(l => l.GIROStatus == StatusSuccess).Select(l => l.ReceiptID).ToList();
            List<int> failed = pc.Lines.Where(l => l.GIROStatus == StatusFailed).Select(l => l.ReceiptID).ToList();
            DateTime now = DateTime.Now;

            // Failed (in the DBS file): GIRORecordStatus Failed + reject reason, then Cancel Receipt Action of the module
            foreach (GIROPreCheckLine l in pc.Lines.Where(x => x.GIROStatus == StatusFailed))
            {
                string reason = l.ReturnReason ?? "";
                CancelReceipt(tran, l.ReceiptID, userID, now,
                    string.Format(Strings.GetString("CB.GIROCancel_RemarkRejected"), groupNo, reason));
                GIRODb.Execute(tran, @"
                    update CB_Receipt set GIRORecordStatus = @Failed where CBReceiptID = @ID;
                    update CB_ReceiptGroupDetail set ReturnReason = @Reason, ModifyUserID = @UserID, ModifyDate = @Now
                    where ReceiptGroupID = @GroupID and ReceiptID = @ID and RecordStatus <> 'Cancel';",
                    "@Failed", StatusFailed, "@ID", l.ReceiptID, "@Reason", reason.Length > 255 ? reason.Substring(0, 255) : reason,
                    "@UserID", userID, "@Now", now, "@GroupID", receiptGroupID);
            }
            if (success.Count > 0)
            {
                string ids = string.Join(",", success.Select(i => i.ToString()).ToArray());
                GIRODb.Execute(tran, string.Format(@"
                    update CB_Receipt set RecordStatus = 'Verified', GIRORecordStatus = @Success, ModifyUserID = @UserID, ModifyDate = @Now
                    where CBReceiptID in ({0});", ids),
                    "@Success", StatusSuccess, "@UserID", userID, "@Now", now);
            }

            GIRODb.Execute(tran, @"
                update CB_ReceiptGroup set RecordStatus = @Completed, ModifyUserID = @UserID, ModifyDate = @Now
                where CBReceiptGroupID = @GroupID;",
                "@Completed", StatusCompleted, "@UserID", userID, "@Now", now, "@GroupID", receiptGroupID);

            bool isImport = !string.IsNullOrEmpty(fileName);
            WriteAuditLog(tran, receiptGroupID, userID, isImport ? "Import" : "Verify",
                string.Format("Batch {0}: {1} success, {2} failed{3}", groupNo, success.Count, failed.Count,
                    isImport ? ", file " + fileName : " (no DBS return file)"));
            tran.Commit();
            return string.Format(Strings.GetString("CB.GIROBatch_ConfirmSuccess"), groupNo, success.Count, failed.Count);
        }
        catch
        {
            try { tran.Rollback(); } catch { }
            throw;
        }
        finally
        {
            con.Close();
        }
    }

    // ===================================================================================
    // Cancel Receipt Action (Stanley doc): CB_Receipt Voided, release AR_Allocation, recalculate bill balance.
    // Done by the module handler (same steps as the module's own void / delete screen), always in the caller's transaction.
    // ===================================================================================
    public const string StatusCancel_Receipt = "Cancel";

    private static void CancelReceipt(DbTransaction tran, int receiptID, int userID, DateTime voidDate, string remark)
    {
        DataTable dt = GIRODb.Table(tran, "select CBReceiptID, DocNo, CompanyID, ReceiptType from CB_Receipt with (updlock, rowlock) where CBReceiptID = @ID",
            "@ID", receiptID);
        if (dt == null || dt.Rows.Count == 0)
            throw new GIROException(Strings.GetString("CB.GIROBatch_NotFound"));
        DataRow r = dt.Rows[0];
        string receiptType = Convert.ToString(r["ReceiptType"]);
        if (!GIROCollectionGenerator.Handlers.ContainsKey(receiptType))
            throw new GIROException(string.Format(Strings.GetString("CB.GIRO_ModuleNotSupported"), receiptType));

        GIROCancelContext ctx = new GIROCancelContext();
        ctx.ReceiptID = receiptID;
        ctx.DocNo = Convert.ToString(r["DocNo"]);
        ctx.CompanyID = Convert.ToInt32(r["CompanyID"]);
        ctx.VoidDate = voidDate;
        ctx.UserID = userID;
        ctx.VoidRemark = remark;
        GIROCollectionGenerator.Handlers[receiptType].CancelReceipt(tran, ctx);
    }

    /// <summary>Cancel button of Collection Verification (Stanley doc: only GIRO receipts, Group No empty, Generated):
    /// Cancel Receipt Action for each ticked receipt, GIRORecordStatus Cancel. All or nothing.</summary>
    public string CancelGeneratedReceipts(string receiptIDs, int userID)
    {
        List<int> ids = new List<int>();
        foreach (string x in (receiptIDs ?? "").Split(','))
        {
            int id;
            if (int.TryParse(x.Trim(), out id) && id > 0 && !ids.Contains(id)) ids.Add(id);
        }
        if (ids.Count == 0) throw new GIROException(Strings.GetString("MustSelectReceipt"));
        string idList = string.Join(",", ids.Select(i => i.ToString()).ToArray());   // ints only

        DbConnection con = DataAccessHelper.CreateConnection();
        con.Open();
        DbTransaction tran = con.BeginTransaction();
        try
        {
            DataTable dt = GIRODb.Table(tran, string.Format(@"
                select CBReceiptID, DocNo, IsGiroReceipt, GIRORecordStatus, GroupNo, RecordStatus
                from CB_Receipt with (updlock, rowlock) where CBReceiptID in ({0}) order by DocNo", idList));
            List<string> bad = new List<string>();
            foreach (DataRow r in dt.Rows)
            {
                if (Convert.ToString(r["IsGiroReceipt"]) != "Y" || Convert.ToString(r["GIRORecordStatus"]) != StatusGenerated
                    || Convert.ToString(r["GroupNo"]).Trim() != "" || Convert.ToString(r["RecordStatus"]) != "Active")
                    bad.Add(Convert.ToString(r["DocNo"]));
            }
            if (bad.Count > 0 || dt.Rows.Count != ids.Count)
                throw new GIROException(Strings.GetString("CB.GIROCancel_OnlyGenerated") + "<br>" + string.Join(", ", bad.ToArray()));

            DateTime now = DateTime.Now;
            List<string> docs = new List<string>();
            foreach (DataRow r in dt.Rows)
            {
                int id = Convert.ToInt32(r["CBReceiptID"]);
                CancelReceipt(tran, id, userID, now, Strings.GetString("CB.GIROCancel_RemarkVerification"));
                GIRODb.Execute(tran, "update CB_Receipt set GIRORecordStatus = @Cancel where CBReceiptID = @ID",
                    "@Cancel", StatusCancel_Receipt, "@ID", id);
                docs.Add(Convert.ToString(r["DocNo"]));
            }
            WriteAuditLog(tran, null, userID, "Cancel", "Collection Verification cancel: " + string.Join(", ", docs.ToArray()));
            tran.Commit();
            return string.Format(Strings.GetString("CB.GIROCancel_Success"), docs.Count) + "<br>" + string.Join(", ", docs.ToArray());
        }
        catch
        {
            try { tran.Rollback(); } catch { }
            throw;
        }
        finally
        {
            con.Close();
        }
    }

    // tran = null: read only (Pre-Check page); in Confirm the same check runs inside the transaction
    private static GIROPreCheckResult BuildPreCheck(DbTransaction tran, int receiptGroupID, string fileName)
    {
        GIROPreCheckResult res = new GIROPreCheckResult();
        res.ReceiptGroupID = receiptGroupID;
        res.FileName = fileName;

        DataTable dt = Query(tran, @"
            select r.CBReceiptID, r.DebtorID, r.DebtorName, r.GiroAccountNo, r.SwiftCode, r.IdentityNo, r.ReceiptAmt, r.DocumentNo
            from View_CB_Receipt_GIRO r
                 inner join CB_ReceiptGroupDetail d on d.ReceiptID = r.CBReceiptID
            where d.ReceiptGroupID = @GroupID and d.RecordStatus <> 'Cancel'
            order by r.DebtorName, r.DocumentNo", "@GroupID", receiptGroupID);

        List<GIROUffReceipt> receipts = new List<GIROUffReceipt>();
        foreach (DataRow r in dt.Rows)
        {
            GIROUffReceipt u = new GIROUffReceipt();
            u.ReceiptID = Convert.ToInt32(r["CBReceiptID"]);
            u.DebtorID = Convert.ToInt32(r["DebtorID"]);
            u.DebtorName = Convert.ToString(r["DebtorName"]);
            u.GiroAccountNo = Convert.ToString(r["GiroAccountNo"]);
            u.Amount = Convert.ToDecimal(r["ReceiptAmt"]);
            receipts.Add(u);
            GIROPreCheckLine line = new GIROPreCheckLine();
            line.ReceiptID = u.ReceiptID;
            line.DebtorID = u.DebtorID;
            line.GIROStatus = StatusSuccess;      // default (doc: not matched / no attachment -> Success)
            res.Lines.Add(line);
        }
        if (receipts.Count == 0)
            res.Errors.Add(Strings.GetString("CB.GIROBatch_NoReceiptInBatch"));

        if (!string.IsNullOrEmpty(fileName))
        {
            string name = Path.GetFileName(fileName);
            string path = GetImportPath(receiptGroupID);
            string full = Path.Combine(path, name);
            if (name != fileName || !File.Exists(full))
            {
                res.Errors.Add(string.Format(Strings.GetString("CB.GIROBatch_FileNotFound"), fileName));
                return res;
            }

            GIROReturnFile file = GIROReturnFileDbs.ParseCsv(name, File.ReadAllBytes(full));
            res.Errors.AddRange(file.Errors);

            // every record of the file must match a debtor line of this batch (Stanley 06/11), else Confirm blocked
            List<GIROUffLine> lines = GIROUffDbs.GroupByDebtor(receipts);
            GIROReturnMatch m = GIROReturnFileDbs.Match(file, lines);
            foreach (GIROReturnRow row in m.Unmatched)
                res.Unmatched.Add(string.Format("Row {0}: {1} / {2} / {3}", row.RowNo, row.PayeeName, row.AccountNo, row.AmountText));
            if (m.Unmatched.Count > 0)
                res.Errors.Add(string.Format(Strings.GetString("CB.GIROBatch_FileNotMatch"), m.Unmatched.Count));
            res.Errors.AddRange(m.Warnings);      // amount different / account twice -> wrong file, blocked too

            foreach (GIROUffLine l in m.Failed)
            {
                GIROReturnRow row = m.FailedRow[l.DebtorID];
                foreach (GIROPreCheckLine pl in res.Lines.Where(x => x.DebtorID == l.DebtorID))
                {
                    pl.GIROStatus = StatusFailed;
                    pl.ReturnReason = row.ReturnReason;
                }
            }
        }
        return res;
    }

    /// <summary>Import Path of the batch's GIRO bank for display ("" when not set up).</summary>
    public static string GetImportPathText(int receiptGroupID)
    {
        try { return GetImportPath(receiptGroupID); }
        catch (GIROException) { return ""; }
    }

    private static string GetImportPath(int receiptGroupID)
    {
        DataTable g = DataAccessHelper.ExecuteDataTable(string.Format(
            "select CompanyID, BankAccountID from CB_ReceiptGroup where CBReceiptGroupID = {0}", receiptGroupID));
        if (g == null || g.Rows.Count == 0)
            throw new GIROException(Strings.GetString("CB.GIROBatch_NotFound"));
        GIROBankSetup bank = LoadBank(Convert.ToInt32(g.Rows[0]["CompanyID"]), Convert.ToInt32(g.Rows[0]["BankAccountID"]));
        string path = bank == null ? "" : (bank.ARImportPath ?? "").Trim();
        if (path.Trim('\\', '/') == "")
            throw new GIROException(Strings.GetString("CB.GIROBatch_ImportPathRequired"));
        if (!Directory.Exists(path))
            throw new GIROException(string.Format(Strings.GetString("CB.GIROBatch_ImportPathNotFound"), path));
        return path;
    }

    private static DataTable Query(DbTransaction tran, string sql, params object[] args)
    {
        if (tran != null) return GIRODb.Table(tran, sql, args);
        // read only: parameters are ints here -> inline them
        for (int i = 0; i + 1 < args.Length; i += 2)
            sql = sql.Replace((string)args[i], Convert.ToInt32(args[i + 1]).ToString());
        return DataAccessHelper.ExecuteDataTable(sql);
    }

    // batch row locked; only an Exported GIRO batch can be reset / completed / imported
    private static DataRow LockBatch(DbTransaction tran, int receiptGroupID)
    {
        DataTable dt = GIRODb.Table(tran, @"
            select CBReceiptGroupID, GroupNo, DocumentDate, RecordStatus, Filename
            from CB_ReceiptGroup with (updlock, rowlock)
            where CBReceiptGroupID = @GroupID and RecordType = 'GIRO'", "@GroupID", receiptGroupID);
        if (dt == null || dt.Rows.Count == 0)
            throw new GIROException(Strings.GetString("CB.GIROBatch_NotFound"));
        DataRow g = dt.Rows[0];
        if (Convert.ToString(g["RecordStatus"]) != StatusExported)
            throw new GIROException(string.Format(Strings.GetString("CB.GIROBatch_NotExported"), g["GroupNo"], g["RecordStatus"]));
        return g;
    }

    public static GIROBankSetup LoadBank(int companyID, int bankAccountID)
    {
        DataTable dt = DataAccessHelper.ExecuteDataTable(string.Format(@"
            select top 1 cgb.GiroBankAccountID, ba.AccountNo, ca.Name as BankName, ba.CurrencyID, c.ISOCode,
                   cgb.OrganizationID, cgb.OrganizationName, cgb.ARExportPath, cgb.ARImportPath
            from CF_CompanyGiroBank cgb
                 inner join CF_BankAccount ba on ba.BankAccountID = cgb.GiroBankAccountID
                 left join CF_Account ca on ca.AccountID = ba.AccountID
                 left join CF_Currency c on c.CurrencyID = ba.CurrencyID
            where cgb.CompanyID = {0} and cgb.GiroBankAccountID = {1} and cgb.RecordStatus = 'Active'
            order by cgb.CompanyGiroBankID", companyID, bankAccountID));
        if (dt == null || dt.Rows.Count == 0) return null;
        DataRow r = dt.Rows[0];
        GIROBankSetup b = new GIROBankSetup();
        b.BankAccountID = bankAccountID;
        b.AccountNo = Convert.ToString(r["AccountNo"]);
        b.BankName = Convert.ToString(r["BankName"]);
        b.CurrencyID = r["CurrencyID"] == DBNull.Value ? 0 : Convert.ToInt32(r["CurrencyID"]);
        b.CurrencyCode = Convert.ToString(r["ISOCode"]);
        b.OrganizationID = Convert.ToString(r["OrganizationID"]);
        b.OrganizationName = Convert.ToString(r["OrganizationName"]);
        b.ARExportPath = Convert.ToString(r["ARExportPath"]);
        b.ARImportPath = Convert.ToString(r["ARImportPath"]);
        return b;
    }

    public static void WriteAuditLog(DbTransaction tran, int? groupID, int userID, string action, string remark)
    {
        if (remark != null && remark.Length > 500) remark = remark.Substring(0, 500);
        GIRODb.Execute(tran, @"
            insert into CB_ReceiptGroup_AuditLog (ReceiptGroupID, ProcessUserID, ProcessDateTime, Action, Remark,
                                                  CreateUserID, CreateDate, ModifyUserID, ModifyDate)
            values (@GroupID, @UserID, getdate(), @Action, @Remark, @UserID, getdate(), @UserID, getdate())",
            "@GroupID", groupID.HasValue ? (object)groupID.Value : DBNull.Value, "@UserID", userID, "@Action", action, "@Remark", remark);
    }

    // D64: invoice no of the bills collected by each receipt
    private static Dictionary<int, List<string>> LoadInvoiceNos(DbTransaction tran, string idList)
    {
        Dictionary<int, List<string>> map = new Dictionary<int, List<string>>();
        DataTable dt = GIRODb.Table(tran, string.Format(@"
            select distinct a.ReceiptID, t.DocumentNo
            from AR_Allocation a inner join AR_Trx t on t.BillID = a.BillID
            where a.ReceiptID in ({0}) and a.AllocAmt <> 0 and a.RecordStatus not in ('Inactive', 'Voided')
              and isnull(t.DocumentNo, '') <> ''
            order by a.ReceiptID, t.DocumentNo", idList));
        foreach (DataRow r in dt.Rows)
        {
            int id = Convert.ToInt32(r["ReceiptID"]);
            if (!map.ContainsKey(id)) map[id] = new List<string>();
            map[id].Add(Convert.ToString(r["DocumentNo"]));
        }
        return map;
    }

    // DBS duplicate check = File Creation Date + Organization ID + File Name -> batch id + time in the name
    private static string MakeFileName(string orgID, string batchID)
    {
        string org = new string((orgID ?? "").Where(ch => char.IsLetterOrDigit(ch)).ToArray());
        return string.Format("UFF_COL_{0}_{1}_{2}.csv", org, batchID, DateTime.Now.ToString("yyyyMMddHHmmss"));
    }
}
