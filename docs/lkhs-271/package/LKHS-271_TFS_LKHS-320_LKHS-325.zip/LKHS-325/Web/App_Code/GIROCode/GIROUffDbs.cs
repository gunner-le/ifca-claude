using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// LKHS-325 - GIRO Batch (step 7) - DBS UFF (Universal File Format) instruction file builder.
// Spec: DBS_GIRO_Specification.xlsx (sheets Instruction Header / Detail / Trailer, Sample Giro Format).
// Pure class: no DB, no file system. The caller (GIRO Batch page) reads the receipts of the batch,
// calls Build(), then writes Result.Content to CF_CompanyGiroBank.ARExportPath.
//
// File layout (CSV, UTF-8, CRLF):
//   HEADER,<H02 DDMMYYYY>,<H03 Org ID>,<H04 Org Name>,UFFv2
//   PAYMENT,COL,<D03>,<D04>,,<D06>,<D07>,<D08>,...  (68 fields, D01..D68)  -> ONE LINE PER DEBTOR (Stanley)
//   TRAILER,<T02 count>,<T03 total>

/// <summary>One GIRO receipt of the batch (CB_Receipt IsGiroReceipt='Y'). Several receipts of one debtor = one UFF line.</summary>
public class GIROUffReceipt
{
    public int ReceiptID;              // CB_Receipt.CBReceiptID
    public int DebtorID;               // AR_Debtor.DebtorID (grouping key)
    public string DebtorName;          // D11 (truncated to 35)
    public string GiroAccountNo;       // D16 AR_Debtor.GiroAccountNo
    public string SwiftCode;           // D21 Bank SWIFT BIC of AR_Debtor.GiroBankSwiftCodeID
    public string IdentityNo;          // D35 DDA reference (spec: Debtor Link Account Profile > Identity No.)
    public decimal Amount;             // receipt amount (sum per debtor -> D28)
    public List<string> InvoiceNos = new List<string>();   // D64 related invoice no
}

/// <summary>Values shared by the whole file / batch (CB_ReceiptGroup + CF_CompanyGiroBank + CF_BankAccount).</summary>
public class GIROUffBatch
{
    public DateTime FileCreationDate = DateTime.Now;   // H02
    public string OrganizationID;      // H03 CF_CompanyGiroBank.OrganizationID
    public string OrganizationName;    // H04 CF_CompanyGiroBank.OrganizationName
    public string OriginatingAccountNo;// D03 CF_BankAccount account no of the GIRO bank
    public string CurrencyCode;        // D04 / D06 bank currency (ISO, e.g. SGD)
    public string BatchID;             // D07 from CB_ReceiptGroup.GroupNo (numeric 1..99999)
    public DateTime PaymentDate;       // D08 CB_ReceiptGroup.DocumentDate
    public string ReferenceNo;         // D34 CB_ReceiptGroup.ReferenceNo
    public string PurposeCode;         // D43 CB_ReceiptGroup.PurposeCode
    public bool AllowBlankIdentityNo;  // D35 is Mandatory in spec; true only while its source is not decided
    public List<GIROUffReceipt> Receipts = new List<GIROUffReceipt>();
}

/// <summary>One detail line of the file (= one debtor). Kept by the caller to match the DBS return file.</summary>
public class GIROUffLine
{
    public int LineNo;                 // 1-based order in the file
    public int DebtorID;
    public string DebtorName;
    public string AccountNo;           // normalized D16 (no dash / space)
    public string SwiftCode;
    public string IdentityNo;
    public decimal Amount;             // D28
    public string InvoiceNos;          // D64
    public List<int> ReceiptIDs = new List<int>();
}

public class GIROUffResult
{
    public string Content;             // full file text
    public List<GIROUffLine> Lines = new List<GIROUffLine>();
    public int TotalCount;             // T02
    public decimal TotalAmount;        // T03

    /// <summary>UTF-8 without BOM (first bytes of the file must be "HEADER").</summary>
    public byte[] GetBytes() { return new UTF8Encoding(false).GetBytes(Content ?? ""); }
}

public static class GIROUffDbs
{
    public const int DetailFieldCount = 68;     // D01..D68 as in "Sample Giro Format"
    public const string PaymentType = "COL";    // D02 Bulk Collection
    public const string TransactionCode = "30"; // D33 Direct Debit (SG)
    public const string UffVersion = "UFFv2";   // H05

    const int MaxOrgID = 12, MaxOrgName = 35, MaxAccount = 35, MaxName = 35, MaxSwift = 11,
              MaxReference = 35, MaxPurpose = 4, MaxInvoice = 70000;

    /// <summary>Validate and build the file. Throws GIROException listing every problem found.</summary>
    public static GIROUffResult Build(GIROUffBatch batch)
    {
        if (batch == null) throw new ArgumentNullException("batch");
        List<string> errors = new List<string>();

        string orgID = Clean(batch.OrganizationID);
        string orgName = Clean(batch.OrganizationName);
        string fromAcct = NormalizeAccountNo(batch.OriginatingAccountNo);
        string ccy = Clean(batch.CurrencyCode).ToUpperInvariant();
        string reference = Clean(batch.ReferenceNo);
        string purpose = Clean(batch.PurposeCode).ToUpperInvariant();
        string batchID = null;

        if (orgID.Length == 0) errors.Add("GIRO bank Organization ID is not set up (Company Structure).");
        else if (orgID.Length > MaxOrgID) errors.Add("Organization ID '" + orgID + "' is longer than " + MaxOrgID + " characters.");
        if (orgName.Length == 0) errors.Add("GIRO bank Organization Name is not set up (Company Structure).");
        if (fromAcct.Length == 0) errors.Add("Account No of the GIRO bank account is empty.");
        else if (fromAcct.Length > MaxAccount) errors.Add("Account No of the GIRO bank account is longer than " + MaxAccount + " characters.");
        else if (!IsDigits(fromAcct)) errors.Add("Account No of the GIRO bank account '" + batch.OriginatingAccountNo + "' must contain digits only (D03).");
        if (ccy.Length != 3) errors.Add("Currency code of the GIRO bank account is invalid ('" + ccy + "').");
        if (reference.Length == 0) errors.Add("Reference No is required.");
        else if (reference.Length > MaxReference) errors.Add("Reference No is longer than " + MaxReference + " characters.");
        if (purpose.Length == 0) errors.Add("Purpose of Payment is required.");
        else if (purpose.Length > MaxPurpose) errors.Add("Purpose of Payment '" + purpose + "' is longer than " + MaxPurpose + " characters.");
        if (batch.PaymentDate == DateTime.MinValue) errors.Add("Payment Date is required.");
        try { batchID = FormatBatchID(batch.BatchID); }
        catch (GIROException ex) { errors.Add(ex.Message); }

        List<GIROUffLine> lines = GroupByDebtor(batch.Receipts);
        if (lines.Count == 0) errors.Add("No GIRO receipt in the batch.");

        Dictionary<string, GIROUffLine> byAccount = new Dictionary<string, GIROUffLine>();
        foreach (GIROUffLine l in lines)
        {
            string who = "Debtor '" + l.DebtorName + "'";
            if (l.AccountNo.Length == 0) errors.Add(who + ": GIRO Account No is empty.");
            else if (l.AccountNo.Length > MaxAccount) errors.Add(who + ": GIRO Account No is longer than " + MaxAccount + " characters.");
            else if (byAccount.ContainsKey(l.AccountNo))
                // the DBS return file is matched by account number -> must be unique in one file
                errors.Add(who + " and debtor '" + byAccount[l.AccountNo].DebtorName + "' have the same GIRO Account No " + l.AccountNo + ".");
            else byAccount.Add(l.AccountNo, l);
            if (l.SwiftCode.Length == 0) errors.Add(who + ": Bank SWIFT Code is empty.");
            else if (l.SwiftCode.Length > MaxSwift) errors.Add(who + ": Bank SWIFT Code '" + l.SwiftCode + "' is longer than " + MaxSwift + " characters.");
            if (l.IdentityNo.Length == 0 && !batch.AllowBlankIdentityNo) errors.Add(who + ": Identity No is empty (D35, please fill Identity No in the debtor account profile).");
            if (l.Amount <= 0) errors.Add(who + ": total amount must be greater than 0 (" + FormatAmount(l.Amount) + ").");
        }

        if (errors.Count > 0) throw new GIROException(string.Join("\n", errors.ToArray()));

        GIROUffResult result = new GIROUffResult();
        StringBuilder sb = new StringBuilder();

        // Header H01..H05
        AppendRecord(sb, new string[] { "HEADER", FormatDate(batch.FileCreationDate), orgID, Truncate(orgName, MaxOrgName), UffVersion });

        // Detail D01..D68, one per debtor
        foreach (GIROUffLine l in lines)
        {
            string[] d = new string[DetailFieldCount];
            d[0] = "PAYMENT";                          // D01
            d[1] = PaymentType;                        // D02
            d[2] = fromAcct;                           // D03
            d[3] = ccy;                                // D04
            //   D05 Customer / Batch reference: blank (auto-assign by DBS)
            d[5] = ccy;                                // D06
            d[6] = batchID;                            // D07
            d[7] = FormatDate(batch.PaymentDate);      // D08
            d[10] = Truncate(l.DebtorName, MaxName);   // D11
            d[15] = l.AccountNo;                       // D16
            d[20] = l.SwiftCode;                       // D21
            d[27] = FormatAmount(l.Amount);            // D28
            d[32] = TransactionCode;                   // D33
            d[33] = reference;                         // D34
            d[34] = l.IdentityNo;                      // D35
            d[42] = purpose;                           // D43
            d[63] = Truncate(l.InvoiceNos, MaxInvoice);// D64
            AppendRecord(sb, d);

            result.TotalCount++;
            result.TotalAmount += l.Amount;
        }

        // Trailer T01..T03
        AppendRecord(sb, new string[] { "TRAILER", result.TotalCount.ToString(CultureInfo.InvariantCulture), FormatAmount(result.TotalAmount) });

        result.Content = sb.ToString();
        result.Lines = lines;
        return result;
    }

    /// <summary>Receipts -> one line per DebtorID (amount summed, invoice no distinct, order of first receipt kept).
    /// Also used by the Import to rebuild the exported lines from CB_ReceiptGroupDetail.</summary>
    public static List<GIROUffLine> GroupByDebtor(IEnumerable<GIROUffReceipt> receipts)
    {
        List<GIROUffLine> lines = new List<GIROUffLine>();
        Dictionary<int, GIROUffLine> map = new Dictionary<int, GIROUffLine>();
        Dictionary<int, List<string>> invoices = new Dictionary<int, List<string>>();
        if (receipts == null) return lines;

        foreach (GIROUffReceipt r in receipts)
        {
            if (r == null) continue;
            GIROUffLine l;
            if (!map.TryGetValue(r.DebtorID, out l))
            {
                l = new GIROUffLine();
                l.LineNo = lines.Count + 1;
                l.DebtorID = r.DebtorID;
                l.DebtorName = Clean(r.DebtorName);
                l.AccountNo = NormalizeAccountNo(r.GiroAccountNo);
                l.SwiftCode = Clean(r.SwiftCode).ToUpperInvariant();
                l.IdentityNo = Clean(r.IdentityNo);
                map.Add(r.DebtorID, l);
                invoices.Add(r.DebtorID, new List<string>());
                lines.Add(l);
            }
            l.Amount += Math.Round(r.Amount, 2, MidpointRounding.AwayFromZero);
            if (!l.ReceiptIDs.Contains(r.ReceiptID)) l.ReceiptIDs.Add(r.ReceiptID);
            if (r.InvoiceNos != null)
                foreach (string inv in r.InvoiceNos)
                {
                    string s = Clean(inv);
                    if (s.Length > 0 && !invoices[r.DebtorID].Contains(s)) invoices[r.DebtorID].Add(s);
                }
        }
        foreach (GIROUffLine l in lines) l.InvoiceNos = string.Join(", ", invoices[l.DebtorID].ToArray());
        return lines;
    }

    /// <summary>D07: numeric, 00001..99999, 5 digits. GroupNo of DocCode 316_ReceiptGroup must be numeric only.</summary>
    public static string FormatBatchID(string groupNo)
    {
        string s = Clean(groupNo);
        int n;
        if (s.Length == 0) throw new GIROException("GIRO Batch No is empty.");
        if (s.Length > 5 || !IsDigits(s) || !int.TryParse(s, out n) || n < 1)
            throw new GIROException("GIRO Batch No '" + s + "' is not valid for DBS Batch ID (D07 must be numeric 00001-99999). Please check Number Structure 316_ReceiptGroup.");
        return n.ToString("00000", CultureInfo.InvariantCulture);
    }

    /// <summary>Account no as DBS expects: remark in brackets removed (e.g. "003-922390-0 (NEW)" -> "0039223900"),
    /// then letters / digits only (dash, space, quote removed). Also used to match the return file.</summary>
    public static string NormalizeAccountNo(string accountNo)
    {
        string s = Clean(accountNo);
        StringBuilder sb = new StringBuilder(s.Length);
        int depth = 0;
        foreach (char c in s)
        {
            if (c == '(' || c == '[') { depth++; continue; }
            if (c == ')' || c == ']') { if (depth > 0) depth--; continue; }
            if (depth == 0 && char.IsLetterOrDigit(c)) sb.Append(c);
        }
        return sb.ToString();
    }

    public static string FormatDate(DateTime d) { return d.ToString("ddMMyyyy", CultureInfo.InvariantCulture); }

    /// <summary>2 decimals, no thousand separator, no leading zero.</summary>
    public static string FormatAmount(decimal amt)
    {
        return Math.Round(amt, 2, MidpointRounding.AwayFromZero).ToString("0.00", CultureInfo.InvariantCulture);
    }

    /// <summary>CSV field: quoted when it contains comma / quote; quote doubled (spec "General Note").</summary>
    public static string CsvField(string value)
    {
        string s = value ?? "";
        if (s.IndexOf(',') >= 0 || s.IndexOf('"') >= 0)
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        return s;
    }

    static void AppendRecord(StringBuilder sb, string[] fields)
    {
        for (int i = 0; i < fields.Length; i++)
        {
            if (i > 0) sb.Append(',');
            sb.Append(CsvField(fields[i]));
        }
        sb.Append("\r\n");
    }

    /// <summary>Trim, and replace line breaks / tabs by a space (no "Alt Enter" allowed in a field).</summary>
    static string Clean(string s)
    {
        if (s == null) return "";
        return s.Replace("\r\n", " ").Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ').Trim();
    }

    static string Truncate(string s, int max)
    {
        if (s == null) return "";
        return s.Length <= max ? s : s.Substring(0, max).TrimEnd();
    }

    static bool IsDigits(string s)
    {
        foreach (char c in s) if (c < '0' || c > '9') return false;
        return true;
    }
}
