using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

// LKHS-325 - GIRO Batch (step 7) - DBS return (result) file reader.
// Rules (Stanley / Valerie):
//   - One return file per batch (CSV, Stanley 06/11). File name NOT used to find the batch: user selects the batch,
//     every record of the file must match a debtor line of that batch, else Confirm is blocked.
//   - The file lists ONLY the failed lines; a debtor line not in the file = success.
//   - If all lines succeed DBS sends no file -> "Complete (All Success)" button (not handled here).
//   - Line key = Account number (D16). The result of a line applies to all receipts of that debtor in the batch.
// Pure class: no DB. Parse() takes rows, so an xlsx reader can be plugged in later; ParseCsv() reads CSV text.

/// <summary>One data row of the return file.</summary>
public class GIROReturnRow
{
    public int RowNo;                  // 1-based row number in the file (for messages)
    public string PayeeName;           // Payee / Nickname (D11)
    public string SwiftCode;           // Bank / SWIFT BIC (D21)
    public string AccountNo;           // Account number (D16), normalized
    public string Status;              // e.g. "Bank Rejected"
    public string RejectReason;        // e.g. "1209:..."
    public string AmountText;          // e.g. "3167.43(SGD)"
    public decimal? Amount;
    public string PurposeCode;
    public string Reference;           // Reference for payee (D34)
    public string PaymentDate;
    public string Message;
    public bool IsFailed;              // false only when Status says success

    /// <summary>Text saved to CB_ReceiptGroupDetail.ReturnReason (nvarchar 255).</summary>
    public string ReturnReason
    {
        get
        {
            List<string> parts = new List<string>();
            if (!string.IsNullOrEmpty(RejectReason)) parts.Add(RejectReason);
            if (!string.IsNullOrEmpty(Message) && Message != RejectReason) parts.Add(Message);
            if (parts.Count == 0 && !string.IsNullOrEmpty(Status)) parts.Add(Status);
            string s = string.Join(" - ", parts.ToArray());
            return s.Length <= 255 ? s : s.Substring(0, 255);
        }
    }
}

public class GIROReturnFile
{
    public string FileName;
    public string BatchID;             // from file name (5 digits) or null
    public List<GIROReturnRow> Rows = new List<GIROReturnRow>();
    public List<string> Errors = new List<string>();   // file cannot be used if not empty
}

/// <summary>Return file matched against the exported lines of the batch.</summary>
public class GIROReturnMatch
{
    public List<GIROUffLine> Failed = new List<GIROUffLine>();
    public Dictionary<int, GIROReturnRow> FailedRow = new Dictionary<int, GIROReturnRow>();  // key DebtorID
    public List<GIROUffLine> Success = new List<GIROUffLine>();
    public List<GIROReturnRow> Unmatched = new List<GIROReturnRow>();   // row with no exported line -> block import
    public List<string> Warnings = new List<string>();
}

public static class GIROReturnFileDbs
{
    static readonly Regex SciNotation = new Regex(@"^\d+(\.\d+)?[eE][+\-]?\d+$");

    /// <summary>Batch ID from the file name: last "-" segment without extension, digits only, as 5 digits.</summary>
    public static string GetBatchIDFromFileName(string fileName)
    {
        if (string.IsNullOrEmpty(fileName)) return null;
        string name = Path.GetFileNameWithoutExtension(fileName.Trim());
        int pos = name.LastIndexOf('-');
        string seg = (pos >= 0 ? name.Substring(pos + 1) : name).Trim();
        int n;
        if (seg.Length == 0 || seg.Length > 5 || !int.TryParse(seg, NumberStyles.None, CultureInfo.InvariantCulture, out n) || n < 1)
            return null;
        return n.ToString("00000", CultureInfo.InvariantCulture);
    }

    public static GIROReturnFile ParseCsv(string fileName, string text)
    {
        return Parse(fileName, ReadCsv(text));
    }

    public static GIROReturnFile ParseCsv(string fileName, byte[] content)
    {
        // UTF-8 (BOM removed); DBS supports UTF-8 only
        string text = content == null ? "" : new UTF8Encoding(false).GetString(content);
        return ParseCsv(fileName, text);
    }

    /// <summary>Rows (first row containing an "Account number" header = header row) -> return file.</summary>
    public static GIROReturnFile Parse(string fileName, IList<string[]> rows)
    {
        GIROReturnFile file = new GIROReturnFile();
        file.FileName = fileName;
        file.BatchID = GetBatchIDFromFileName(fileName);
        // Stanley 06/11: file name cannot be matched with the batch -> BatchID only informative, no error;
        // the file is checked by its records (every record must match the selected batch)

        if (rows == null || rows.Count == 0) { file.Errors.Add("The file is empty."); return file; }

        int headerIdx = -1;
        Dictionary<string, int> col = null;
        for (int i = 0; i < rows.Count && i < 30; i++)
        {
            Dictionary<string, int> c = MapColumns(rows[i]);
            if (c.ContainsKey("account")) { headerIdx = i; col = c; break; }
        }
        if (headerIdx < 0) { file.Errors.Add("Column 'Account number' is not found in the file."); return file; }
        if (!col.ContainsKey("status") && !col.ContainsKey("reason"))
        { file.Errors.Add("Column 'Status' / 'Reject Reason' is not found in the file."); return file; }

        for (int i = headerIdx + 1; i < rows.Count; i++)
        {
            string[] r = rows[i];
            if (IsBlank(r)) continue;

            GIROReturnRow row = new GIROReturnRow();
            row.RowNo = i + 1;
            string rawAccount = Get(r, col, "account");
            row.AccountNo = GIROUffDbs.NormalizeAccountNo(rawAccount);
            row.PayeeName = Get(r, col, "payee");
            row.SwiftCode = Get(r, col, "swift");
            row.Status = Get(r, col, "status");
            row.RejectReason = Get(r, col, "reason");
            row.AmountText = Get(r, col, "amount");
            row.Amount = ParseAmount(row.AmountText);
            row.PurposeCode = Get(r, col, "purpose");
            row.Reference = Get(r, col, "reference");
            row.PaymentDate = Get(r, col, "paymentdate");
            row.Message = Get(r, col, "message");
            row.IsFailed = !IsSuccessStatus(row.Status);

            if (row.AccountNo.Length == 0)
                file.Errors.Add("Row " + row.RowNo + ": Account number is empty.");
            else if (SciNotation.IsMatch(row.AccountNo))
                file.Errors.Add("Row " + row.RowNo + ": Account number '" + rawAccount + "' was changed by Excel (scientific format). Please use the original file from DBS.");
            file.Rows.Add(row);
        }
        return file;
    }

    /// <summary>Match rows with the exported lines by account number (leading zero lost by Excel also accepted).</summary>
    public static GIROReturnMatch Match(GIROReturnFile file, IList<GIROUffLine> exported)
    {
        GIROReturnMatch m = new GIROReturnMatch();
        Dictionary<string, GIROUffLine> byAcct = new Dictionary<string, GIROUffLine>(StringComparer.OrdinalIgnoreCase);
        Dictionary<string, GIROUffLine> byAcctNoZero = new Dictionary<string, GIROUffLine>(StringComparer.OrdinalIgnoreCase);
        foreach (GIROUffLine l in exported)
        {
            if (!byAcct.ContainsKey(l.AccountNo)) byAcct.Add(l.AccountNo, l);
            string z = l.AccountNo.TrimStart('0');
            if (!byAcctNoZero.ContainsKey(z)) byAcctNoZero.Add(z, l);
        }

        foreach (GIROReturnRow row in file.Rows)
        {
            GIROUffLine l;
            if (!byAcct.TryGetValue(row.AccountNo, out l) && !byAcctNoZero.TryGetValue(row.AccountNo.TrimStart('0'), out l))
            {
                m.Unmatched.Add(row);
                continue;
            }
            if (row.Amount.HasValue && row.Amount.Value != l.Amount)
                m.Warnings.Add("Row " + row.RowNo + " (" + l.DebtorName + "): amount " + row.AmountText + " differs from exported amount " + GIROUffDbs.FormatAmount(l.Amount) + ".");
            if (!row.IsFailed) continue;
            if (m.FailedRow.ContainsKey(l.DebtorID))
            {
                m.Warnings.Add("Row " + row.RowNo + ": account " + row.AccountNo + " appears more than once, first row is used.");
                continue;
            }
            m.FailedRow.Add(l.DebtorID, row);
            m.Failed.Add(l);
        }
        foreach (GIROUffLine l in exported)
            if (!m.FailedRow.ContainsKey(l.DebtorID)) m.Success.Add(l);
        return m;
    }

    /// <summary>RFC-4180 style CSV reader (quoted fields, "" escape, line breaks inside quotes, BOM).</summary>
    public static List<string[]> ReadCsv(string text)
    {
        List<string[]> rows = new List<string[]>();
        if (string.IsNullOrEmpty(text)) return rows;
        if (text[0] == '\uFEFF') text = text.Substring(1);   // UTF-8 BOM

        List<string> fields = new List<string>();
        StringBuilder cur = new StringBuilder();
        bool inQuotes = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (inQuotes)
            {
                if (c == '"')
                {
                    if (i + 1 < text.Length && text[i + 1] == '"') { cur.Append('"'); i++; }
                    else inQuotes = false;
                }
                else cur.Append(c);
            }
            else if (c == '"') inQuotes = true;
            else if (c == ',') { fields.Add(cur.ToString()); cur.Length = 0; }
            else if (c == '\r' || c == '\n')
            {
                if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                fields.Add(cur.ToString()); cur.Length = 0;
                rows.Add(fields.ToArray()); fields.Clear();
            }
            else cur.Append(c);
        }
        if (cur.Length > 0 || fields.Count > 0) { fields.Add(cur.ToString()); rows.Add(fields.ToArray()); }
        return rows;
    }

    // ---- helpers ----------------------------------------------------------------------

    /// <summary>Header text -> logical column (by name, not position; header text compared without space / symbol).</summary>
    static Dictionary<string, int> MapColumns(string[] header)
    {
        Dictionary<string, int> c = new Dictionary<string, int>();
        for (int i = 0; i < header.Length; i++)
        {
            string h = Key(header[i]);
            if (h.Length == 0) continue;
            string k = null;
            if (h.Contains("accountnumber") || h == "accountno" || h.Contains("receivingaccount")) k = "account";
            else if (h.StartsWith("payee") || h.Contains("nickname") || h.Contains("receivingparty")) k = "payee";
            else if (h.Contains("swift") || h.Contains("bic")) k = "swift";
            else if (h.Contains("reason")) k = "reason";
            else if (h.StartsWith("status")) k = "status";
            else if (h.StartsWith("amount")) k = "amount";
            else if (h.Contains("purpose")) k = "purpose";
            else if (h.Contains("reference")) k = "reference";
            else if (h.Contains("paymentdate") || h == "date") k = "paymentdate";
            else if (h.StartsWith("message")) k = "message";
            if (k != null && !c.ContainsKey(k)) c.Add(k, i);
        }
        return c;
    }

    static string Key(string s)
    {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        foreach (char ch in s.ToLowerInvariant()) if (char.IsLetterOrDigit(ch)) sb.Append(ch);
        return sb.ToString();
    }

    static string Get(string[] r, Dictionary<string, int> col, string key)
    {
        int i;
        if (!col.TryGetValue(key, out i) || i >= r.Length || r[i] == null) return "";
        return r[i].Trim();
    }

    static bool IsBlank(string[] r)
    {
        foreach (string s in r) if (!string.IsNullOrEmpty(s) && s.Trim().Length > 0) return false;
        return true;
    }

    /// <summary>Only failed lines are returned; a row is success only if its status says so explicitly.</summary>
    static bool IsSuccessStatus(string status)
    {
        string s = Key(status);
        return s.Contains("success") || s == "completed" || s == "accepted" || s == "processed";
    }

    /// <summary>"3,167.43(SGD)" -> 3167.43</summary>
    static decimal? ParseAmount(string s)
    {
        if (string.IsNullOrEmpty(s)) return null;
        int p = s.IndexOf('(');
        if (p >= 0) s = s.Substring(0, p);
        s = s.Replace(",", "").Trim();
        decimal d;
        if (decimal.TryParse(s, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out d))
            return Math.Round(d, 2);
        return null;
    }
}
