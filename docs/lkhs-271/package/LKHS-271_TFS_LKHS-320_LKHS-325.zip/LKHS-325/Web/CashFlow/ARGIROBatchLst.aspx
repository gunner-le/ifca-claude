<%@ Page Language="C#" MasterPageFile="~/Common/MasterBarCondList.master" AutoEventWireup="true" CodeFile="ARGIROBatchLst.aspx.cs" Inherits="CashFlow_ARGIROBatchLst" Title="Untitled Page" %>

<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System" %>
<%-- LKHS-325: GIRO Batch Listing - popup from Collection Verification (spec 7b / 7c, Stanley call 04/11)
     criteria + batch grid + Import / Verify / Reset / Close (doc v01.01); one batch per action.
     Import -> ARGIROBatchImport.aspx (Upload Screen) -> ARGIROBatchPreCheck.aspx; Verify -> ARGIROBatchPreCheck.aspx (no file).
     Same structure as ARGIROCollectionLst.aspx (step 6). --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" runat="Server">
<script language="javascript" type="text/javascript">
var PubPrive;
var PubCont = '<%=ContextMnuNo %>';

function f_GetMessage(tip)
{
    return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
}

function f_OnFailure(obj)
{
    MessageClose();
    MessageShow(f_GetMessage(obj._message));
}

// exactly one ticked batch -> CBReceiptGroupID, else message and null
function f_GetOneBatch()
{
    var ids = gridManager2.GetSelectedRowIds();
    if (ids == null || ids.toString() == "")
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected") %>"));
        return null;
    }
    if (ids.toString().indexOf(",") >= 0)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIROBatch_SelectOneBatch") %>"));
        return null;
    }
    // only an Exported batch can be processed; Completed / Cancel are listed for history (view only)
    var rows = gridManager2.GetValidRows();
    for (var m = 0; m < rows.length; m++)
    {
        if (String(gridManager2.GetValueByName(rows[m], "cbreceiptgroupid")) != ids.toString()) continue;
        var status = gridManager2.GetValueByName(rows[m], "recordstatus");
        if (status != null && status != "" && status != "Exported")
        {
            var tip = "<%=Strings.GetString("CB.GIROBatch_ViewOnly") %>";
            tip = tip.replace("{0}", gridManager2.GetValueByName(rows[m], "groupno")).replace("{1}", status);
            MessageShow(f_GetMessage(tip));
            return null;
        }
        break;
    }
    return ids.toString();
}

// confirm box -> fn(id) on OK
function f_Confirm(tip, okEvent)
{
    var msg = {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",
               Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:okEvent},{Name:"<%=Strings.GetString("Cancel") %>",Event:""}]};
    MessageShow(msg);
}

/* Reset: batch cancelled, receipts back to Generated */
function f_GIROBatchReset()
{
    var id = f_GetOneBatch();
    if (id == null) return;
    f_Confirm("<%=Strings.GetString("CB.GIROBatch_ResetConfirm") %>", "f_DoReset('" + id + "')");
}
function f_DoReset(id)
{
    f_MessageWait();
    PageMethods.ResetBatch(parseInt(id, 10), f_ActionDone, f_OnFailure);
}

/* Import (doc v01.01): Upload Screen (files of the Import Path) -> selected file -> Pre-Check WITH attachment info */
var giroBatchID = "";
function f_GIROBatchImport()
{
    var id = f_GetOneBatch();
    if (id == null) return;
    giroBatchID = id;
    f_OpenWin("../CashFlow/ARGIROBatchImport.aspx?ReceiptGroupID=" + id, "GIROBatchImport", 700, 450);
}
// called by the Upload Screen (window.opener) with the selected file name
function f_OpenPreCheck(fileName)
{
    if (giroBatchID == "") return;
    f_OpenWin("../CashFlow/ARGIROBatchPreCheck.aspx?ReceiptGroupID=" + giroBatchID + "&File=" + encodeURIComponent(fileName), "GIROBatchPreCheck", 1000, 550);
}

/* Verify (doc v01.01): no DBS return file -> Pre-Check WITHOUT attachment info (all Success) */
function f_GIROBatchVerify()
{
    var id = f_GetOneBatch();
    if (id == null) return;
    giroBatchID = id;
    f_OpenWin("../CashFlow/ARGIROBatchPreCheck.aspx?ReceiptGroupID=" + id, "GIROBatchPreCheck", 1000, 550);
}

// 2nd level popup (this page is already a popup): window.open, the child calls back via window.opener
function f_OpenWin(url, name, w, h)
{
    url += (url.indexOf("?") >= 0 ? "&" : "?") + "t=" + new Date().getTime();   // no cached page: file content can change with the same name
    var left = Math.max(0, (screen.availWidth - w) / 2), top2 = Math.max(0, (screen.availHeight - h) / 2);
    var win = window.open(url, name, "width=" + w + ",height=" + h + ",left=" + left + ",top=" + top2
        + ",resizable=yes,scrollbars=yes,status=no,toolbar=no,menubar=no,location=no");
    try { win.focus(); } catch (e) { }
}

// after Reset, and after Confirm of the Pre-Check screen (called via window.opener)
function f_ActionDone(result)
{
    MessageClose();
    MessageShow(f_GetMessage(result));
    f_ReLoad();
    OnBeforeMenu();
    try { opener.f_GIROAfterBatch(); } catch (e) { }
}

function f_Close()
{
    top.close();
}

function f_MessageWait()
{
    MessageShow({Title:'<%=Strings.GetString("MessageRemind") %>',Tip:'<%=Strings.GetString("SPleaseWait") %>',Pic:"Wait",Buttons:[]});
}

function f_ReLoad()
{
    gridManager2.Refresh();
}

function f_init()
{
    OnBeforeMenu();
}

// Import / Verify / Reset enabled only when exactly one Exported batch is ticked; Close always enabled.
// Refreshed on tick / row click (same grid events as Collection Verification ACReceiptVerify.aspx).
function f_CanProcessTicked()
{
    var ids = gridManager2.GetSelectedRowIds();
    if (ids == null || ids.toString() == "" || ids.toString().indexOf(",") >= 0) return false;
    var rows = gridManager2.GetValidRows();
    for (var m = 0; m < rows.length; m++)
    {
        if (String(gridManager2.GetValueByName(rows[m], "cbreceiptgroupid")) == ids.toString())
            return gridManager2.GetValueByName(rows[m], "recordstatus") == "Exported";
    }
    return false;
}

// toolbar button = <span onclick="if(!this.isDisabled){...}">; isDisabled is IE-only,
// so it is set here too (+ grey text) to work on Edge / Chrome
function f_SetButton(obj, disable)
{
    obj.disabled = disable ? 1 : 0;
    obj.isDisabled = disable ? true : false;
    obj.style.color = disable ? "#A0A0A0" : "";
    obj.style.cursor = disable ? "default" : "pointer";
}

function OnBeforeMenu()
{
    var canProcess = false;
    try { canProcess = f_CanProcessTicked(); } catch (e) { canProcess = true; }   // grid not ready: keep enabled, click check stays
    var pc = PubCont.split(",");
    PubPrive = "";
    for (var i = 0; i < pc.length; i++)
    {
        if (pc[i] == "") continue;
        var isDisable = (pc[i].toLowerCase() == "close" || canProcess) ? 0 : 1;
        var obj = document.getElementById(pc[i]);
        if (obj != null) f_SetButton(obj, isDisable);
        PubPrive = PubPrive + isDisable;
    }
}

gridManager2.AfterCellUpdateHandler = function (row, fieldName, value) {
    if (fieldName == "checkboxselecter") OnBeforeMenu();
}

gridManager2.AfterRowActivate = function (gridIndex, row) {
    OnBeforeMenu();
}

function OnBeforeShowContextMenu(gridIndex, menu)
{
    if (menu == null) return;
    var items = menu.getItems();
    OnBeforeMenu();
    var p = PubPrive.split("");
    for (var i = 0; i < p.length; i++)
    {
        var item = items.getItem(i);
        if (item != null) item.set_enabled(1 - p[i]);
    }
}

function alert(oldmessage)
{
    MessageShow(f_GetMessage(oldmessage));
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" runat="Server">
    <IFCAUI:SysToolbar ID="SysToolBar3" runat="server" Style="width: 100%"
        ShowSettingMenu="true" LstNo="CB.GIROBatchList" TranslateBseNo="CB.GIROBatchList"
        MenuClass="CB.GIROBatchList" MenuNo="mcorp-15-07" ShowEditView="false" ShowFilter="false"
        ShowHelp="true" ShowHelpSetting="true" ShowInterface="false" ShowSort="false"></IFCAUI:SysToolbar>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="SearchContent" runat="Server">
    <IFCAUI:SysCondition ID="SysCondition1" runat="server" LstNo="CB.GIROBatchList" />
    <input type="hidden" id="LstOrder" value="1" />
    <input type="hidden" id="CompanyID" name="CompanyID" runat="server" />
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="ListContent" runat="server">
    <atlas:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true"></atlas:ScriptManager>
    <IFCAUI:SysList2 UseCheckBox="true" StationaryMargins="Header" runat="server" ID="SysList1"
        LstNo="CB.GIROBatchList" Height="95%" Width="100%" ShowContextMenu="true"
        MenuClass="CB.GIROBatchList" MenuNo="mcorp-15-07">
    </IFCAUI:SysList2>
</asp:Content>
