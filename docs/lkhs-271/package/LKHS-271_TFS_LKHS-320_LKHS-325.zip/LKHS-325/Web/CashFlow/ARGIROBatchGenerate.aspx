<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterBarListFooter.master" AutoEventWireup="true" CodeFile="ARGIROBatchGenerate.aspx.cs" Inherits="CashFlow_ARGIROBatchGenerate" %>
<%@ Register Src="~/Common/PageBottom.ascx" TagName="PageBottom" TagPrefix="pb1" %>
<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%@ Register Src="../Common/Finance/FNCommon.ascx" TagName="FNCommon" TagPrefix="fnuc" %>
<%-- LKHS-325: GIRO Batch Generation - popup from Collection Verification (same structure as ARGIROCollectionGenerate.aspx)
     Stanley call 04/11: opens blank, user selects the GIRO bank -> receipts 'Generated' of the bank listed, user ticks -> Save = 1 batch --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" Runat="Server">
    <script type="text/javascript" language="javascript" src="../CashFlow/SubmitHelper.js"></script>
    <fnuc:FNCommon ID="FNCommonJs" runat="server" />
    <script type="text/javascript" language="javascript" src="../Common/Finance/FNCommon.js"></script>
    <script type="text/javascript">
        submitHelper.PleaseWaite = function() { return '<%=Strings.GetString("PleaseWaite") %>'; }
    </script>
    <script language="javascript" type="text/javascript">
    var giroCompanyID = '<%=currCompanyID %>';
    var giroBankAccountID = '<%=giroBankAccountID %>';

    function f_GetMessage(tip)
    {
        return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
    }

    function f_init()
    {
        // Bank dropdown: reload the popup for the selected bank (header + receipt list)
        var ddl = document.getElementById("<%=bankDDLClientID %>");
        if (ddl != null)
            ddl.onchange = f_BankChanged;
        document.getElementById("giroDetail").src = "../CashFlow/ARGIROBatchGenerateDetail.aspx?CompanyID=" + giroCompanyID
            + "&BankAccountID=" + giroBankAccountID;
    }

    function f_BankChanged()
    {
        var ddl = document.getElementById("<%=bankDDLClientID %>");
        var bankID = (ddl == null) ? "" : ddl.value;
        location.href = "../CashFlow/ARGIROBatchGenerate.aspx?CompanyID=" + giroCompanyID + "&BankAccountID=" + bankID;
    }

    // No. of Receipts / Total Amount of the ticked receipts - called by the receipt grid
    function f_SetSummary(cnt, amt)
    {
        try { tabEditorManager.SetValueByFieldName("DocumentCount", cnt); } catch (e) { }
        try { tabEditorManager.SetCurrencyValueByName("TotalAmt", amt); } catch (e) { }
    }

    // first ticked receipt -> suggest its Reference No in the header when still empty (user can change it).
    // Payment Date keeps the date chosen by the user (default today).
    function f_SuggestReference(refNo)
    {
        try
        {
            var cur = tabEditorManager.GetValueByFieldName("ReferenceNo");
            if ((cur == null || cur == "") && refNo != null && refNo != "")
                tabEditorManager.SetValueByFieldName("ReferenceNo", refNo);
        }
        catch (e) { }
    }

    // called by SubmitHelper (f_SaveData) before postback; ticked receipts -> hidden field, server validates the rest
    function f_CheckSave()
    {
        var detail = document.getElementById("giroDetail").contentWindow;
        var ids = "";
        try { ids = detail.f_GetCheckedIDs(); } catch (e) { ids = ""; }
        if (ids == null || ids == "")
        {
            MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIROBatch_NoReceipt")%>"));
            return false;
        }
        document.getElementById("<%=hidReceiptIDs.ClientID%>").value = ids;
        return true;
    }

    function f_Close()
    {
        top.close();
    }

    // after save: refresh Collection Verification and close
    function f_AfterSave()
    {
        try { opener.f_GIROAfterBatch(); } catch (e) { }
        top.close();
    }

    function alert(oldmessage)
    {
        MessageShow(f_GetMessage(oldmessage));
    }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" Runat="Server">
    <atlas:ScriptManager ID="sm" EnablePageMethods="true" runat="server"></atlas:ScriptManager>
    <IFCAUI:SysToolbar ID="SysToolBar2" runat="server" Style="width: 100%" ShowSettingMenu="false"
        TranslateBseNo="CB.GIROBatchGenerate" TabNo="CB.GIROBatchGenerate" MenuClass="CB.GIROBatchGenerate"
        MenuNo="mcorp-15-07" ShowFilter="false" ShowInterface="false" ShowListView="false"
        ShowQryCondition="false" ShowSort="false" />
</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="RightContentPlace" Runat="Server">
    <IFCAUI:SysTabEdit ID="SysTabEdit1" runat="server" TabNo="CB.GIROBatchGenerate" AllowPaging="false" />
    <input type="hidden" id="hidReceiptIDs" runat="server" />
    <div style="padding:2px 4px; color:red;"><asp:Label ID="lblWarning" runat="server" /></div>
    <IFCAUI:SysContainer ID="SysContainer1" runat="server" TcdTabNo="CB.GIROBatchGen" Width="100%" Height="350px">
        <IFCAUI:SysContainerTab ID="SysContainerTab1" runat="server" TcdCardNo="CB.GIROBatchCard">
            <iframe style="height:430px; width: 100%;" scrolling="no" frameborder="0" id="giroDetail" name="giroDetail" src=""></iframe>
        </IFCAUI:SysContainerTab>
    </IFCAUI:SysContainer>
</asp:Content>
<asp:Content ID="Content5" ContentPlaceHolderID="FooterContent" Runat="Server">
    <pb1:PageBottom ID="PageBottom1" runat="server" BseNo="CB.GIROBatchGenerate" CurrentID="" />
</asp:Content>
