using System;
using System.Data;
using System.Web.Services;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Business.Finance.Generic;

// LKHS-325: GIRO Batch Listing - popup from Collection Verification (same structure as ARGIROCollectionLst.aspx.cs)
// Query string: CompanyID. All batches of the company (history, view only), Exported (waiting for the DBS result) first
// (Gunner 05/11). Import / Verify / Reset only for an Exported batch (checked in JS and in GIROBatchService).
// Reset = page method here; Import / Verify open the Upload / Pre-Check screens, Confirm runs there (doc v01.01).
public partial class CashFlow_ARGIROBatchLst : IFCA.Web.UI.Page
{
    protected string ContextMnuNo = "";

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected override void OnInit(EventArgs e)
    {
        this.SysToolBar3.Title = Strings.GetString("CB.GIROBatchList_Title");

        int companyID = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        this.CompanyID.Value = companyID.ToString();

        if (!Page.IsPostBack)
        {
            this.SysList1.SelectCommandText = companyID > 0
                ? string.Format("select * from View_CB_ReceiptGroup_GIRO where CompanyID={0} order by case when RecordStatus = 'Exported' then 0 else 1 end, CBReceiptGroupID desc", companyID)
                : "select * from View_CB_ReceiptGroup_GIRO where 1=2";

            Common.pf_LoadCustomization(this, "", "Init");

            // toolbar buttons of this menu -> used by JS OnBeforeMenu()
            try
            {
                DataTable rs = DataAccessHelper.ExecuteDataset(string.Format(
                    "select ContextMnuNo from Sys_ContextMenu where MnuNo='{0}' and MnuClass='{1}' order by SeqNo",
                    SysToolBar3.MenuNo, SysToolBar3.MenuClass)).Tables[0];
                foreach (DataRow row in rs.Rows)
                    ContextMnuNo += "," + row["ContextMnuNo"].ToString();
                if (ContextMnuNo.Length > 0)
                    ContextMnuNo = ContextMnuNo.Substring(1);
            }
            catch { }
        }
        // NOTE: same as ARGIROCollectionLst / ACPaymentLst, base.OnInit(e) not called
    }

    [WebMethod(true)]
    public static string ResetBatch(int receiptGroupID)
    {
        return RunAction(receiptGroupID);
    }

    // business errors (GIROException) are returned as the message; other errors are thrown to the page (f_OnFailure)
    private static string RunAction(int receiptGroupID)
    {
        int userID = FNCommon.ObjToInt(SysContext.CurrentUserId);
        try
        {
            GIROBatchService svc = new GIROBatchService();
            return svc.ResetBatch(receiptGroupID, userID);
        }
        catch (GIROException ex)
        {
            return ex.Message;
        }
    }
}
