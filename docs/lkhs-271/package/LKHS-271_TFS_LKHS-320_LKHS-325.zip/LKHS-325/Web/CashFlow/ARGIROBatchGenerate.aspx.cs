using System;
using System.Data;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.UI.Controls;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Web.Common;
using IFCA.Business.Finance.Generic;
using Infragistics.WebUI.WebSchedule;

// LKHS-325: GIRO Batch Generation - popup from Collection Verification (same structure as ARGIROCollectionGenerate.aspx.cs)
// Query string: CompanyID, BankAccountID (empty = not selected yet; the Bank dropdown reloads the popup with it)
// Save -> GIROBatchService.CreateBatch (batch + receipts + UFF file in one transaction)
public partial class CashFlow_ARGIROBatchGenerate : IFCA.Web.UI.Page
{
    protected int currCompanyID;
    protected int giroBankAccountID;
    protected string bankDDLClientID = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        ReadQueryString();
        if (!Page.IsPostBack)
        {
            string title = Strings.GetString("CB.GIROBatch_Title");
            this.Page.Title = title;
            this.SysToolBar2.Title = title;
            SysTabEdit1.PrimaryKeyValue = "0";

            if (currCompanyID <= 0)
                lblWarning.Text = Strings.GetString("CB.GIROBatch_SelectCompany");
            else if (companyBanks == null || companyBanks.Rows.Count == 0)
                lblWarning.Text = Strings.GetString("CB.GIROBatch_NoGIROBank");

            LoadBankHeader();
            SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "DocumentDate", DateTime.Today);
            SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "DocumentCount", 0);
            SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "TotalAmt", 0m);
        }
    }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        Common.pf_LoadCustomization(this, "CB.GIROBatchGenerate", "Init");
        SysToolBar2.CustomControlsCreated += new EventHandler(SysToolBar2_CustomControlsCreated);
        this.SysTabEdit1.CustomControlsCreated += new EventHandler(SysTabEdit1_CustomControlsCreated);
    }

    // dropdown items replaced AFTER SysTabEdit.OnPreRender (it DataBinds its dropdowns there; touching them before
    // gives "'SelectedIndex' and 'SelectedValue' attributes are mutually exclusive")
    protected override void OnPreRenderComplete(EventArgs e)
    {
        base.OnPreRenderComplete(e);
        FillBankList();
        FillPurposeList();
        DropDownList ddl = BankDDL();
        if (ddl != null) bankDDLClientID = ddl.ClientID;
    }

    void SysTabEdit1_CustomControlsCreated(object sender, EventArgs e)
    {
    }

    void SysToolBar2_CustomControlsCreated(object sender, EventArgs e)
    {
        SysToolbarButton saveButton = SysToolBar2.FindContextButton("Save");
        if (saveButton != null)
            saveButton.Click += new EventHandler(SaveButton_Click);
    }

    #region internal function
    private DataTable companyBanks;

    // CompanyID / BankAccountID from the query string; only one GIRO bank in the company -> that bank (load and save)
    private void ReadQueryString()
    {
        currCompanyID = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        giroBankAccountID = FNCommon.ObjToInt(Request.QueryString["BankAccountID"]);
        companyBanks = currCompanyID > 0 ? GIROBatchService.GetCompanyBanks(currCompanyID) : null;
        if (companyBanks == null) return;
        if (giroBankAccountID <= 0 && companyBanks.Rows.Count == 1)
            giroBankAccountID = Convert.ToInt32(companyBanks.Rows[0]["BankAccountID"]);
        if (companyBanks.Select("BankAccountID = " + giroBankAccountID).Length == 0)
            giroBankAccountID = 0;     // not a GIRO bank of this company
    }

    // dropdown of the SysTabEdit: control id = relation name (as PayMethod of step 6); field name kept as fallback
    private DropDownList FindDDL(string relationName, string fieldName)
    {
        DropDownList ddl = SysTabEdit1.FindControl(relationName) as DropDownList;
        if (ddl == null) ddl = SysTabEdit1.FindControl(fieldName) as DropDownList;
        return ddl;
    }

    private DropDownList BankDDL() { return FindDDL("GiroBank", "GiroBankStringCode"); }
    private DropDownList PurposeDDL() { return FindDDL("PurposeCode", "PurposeCodeStringCode"); }

    // company GIRO banks (CF_CompanyGiroBank)
    private void FillBankList()
    {
        DropDownList ddl = BankDDL();
        if (ddl == null) return;
        ddl.Items.Clear();
        ddl.SelectedIndex = -1;
        ddl.Items.Add(new ListItem("", ""));
        if (companyBanks != null)
            foreach (DataRow r in companyBanks.Rows)
                ddl.Items.Add(new ListItem(Convert.ToString(r["BankName"]) + " - " + Convert.ToString(r["AccountNo"]), Convert.ToString(r["BankAccountID"])));
        ListItem sel = ddl.Items.FindByValue(giroBankAccountID.ToString());
        if (sel != null) sel.Selected = true;
    }

    // DBS Purpose Code (View_CB_GIROLookup)
    private void FillPurposeList()
    {
        DropDownList ddl = PurposeDDL();
        if (ddl == null) return;
        string posted = Page.IsPostBack ? Request.Form[ddl.UniqueID] : null;
        ddl.Items.Clear();
        ddl.SelectedIndex = -1;
        ddl.Items.Add(new ListItem("", ""));
        foreach (DataRow r in GIROBatchService.GetPurposeCodes().Rows)
        {
            string code = Convert.ToString(r["LookupCode"]);
            string name = Convert.ToString(r["LookupName"]);
            ddl.Items.Add(new ListItem(name == code || name == "" ? code : code + " - " + name, code));
        }
        ListItem sel = string.IsNullOrEmpty(posted) ? null : ddl.Items.FindByValue(posted);
        if (sel != null) sel.Selected = true;
    }

    // Account No / Currency of the selected bank (read-only)
    private void LoadBankHeader()
    {
        if (currCompanyID <= 0 || giroBankAccountID <= 0) return;
        GIROBankSetup bank = GIROBatchService.LoadBank(currCompanyID, giroBankAccountID);
        if (bank == null) return;
        SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "ACNo", bank.AccountNo);
        SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "Currency", bank.CurrencyCode);
    }

    private static List<int> ParseIDs(string ids)
    {
        List<int> list = new List<int>();
        if (string.IsNullOrEmpty(ids)) return list;
        ids = ids.Trim().Trim(',');
        if (!Regex.IsMatch(ids, @"^\d+(,\d+)*$")) return list;
        foreach (string s in ids.Split(','))
            list.Add(Convert.ToInt32(s));
        return list;
    }

    private DateTime? GetTabDate(string name)
    {
        WebDateChooser ctl = SysTabEdit1.FindControl(name) as WebDateChooser;
        if (ctl == null || ctl.Value == null || ctl.Value == DBNull.Value || ctl.Value.ToString() == "") return null;
        DateTime d;
        if (DateTime.TryParse(ctl.Value.ToString(), out d)) return d.Date;
        return null;
    }

    void ShowMessStr(string msgText)
    {
        Message msg = new Message();
        msg.AutoClientJs = "MessageClose();";
        msg.MsgTitle = Strings.GetString("CommonSaveTitle");
        msg.Msg = msgText;
        msg.TipPic = Message.EnumTipPicType.Remind;
        msg.MsgType = Message.EnumMsgType.OKOnly;
        Page.ClientScript.RegisterStartupScript(GetType(), "Result", msg.GetHtml());
    }
    #endregion

    #region Save
    void SaveButton_Click(object sender, EventArgs e)
    {
        ReadQueryString();

        GIROBatchRequest req = new GIROBatchRequest();
        req.CompanyID = currCompanyID;
        req.BankAccountID = giroBankAccountID;      // query string / the only GIRO bank (dropdown change reloads the popup)
        req.UserID = FNCommon.ObjToInt(SysContext.CurrentUserId);
        req.ReceiptIDs = ParseIDs(hidReceiptIDs.Value);

        TextBox refNo = SysTabEdit1.FindControl("ReferenceNo") as TextBox;
        req.ReferenceNo = refNo != null ? refNo.Text.Trim() : "";
        DateTime? paymentDate = GetTabDate("DocumentDate");
        req.PaymentDate = paymentDate.HasValue ? paymentDate.Value : DateTime.MinValue;
        DropDownList purpose = PurposeDDL();
        req.PurposeCode = purpose != null ? (Request.Form[purpose.UniqueID] ?? "") : "";

        try
        {
            GIROBatchResult r = new GIROBatchService().CreateBatch(req);
            string text = string.Format(Strings.GetString("CB.GIROBatch_SaveSuccess"),
                r.GroupNo, r.ReceiptCount, r.LineCount, r.TotalAmt.ToString("#,##0.00"), Message.FormatMessage(r.FileName));   // file name only (path has \ for JS)
            NameValueCollection buttons = new NameValueCollection();
            buttons.Add(Strings.GetString("Close"), "f_AfterSave();");
            Message msg = new Message(text, buttons);
            msg.MsgType = Message.EnumMsgType.No;
            Page.ClientScript.RegisterStartupScript(GetType(), "Result", msg.GetHtml());
        }
        catch (GIROException ex)
        {
            ShowMessStr(JsMessage(ex.Message));
        }
        catch (Exception ex)
        {
            ShowMessStr(Strings.GetString("ErrorMessage") + "<br>" + JsMessage(ex.Message));
        }
    }

    /// <summary>Message text safe for the JS popup (Message.GetHtml puts it in a JS string literal):
    /// one line per problem, CR/LF removed (system messages like IOException end with "\r\n" -> JS syntax error,
    /// popup not shown, page only reloads), \ of paths kept, each line escaped (debtor names may contain quotes).</summary>
    static string JsMessage(string text)
    {
        List<string> lines = new List<string>();
        foreach (string line in (text ?? "").Replace("\r", "").Replace("<br>", "\n").Split('\n'))
            if (line.Trim() != "") lines.Add(Message.FormatMessage(line.Trim().Replace("\\", "\\\\")));
        return string.Join("<br>", lines.ToArray());
    }
    #endregion
}
