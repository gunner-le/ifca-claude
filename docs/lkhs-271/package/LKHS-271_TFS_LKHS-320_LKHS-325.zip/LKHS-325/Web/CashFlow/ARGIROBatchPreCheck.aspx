<%@ Page Language="C#" MasterPageFile="~/Common/MasterBarCondList.master" AutoEventWireup="true" CodeFile="ARGIROBatchPreCheck.aspx.cs" Inherits="CashFlow_ARGIROBatchPreCheck" Title="Untitled Page" %>

<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%-- LKHS-325: GIRO Batch Pre-Check Screen (Stanley doc v01.01), opened from the GIRO Batch Listing:
       Import -> Upload Screen -> selected file -> Pre-Check WITH attachment info (debtors in the DBS file = Failed, others = Success)
       Verify -> Pre-Check WITHOUT attachment info (all Success)
     Grid: Document No / Debtor Name / Amount / GIRO Status (+ Return Reason of DBS). Read only.
     Confirm blocked when the file cannot be used / a record of the file is not in the batch (Stanley 06/11). --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" runat="Server">
<script language="javascript" type="text/javascript">
var giroGroupID = '<%=receiptGroupID %>';
var giroFileName = '<%=fileNameJs %>';
var giroCanConfirm = <%=canConfirm ? "true" : "false" %>;

function f_GetMessage(tip)
{
    return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
}

function f_OnFailure(obj)
{
    MessageClose();
    MessageShow(f_GetMessage(obj._message));
}

function f_MessageWait()
{
    MessageShow({Title:'<%=Strings.GetString("MessageRemind") %>',Tip:'<%=Strings.GetString("SPleaseWait") %>',Pic:"Wait",Buttons:[]});
}

/* Confirm: batch Completed, Success receipts verified (server re-checks everything) */
function f_GIROPreCheckConfirm()
{
    if (!giroCanConfirm)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIROPreCheck_CannotConfirm") %>"));
        return;
    }
    var msg = {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:"<%=Strings.GetString("CB.GIROPreCheck_ConfirmAsk") %>",Pic:"Remind",
               Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:"f_DoConfirm()"},{Name:"<%=Strings.GetString("Cancel") %>",Event:""}]};
    MessageShow(msg);
}
function f_DoConfirm()
{
    f_MessageWait();
    PageMethods.ConfirmBatch(parseInt(giroGroupID, 10), giroFileName, f_ConfirmDone, f_OnFailure);
}
// result "OK|message" -> Listing refreshed + this page closed; "ERR|message" -> message, page stays
function f_ConfirmDone(result)
{
    MessageClose();
    var ok = (result != null && result.indexOf("OK|") == 0);
    var text = (result == null) ? "" : result.substring(result.indexOf("|") + 1);
    if (!ok)
    {
        MessageShow(f_GetMessage(text));
        return;
    }
    try
    {
        window.opener.f_ActionDone(text);
        window.close();
    }
    catch (e)
    {
        MessageShow(f_GetMessage(text));
    }
}

function f_Close()
{
    window.close();
}

// toolbar button = <span onclick="if(!this.isDisabled){...}">; isDisabled is IE-only -> set + grey (same as ARGIROBatchLst)
function f_SetButton(obj, disable)
{
    obj.disabled = disable ? 1 : 0;
    obj.isDisabled = disable ? true : false;
    obj.style.color = disable ? "#A0A0A0" : "";
    obj.style.cursor = disable ? "default" : "pointer";
}

function f_init()
{
    var obj = document.getElementById("Confirm");
    if (obj != null) f_SetButton(obj, !giroCanConfirm);
}

function alert(oldmessage)
{
    MessageShow(f_GetMessage(oldmessage));
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" runat="Server">
    <IFCAUI:SysToolbar ID="SysToolBar3" runat="server" Style="width: 100%"
        ShowSettingMenu="false" LstNo="CB.GIROPreCheck" TranslateBseNo="CB.GIROPreCheck"
        MenuClass="CB.GIROPreCheck" MenuNo="mcorp-15-07" ShowEditView="false" ShowFilter="false"
        ShowHelp="false" ShowHelpSetting="false" ShowInterface="false" ShowSort="false"></IFCAUI:SysToolbar>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="SearchContent" runat="Server">
    <%-- no criteria (doc: NA): batch info + summary; problems of the attachment in red (Confirm disabled) --%>
    <div style="padding: 4px 6px; line-height: 18px;"><asp:Literal ID="litInfo" runat="server"></asp:Literal></div>
    <div style="padding: 2px 6px 6px 6px; color: #CC0000; line-height: 18px;"><asp:Literal ID="litError" runat="server"></asp:Literal></div>
    <input type="hidden" id="LstOrder" value="1" />
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="ListContent" runat="server">
    <atlas:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true"></atlas:ScriptManager>
    <IFCAUI:SysList2 UseCheckBox="false" StationaryMargins="Header" runat="server" ID="SysList1"
        LstNo="CB.GIROPreCheck" Height="95%" Width="100%" ShowContextMenu="false" PageSize="1000" AllowPaging="false" ShowFooter="true">
    </IFCAUI:SysList2>
</asp:Content>
