<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ARGIROBatchGenerateDetail.aspx.cs" Inherits="CashFlow_ARGIROBatchGenerateDetail" %>
<%-- LKHS-325: GIRO Batch Generation - receipt grid of the popup (same structure as ARGIROCollectionGenerateDetail.aspx)
     All GIRO receipts 'Generated' of the selected bank; ticked rows = receipts of the new batch --%>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Common/Finance/FNCommon.js"></script>
    <script type="text/javascript">
    var LIB_URL = "..";
    </script>
    <script src="../Lib/CommonScriptNET.js?version=<%=Application["JSVersion"]%>" type="text/javascript"></script>
    <script type="text/javascript" language="javascript">
        // ticked receipts -> CBReceiptID list (id field of the grid)
        function f_GetCheckedIDs()
        {
            var ids = gridManager2.GetSelectedRowIds();
            return (ids == null) ? "" : ids.toString();
        }

        // No. of Receipts / Total Amount of the ticked rows -> popup header
        function f_CalcSummary()
        {
            var ids = "," + f_GetCheckedIDs() + ",";
            var cnt = 0, amt = 0, firstRef = "";
            var rows = gridManager2.GetValidRows();
            for (var m = 0; m < rows.length; m++)
            {
                var id = gridManager2.GetValueByName(rows[m], "cbreceiptid");
                if (ids.indexOf("," + id + ",") >= 0)
                {
                    cnt++;
                    if (firstRef == "") firstRef = gridManager2.GetValueByName(rows[m], "referenceno");
                    amt = CallFloat(parseFloat(amt, 2), parseFloat(gridManager2.GetValueByName(rows[m], "receiptamt"), 2) || 0, 0);
                }
            }
            try { parent.f_SetSummary(cnt, amt); } catch (e) { }
            if (cnt > 0) { try { parent.f_SuggestReference(firstRef); } catch (e) { } }
        }

        function f_init()
        {
            gridManager2.AfterCellUpdateHandler = function (row, fieldName, value) {
                if (fieldName == "checkboxselecter") f_CalcSummary();
            }
            f_CalcSummary();
        }
    </script>
</head>
<body onload="try{f_init();}catch(e){}">
    <form id="form1" runat="server" style="margin: 0; padding: 0;">
    <atlas:ScriptManager runat="Server" ID="sm" EnablePageMethods="true">
    </atlas:ScriptManager>
        <IFCAUI:SysList2 runat="server" ID="SysList1" LstNo="CB.GIROBatchDetail" ShowContextMenu="false" PageSize="1000" AllowPaging="false" ShowFooter="true" Height="100%" UseCheckBox="true" BorderStyle="None" />
    </form>
</body>
</html>
