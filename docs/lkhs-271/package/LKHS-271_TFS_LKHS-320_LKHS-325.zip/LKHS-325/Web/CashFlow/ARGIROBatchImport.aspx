<%@ Page Language="C#" MasterPageFile="~/Common/MasterBarCondList.master" AutoEventWireup="true" CodeFile="ARGIROBatchImport.aspx.cs" Inherits="CashFlow_ARGIROBatchImport" Title="Untitled Page" %>

<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%-- LKHS-325: GIRO Batch - Upload Screen (Stanley doc v01.01), opened by Import on the GIRO Batch Listing.
     Lists all file names of the Import Path of the batch's GIRO bank (CF_CompanyGiroBank.ARImportPath).
     Select: the ticked file name goes back to the Listing (window.opener.f_OpenPreCheck), then this page closes.
     Same structure as ARGIROCollectionSelect.aspx. --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" runat="Server">
<script language="javascript" type="text/javascript">
function f_GetMessage(tip)
{
    return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
}

// exactly one ticked file -> its name back to the Listing
function f_SelectFile()
{
    var ids = gridManager2.GetSelectedRowIds();
    if (ids == null || ids.toString() == "")
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected") %>"));
        return;
    }
    if (ids.toString().indexOf(",") >= 0)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIROImport_SelectOneFile") %>"));
        return;
    }
    var fileName = "";
    var rows = gridManager2.GetValidRows();
    for (var m = 0; m < rows.length; m++)
    {
        if (String(gridManager2.GetValueByName(rows[m], "fileno")) == ids.toString())
        {
            fileName = gridManager2.GetValueByName(rows[m], "filename");
            break;
        }
    }
    if (fileName == null || fileName == "") return;
    try
    {
        window.opener.f_OpenPreCheck(fileName);
    }
    catch (e)
    {
    }
    window.close();
}

function f_Close()
{
    window.close();
}

function f_init()
{
    var msg = document.getElementById("giroImportMsg");
    if (msg != null && msg.innerHTML != "") MessageShow(f_GetMessage(msg.innerHTML));
}

function alert(oldmessage)
{
    MessageShow(f_GetMessage(oldmessage));
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" runat="Server">
    <IFCAUI:SysToolbar ID="SysToolBar3" runat="server" Style="width: 100%"
        ShowSettingMenu="false" LstNo="CB.GIROImportFile" TranslateBseNo="CB.GIROImportFile"
        MenuClass="CB.GIROImportFile" MenuNo="mcorp-15-07" ShowEditView="false" ShowFilter="false"
        ShowHelp="false" ShowHelpSetting="false" ShowInterface="false" ShowSort="false"></IFCAUI:SysToolbar>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="SearchContent" runat="Server">
    <%-- no criteria (doc: NA); import path shown for information, error of the path shown as message --%>
    <div style="padding: 4px 6px;"><asp:Literal ID="litPath" runat="server"></asp:Literal></div>
    <div id="giroImportMsg" style="display: none;"><asp:Literal ID="litMsg" runat="server"></asp:Literal></div>
    <input type="hidden" id="LstOrder" value="1" />
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="ListContent" runat="server">
    <atlas:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true"></atlas:ScriptManager>
    <IFCAUI:SysList2 UseCheckBox="true" StationaryMargins="Header" runat="server" ID="SysList1"
        LstNo="CB.GIROImportFile" Height="95%" Width="100%" ShowContextMenu="false" PageSize="1000" AllowPaging="false">
    </IFCAUI:SysList2>
</asp:Content>
