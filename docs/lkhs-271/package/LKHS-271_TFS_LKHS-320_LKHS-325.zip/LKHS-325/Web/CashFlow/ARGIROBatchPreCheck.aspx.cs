using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Business.Finance.Generic;

// LKHS-325: GIRO Batch Pre-Check Screen (Stanley doc v01.01). Query string: ReceiptGroupID [, File = name in the Import Path].
// GIRO Status of each receipt = GIROBatchService.GetPreCheck (no File = Verify -> all Success).
// Nothing is saved here; Confirm (page method) re-runs the same check inside the transaction (GIROBatchService.ConfirmBatch).
public partial class CashFlow_ARGIROBatchPreCheck : IFCA.Web.UI.Page
{
    protected int receiptGroupID = 0;
    protected string fileNameJs = "";
    protected bool canConfirm = false;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected override void OnInit(EventArgs e)
    {
        this.SysToolBar3.Title = Strings.GetString("CB.GIROPreCheck_Title");
        receiptGroupID = FNCommon.ObjToInt(Request.QueryString["ReceiptGroupID"]);
        string fileName = (Request.QueryString["File"] ?? "").Trim();
        fileNameJs = fileName.Replace("\\", "\\\\").Replace("'", "\\'");

        if (!Page.IsPostBack)
        {
            GIROPreCheckResult pc = null;
            try
            {
                if (receiptGroupID > 0) pc = GIROBatchService.GetPreCheck(receiptGroupID, fileName == "" ? null : fileName);
            }
            catch (GIROException ex)
            {
                this.litError.Text = HttpUtility.HtmlEncode(ex.Message);
            }

            if (pc == null || pc.Lines.Count == 0)
            {
                this.SysList1.SelectCommandText = "select * from View_CB_Receipt_GIRO where 1=2";
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < pc.Lines.Count; i++)
                {
                    GIROPreCheckLine l = pc.Lines[i];
                    if (i > 0) sb.Append(",");
                    sb.AppendFormat("({0}, N'{1}', N'{2}')", l.ReceiptID, Sql(l.GIROStatus), Sql(l.ReturnReason));
                }
                // Failed first, then debtor / document
                this.SysList1.SelectCommandText = "select r.*, x.GIROStatus, x.ReturnReason from View_CB_Receipt_GIRO r inner join (values "
                    + sb.ToString() + ") x(PreCheckReceiptID, GIROStatus, ReturnReason) on x.PreCheckReceiptID = r.CBReceiptID"
                    + " order by case when x.GIROStatus = 'Failed' then 0 else 1 end, r.DebtorName, r.DocumentNo";
                canConfirm = pc.CanConfirm;
                this.litError.Text = string.Join("<br>", pc.Errors.Concat(pc.Unmatched).Select(x => HttpUtility.HtmlEncode(x)).ToArray());
            }
            this.litInfo.Text = BuildInfo(fileName, pc);
            Common.pf_LoadCustomization(this, "", "Init");
        }
        // NOTE: same as ARGIROBatchLst / ACPaymentLst, base.OnInit(e) not called
    }

    private static string Sql(string v)
    {
        return (v ?? "").Replace("'", "''");
    }

    // GIRO Batch No / Bank / Payment Date / attachment + count of Success / Failed
    private string BuildInfo(string fileName, GIROPreCheckResult pc)
    {
        if (receiptGroupID <= 0) return "";
        DataTable dt = DataAccessHelper.ExecuteDataTable(string.Format(
            "select GroupNo, BankName, ACNo, Currency, DocumentDate, TotalAmt from View_CB_ReceiptGroup_GIRO where CBReceiptGroupID = {0}", receiptGroupID));
        if (dt == null || dt.Rows.Count == 0) return "";
        DataRow g = dt.Rows[0];
        int success = pc == null ? 0 : pc.Lines.Count(x => x.GIROStatus == GIROBatchService.StatusSuccess);
        int failed = pc == null ? 0 : pc.Lines.Count(x => x.GIROStatus == GIROBatchService.StatusFailed);
        string date = g["DocumentDate"] == DBNull.Value ? "" : Convert.ToDateTime(g["DocumentDate"]).ToString("dd/MM/yyyy");
        string text = string.Format(Strings.GetString("CB.GIROPreCheck_Info"),
            g["GroupNo"], g["BankName"] + " " + g["ACNo"], g["Currency"], date,
            fileName == "" ? Strings.GetString("CB.GIROPreCheck_NoAttachment") : fileName, success, failed);
        return HttpUtility.HtmlEncode(text);
    }

    // "OK|message" = done (Listing refreshed, page closed); "ERR|message" = business error (page stays)
    [WebMethod(true)]
    public static string ConfirmBatch(int receiptGroupID, string fileName)
    {
        int userID = FNCommon.ObjToInt(SysContext.CurrentUserId);
        try
        {
            return "OK|" + new GIROBatchService().ConfirmBatch(receiptGroupID, string.IsNullOrEmpty(fileName) ? null : fileName, userID);
        }
        catch (GIROException ex)
        {
            return "ERR|" + ex.Message;
        }
    }
}
