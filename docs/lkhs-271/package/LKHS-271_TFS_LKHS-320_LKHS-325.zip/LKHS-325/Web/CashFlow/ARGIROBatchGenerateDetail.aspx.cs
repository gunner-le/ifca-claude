using System;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Business.Finance.Generic;

// LKHS-325: GIRO Batch Generation - receipt grid of the popup
// Query string: CompanyID, BankAccountID. No bank -> empty grid.
public partial class CashFlow_ARGIROBatchGenerateDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int companyID = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        int bankAccountID = FNCommon.ObjToInt(Request.QueryString["BankAccountID"]);

        if (companyID <= 0 || bankAccountID <= 0)
        {
            SysList1.SelectCommandText = "select * from View_CB_Receipt_GIRO where 1=2";
            return;
        }

        // same condition as GIROBatchService.CreateBatch (re-checked there inside the transaction)
        SysList1.SelectCommandText = string.Format(@"select * from View_CB_Receipt_GIRO
            where CompanyID = {0} and BankAccountID = {1} and GIRORecordStatus = 'Generated' and RecordStatus = 'Active'
              and isnull(GroupNo, '') = ''
            order by Module, DebtorName, DocumentNo", companyID, bankAccountID);

        Common.pf_LoadCustomization(this, "", "Init");
    }
}
