using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Business.Finance.Generic;

// LKHS-325: GIRO Batch - Upload Screen (Stanley doc v01.01). Query string: ReceiptGroupID.
// Grid = file names of the Import Path (no DB table: rows given as a VALUES list, FileNo = id of the grid).
// The path is not checked against the file name (Stanley 06/11: file name cannot be matched with the batch);
// the records of the file are checked on the Pre-Check screen. Files are not moved / renamed (done manually).
public partial class CashFlow_ARGIROBatchImport : IFCA.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected override void OnInit(EventArgs e)
    {
        this.SysToolBar3.Title = Strings.GetString("CB.GIROImport_Title");
        int groupID = FNCommon.ObjToInt(Request.QueryString["ReceiptGroupID"]);

        if (!Page.IsPostBack)
        {
            List<string> files = new List<string>();
            try
            {
                if (groupID > 0) files = GIROBatchService.ListImportFiles(groupID);
                this.litPath.Text = HttpUtility.HtmlEncode(Strings.GetString("CB.GIROImport_Path") + " " + GIROBatchService.GetImportPathText(groupID));
                if (files.Count == 0)
                    this.litMsg.Text = HttpUtility.HtmlEncode(Strings.GetString("CB.GIROImport_NoFile"));
            }
            catch (GIROException ex)
            {
                this.litMsg.Text = HttpUtility.HtmlEncode(ex.Message);
            }

            if (files.Count == 0)
            {
                this.SysList1.SelectCommandText = "select cast(0 as int) as FileNo, cast(N'' as nvarchar(260)) as Filename where 1=2";
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < files.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.AppendFormat("({0}, N'{1}')", i + 1, files[i].Replace("'", "''"));
                }
                // newest file first (ListImportFiles order)
                this.SysList1.SelectCommandText = "select f.FileNo, f.Filename from (values " + sb.ToString() + ") f(FileNo, Filename) order by f.FileNo";
            }
            Common.pf_LoadCustomization(this, "", "Init");
        }
        // NOTE: same as ARGIROCollectionSelect / ACPaymentLst, base.OnInit(e) not called
    }
}
