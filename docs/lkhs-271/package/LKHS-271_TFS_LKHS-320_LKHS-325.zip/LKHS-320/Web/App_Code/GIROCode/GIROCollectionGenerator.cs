using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Web.Common;
using IFCA.Business.Finance.Generic;
using IFCA.Business.Finance.CB;
using IFCA.Business.Finance.Resoureces.Service;

// LKHS-271 - AR Collection GIRO (DBS) - screen 6 "Generate GIRO Collection": create receipts.
//
// One run = one DB transaction (all or nothing):
//   1. lock the bills (UPDLOCK) and re-read their balance from View_CB_GIROCollectionPending
//   2. validate (still outstanding, same company / GIRO bank, collect amount <= balance)
//   3. group by ReceiptType (module) + DebtorID + CurrencyID  -> 1 receipt per group
//   4. per group: doc no (SysCode of the module), insert CB_Receipt (status Active), module handler allocates the bills
//   5. submit doc numbers, clear the popup working table, commit
// Module-specific logic is in GIROModuleHandlers.cs.
// LKHS-271 NOTE: pf_SaveCustomization hooks of the module screens are not called (client specific, not used by LKHS).
public class GIROCollectionGenerator
{
    /// <summary>Supported modules. A ReceiptType not listed here is refused (handler not written yet).</summary>
    public static readonly Dictionary<string, IGIROModuleHandler> Handlers = new Dictionary<string, IGIROModuleHandler>(StringComparer.OrdinalIgnoreCase)
    {
        { "MC_Fee", new GIRORentalHandler() },
        { "OD_Receipt", new GIROOtherReceivableHandler() },
        { "PM_Receipt", new GIROConstructionHandler() },
        { "PS_Payment", new GIROPropertySalesHandler() }
    };

    public GIROGenerateResult Generate(GIROGenerateRequest req)
    {
        if (req.Bills == null || req.Bills.Count == 0)
            throw new GIROException(Strings.GetString("CB.GIRO_NoDetail"));

        GIROGenerateResult result = new GIROGenerateResult();
        Dictionary<string, SysCodeCollection> docCodes = new Dictionary<string, SysCodeCollection>();

        DbConnection con = DataAccessHelper.CreateConnection();
        con.Open();
        DbTransaction tran = con.BeginTransaction();
        try
        {
            // 1-2. fresh bills + validation
            List<GIROBill> bills = LoadAndValidateBills(tran, req);

            // 3. groups
            var groups = bills
                .GroupBy(b => new { b.ReceiptType, b.DebtorID, b.CurrencyID })
                .OrderBy(g => g.Key.ReceiptType).ThenBy(g => g.First().DebtorName)
                .ToList();

            foreach (var g in groups)
            {
                if (string.IsNullOrEmpty(g.Key.ReceiptType) || !Handlers.ContainsKey(g.Key.ReceiptType))
                    throw new GIROException(string.Format(Strings.GetString("CB.GIRO_ModuleNotSupported"), g.First().Module));
            }

            // doc numbers: one SysCodeCollection per module doc code
            foreach (var codeGroup in groups.GroupBy(g => Handlers[g.Key.ReceiptType].DocCode))
            {
                docCodes[codeGroup.Key] = new SysCodeCollection(codeGroup.Key, DocAnchorType.Company, req.CompanyID, codeGroup.Count());
            }
            Dictionary<string, int> docIndex = docCodes.Keys.ToDictionary(k => k, k => 0);

            // 4. receipts
            foreach (var g in groups)
            {
                IGIROModuleHandler handler = Handlers[g.Key.ReceiptType];
                GIROReceiptContext ctx = new GIROReceiptContext();
                ctx.Request = req;
                ctx.ReceiptType = handler.ReceiptType;
                ctx.DebtorID = g.Key.DebtorID;
                ctx.DebtorName = g.First().DebtorName;
                ctx.CurrencyID = g.Key.CurrencyID;
                ctx.ExchangeRate = Convert.ToDecimal(Currency.GetCurrencyExchange(ctx.CurrencyID, req.CompanyID, DateTime.Now)); // as ArFeeAdd2.getExchangeRate
                ctx.Bills = g.OrderBy(b => b.DocumentNo).ToList();
                ctx.DocNo = docCodes[handler.DocCode][docIndex[handler.DocCode]++].ToString();

                ctx.ReceiptID = InsertReceipt(tran, handler, ctx);

                foreach (GIROBill bill in ctx.Bills)
                    handler.AllocateBill(tran, ctx, bill);

                handler.AfterReceiptCreated(tran, ctx);

                result.DocNos.Add(ctx.DocNo);
                result.BillCount += ctx.Bills.Count;
                result.TotalAmt += ctx.Bills.Sum(b => b.CollectAmt);
            }

            // 5. finish
            foreach (SysCodeCollection c in docCodes.Values)
                c.Submit(tran);

            if (!string.IsNullOrEmpty(req.GIROGuid))
                GIRODb.Execute(tran, "delete CB_GIROTempDetail where GIROGuid = @Guid", "@Guid", req.GIROGuid);

            tran.Commit();
            return result;
        }
        catch
        {
            foreach (SysCodeCollection c in docCodes.Values)
            {
                try { c.Cancel(tran); } catch { }
            }
            try { tran.Rollback(); } catch { }
            throw;
        }
        finally
        {
            con.Close();
        }
    }

    // fresh read inside the transaction (never trust the balance shown on screen)
    private List<GIROBill> LoadAndValidateBills(DbTransaction tran, GIROGenerateRequest req)
    {
        Dictionary<int, decimal> wanted = new Dictionary<int, decimal>();
        foreach (GIROBillRequest b in req.Bills)
        {
            if (b.CollectAmt <= 0) continue;
            wanted[b.BillID] = b.CollectAmt;
        }
        if (wanted.Count == 0)
            throw new GIROException(Strings.GetString("CB.GIRO_NoDetail"));

        string ids = string.Join(",", wanted.Keys.Select(k => k.ToString()).ToArray());   // ints only

        // lock the bills for the rest of the transaction (another collection on the same bill waits)
        GIRODb.Table(tran, "select BillID from AR_Trx with (updlock, rowlock) where BillID in (" + ids + ")");

        DataTable dt = GIRODb.Table(tran,
            @"select BillID, CompanyID, DebtorID, DebtorName, ReceiptType, Module, DocumentNo, DocumentDate, CurrencyID,
                     TrxExchangeRate, BalanceAmt, ItemCode, StakeHolderFlag, GIROBankAccountID
              from View_CB_GIROCollectionPending
              where BillID in (" + ids + ") and GIROBankAccountID = " + req.BankAccountID.ToString());   // view has 1 row per company GIRO bank

        Dictionary<int, DataRow> found = new Dictionary<int, DataRow>();
        foreach (DataRow r in dt.Rows) found[Convert.ToInt32(r["BillID"])] = r;

        List<string> errors = new List<string>();
        List<GIROBill> bills = new List<GIROBill>();
        foreach (KeyValuePair<int, decimal> w in wanted)
        {
            DataRow r;
            if (!found.TryGetValue(w.Key, out r))
            {
                errors.Add(GetDocNo(tran, w.Key));               // paid / voided / no longer GIRO
                continue;
            }
            decimal balance = Convert.ToDecimal(r["BalanceAmt"]);
            if (Convert.ToInt32(r["CompanyID"]) != req.CompanyID
                || Convert.ToInt32(r["GIROBankAccountID"]) != req.BankAccountID
                || (req.CurrencyID > 0 && Convert.ToInt32(r["CurrencyID"]) != req.CurrencyID)
                || Math.Round(w.Value, 2) > Math.Round(balance, 2))
            {
                errors.Add(Convert.ToString(r["DocumentNo"]));
                continue;
            }
            GIROBill bill = new GIROBill();
            bill.BillID = w.Key;
            bill.CompanyID = req.CompanyID;
            bill.DebtorID = Convert.ToInt32(r["DebtorID"]);
            bill.DebtorName = Convert.ToString(r["DebtorName"]);
            bill.ReceiptType = Convert.ToString(r["ReceiptType"]);
            bill.Module = Convert.ToString(r["Module"]);
            bill.DocumentNo = Convert.ToString(r["DocumentNo"]);
            bill.DocumentDate = r["DocumentDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(r["DocumentDate"]);
            bill.CurrencyID = Convert.ToInt32(r["CurrencyID"]);
            bill.TrxExchangeRate = r["TrxExchangeRate"] == DBNull.Value ? 1m : Convert.ToDecimal(r["TrxExchangeRate"]);
            bill.BalanceAmt = balance;
            bill.CollectAmt = Math.Round(w.Value, 2);
            bill.ItemCode = Convert.ToString(r["ItemCode"]);
            bill.StakeHolderFlag = r["StakeHolderFlag"] == DBNull.Value ? "N" : Convert.ToString(r["StakeHolderFlag"]);
            bills.Add(bill);
        }

        if (errors.Count > 0)
            throw new GIROException(Strings.GetString("CB.GIRO_BillChanged") + "<br>" + string.Join(", ", errors.ToArray()));

        return bills;
    }

    private static string GetDocNo(DbTransaction tran, int billID)
    {
        object o = GIRODb.Scalar(tran, "select DocumentNo from AR_Trx where BillID = @BillID", "@BillID", billID);
        return (o == null || o == DBNull.Value) ? billID.ToString() : o.ToString();
    }

    private int InsertReceipt(DbTransaction tran, IGIROModuleHandler handler, GIROReceiptContext ctx)
    {
        GIROGenerateRequest req = ctx.Request;
        decimal amt = ctx.Bills.Sum(b => b.CollectAmt);
        decimal baseAmt = Math.Round(amt * ctx.ExchangeRate, 2);

        // column list follows CB_Receipt rows created by Rental ArFeeAdd2 (status Active, verified later)
        Dictionary<string, object> f = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        f["CompanyID"] = req.CompanyID;
        f["DocNo"] = ctx.DocNo;
        f["BankAccountID"] = req.BankAccountID;
        f["DebtorID"] = ctx.DebtorID;
        f["PaidBy"] = ctx.DebtorName;
        f["ReferenceNo"] = string.IsNullOrEmpty(req.ReferenceNo) ? (object)DBNull.Value : req.ReferenceNo;
        f["ReceiptType"] = ctx.ReceiptType;
        f["PayMethod"] = req.PayMethodID;
        f["DocumentDate"] = req.PaymentDate.Date;
        f["TransactionDate"] = req.PaymentDate.Date;
        f["CurrencyID"] = ctx.CurrencyID;
        f["ExchangeRate"] = ctx.ExchangeRate;
        f["DocumentAmt"] = amt;
        f["BaseAmt"] = baseAmt;
        f["ActualAmt"] = RoundingHelper.GetAmount(req.CompanyID, ctx.CurrencyID, req.PayMethodID, amt);
        f["ActualBaseAmt"] = RoundingHelper.GetAmount(req.CompanyID, ctx.CurrencyID, req.PayMethodID, baseAmt);
        f["AllocBalance"] = 0m;                  // fully allocated
        f["BankCharge"] = 0m;
        f["Remark"] = "GIRO Generation";        // Stanley note 12/10: Description default "GIRO Generation"
        f["IsGiroReceipt"] = "Y";              // Stanley note 12/10: mark all generated collections
        f["GIRORecordStatus"] = "Generated";   // spec v1.2 1a.ii: Generated -> Exported (batch) -> Completed / Failed (import)
        f["RecordStatus"] = "Active";
        f["CreateUserID"] = req.UserID;
        f["ModifyUserID"] = req.UserID;

        handler.FillReceiptFields(ctx, f);

        List<string> cols = f.Keys.ToList();
        StringBuilder sql = new StringBuilder();
        sql.Append("insert into CB_Receipt (").Append(string.Join(", ", cols.ToArray())).Append(", CreateDate, ModifyDate) values (");
        sql.Append(string.Join(", ", cols.Select(c => "@" + c).ToArray())).Append(", getdate(), getdate()); select cast(scope_identity() as int);");

        List<object> args = new List<object>();
        foreach (string c in cols) { args.Add("@" + c); args.Add(f[c]); }
        return Convert.ToInt32(GIRODb.Scalar(tran, sql.ToString(), args.ToArray()));
    }
}

/// <summary>Small parameterized SQL helper on the current transaction.</summary>
public static class GIRODb
{
    private static DbCommand Cmd(DbTransaction tran, string sql, object[] args)
    {
        DbCommand cmd = tran.Connection.CreateCommand();
        cmd.Transaction = tran;
        cmd.CommandText = sql;
        cmd.CommandTimeout = 300;
        for (int i = 0; i + 1 < args.Length; i += 2)
        {
            DbParameter p = cmd.CreateParameter();
            p.ParameterName = Convert.ToString(args[i]);
            p.Value = args[i + 1] ?? DBNull.Value;
            cmd.Parameters.Add(p);
        }
        return cmd;
    }

    public static int Execute(DbTransaction tran, string sql, params object[] args)
    {
        using (DbCommand cmd = Cmd(tran, sql, args)) return cmd.ExecuteNonQuery();
    }

    public static object Scalar(DbTransaction tran, string sql, params object[] args)
    {
        using (DbCommand cmd = Cmd(tran, sql, args)) return cmd.ExecuteScalar();
    }

    public static DataTable Table(DbTransaction tran, string sql, params object[] args)
    {
        DataTable dt = new DataTable();
        using (DbCommand cmd = Cmd(tran, sql, args))
        using (DbDataReader rd = cmd.ExecuteReader())
            dt.Load(rd);
        return dt;
    }
}
