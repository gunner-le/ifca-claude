using System;
using System.Collections.Generic;
using System.Data.Common;
using IFCA.Framework.PS.BL.Collection;   // Alloction (same usings as PSAccount/PSReceiptAdd.aspx.cs)
using IFCA.Framework.PS.BL.Common;
using IFCA.Framework.PS.BL.Sales;        // AccountSetting (same using as PSAccount/ArReceiptDelete.aspx.cs)
using IFCA.Framework.BL;

// LKHS-271 - AR Collection GIRO (DBS) - Property Sales.
// Kept in its own file: it is the only handler that depends on the PS BL assembly.

/// <summary>
/// Property Sales - from PSAccount/PSReceiptAdd.aspx.cs (btnSaveData_Click / SaveAllocData), Sale-11-02.
/// Allocation is NOT copied: it calls the module's own BL Alloction.AddCBAndBill (allocation + bill balance),
/// exactly with the arguments of SaveAllocData:
///   baseAmt = pay amount * BILL rate, currency / rate = RECEIPT, alloc date = receipt date, bill StakeHolderFlag.
/// Receipt: doc code 036 (same as Rental), AllocBalance = DocumentAmt at insert (screen value, the BL reduces it).
/// Not applied to GIRO (LKHS-271 TEMP): floating late-payment interest (SaleInterest.ReCalc / PostFloatBill),
/// plan allocation of unallocated balance (always fully allocated), negative debit bills.
/// </summary>
public class GIROPropertySalesHandler : IGIROModuleHandler
{
    public string ReceiptType { get { return "PS_Payment"; } }

    // PSReceiptAdd: docCode = "036" (pf_LoadCustomization "GetSysCode" not used by LKHS)
    public string DocCode { get { return "036"; } }

    public void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields)
    {
        // PSReceiptAdd: dicother "allocbalance" = DocumentAmt
        fields["AllocBalance"] = fields["DocumentAmt"];
    }

    public void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill)
    {
        // LKHS-271 GIRO forex: the PS BL (AddCBAndBill) works with the converted amount (pay amount * bill rate) for the bill balance,
        // receipt AllocBalance and AllocAmt -> not correct for a foreign-currency bill (also on PSReceiptAdd) -> refused for GIRO.
        if (bill.CurrencyID != GIROHandlerBase.GetBaseCurrencyID(tran))
            throw new GIROException("Property Sales bill in foreign currency is not supported by GIRO (" + bill.DocumentNo + ").");

        decimal baseAmt = bill.CollectAmt * bill.TrxExchangeRate;   // PSReceiptAdd: payamt * row exchangerate
        Alloction alloction = new Alloction();
        alloction.AddCBAndBill(tran, ctx.ReceiptID, bill.BillID, baseAmt, ctx.CurrencyID, ctx.ExchangeRate,
                               ctx.Request.PaymentDate.Date, string.IsNullOrEmpty(bill.StakeHolderFlag) ? "N" : bill.StakeHolderFlag);
    }

    public void AfterReceiptCreated(DbTransaction tran, GIROReceiptContext ctx)
    {
    }

    /// <summary>LKHS-325: same as PSAccount/ArReceiptDelete.aspx.cs (DataSave, button Voide of the PS receipt list), in the GIRO transaction:
    ///   blocked when void date is before the month-end closing date or the receipt has a refund (same checks / messages),
    ///   receipt Voided + AllocBalance 0 + void info, each allocation not Inactive -> Inactive and bill BalanceAmt += BaseAmt.
    /// Not applied (client hooks of the screen): pf_SaveCustomization ArReceiptDelete_SaveArTrxForex, PostSalesForce, ARRECEIPTDELETE API.
    /// An allocation without bill is only set Inactive (the screen SQL would fail on it).</summary>
    public void CancelReceipt(DbTransaction tran, GIROCancelContext ctx)
    {
        DateTime minDate = AccountSetting.GetAccountMinDate(ctx.CompanyID);
        if (minDate.CompareTo(ctx.VoidDate) > 0)
            throw new GIROException(ctx.DocNo + ": " + Strings.GetString("VoidDateErr") + ": " + minDate.ToShortDateString());

        object refund = GIRODb.Scalar(tran, @"select count(*) from AR_Allocation
            where RefundID is not null and RecordStatus <> 'InActive' and BillID is null and ReceiptID = @ID", "@ID", ctx.ReceiptID);
        if (Convert.ToInt32(refund) != 0)
            throw new GIROException(ctx.DocNo + ": " + Strings.GetString("MC.CurReceiptRefund"));

        GIRODb.Execute(tran, @"
            update CB_Receipt set RecordStatus = 'Voided', AllocBalance = 0, VoidUserID = @UserID, VoidRemark = @Remark, VoidDate = @VoidDate,
                   ModifyUserID = @UserID, ModifyDate = getdate()
            where CBReceiptID = @ID;

            update t set BalanceAmt = a.BaseAmt + t.BalanceAmt
            from AR_Trx t
                 inner join (select BillID, sum(BaseAmt) as BaseAmt from AR_Allocation
                             where ReceiptID = @ID and RecordStatus <> 'Inactive' and BillID is not null
                             group by BillID) a on a.BillID = t.BillID;

            update AR_Allocation set RecordStatus = 'Inactive' where ReceiptID = @ID and RecordStatus <> 'Inactive';",
            "@ID", ctx.ReceiptID, "@UserID", ctx.UserID, "@Remark", (ctx.VoidRemark ?? "").Length > 200 ? ctx.VoidRemark.Substring(0, 200) : (ctx.VoidRemark ?? ""),
            "@VoidDate", ctx.VoidDate);
    }
}
