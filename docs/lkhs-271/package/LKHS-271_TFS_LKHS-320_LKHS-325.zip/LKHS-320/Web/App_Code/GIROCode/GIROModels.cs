using System;
using System.Collections.Generic;

// LKHS-271 - AR Collection GIRO (DBS) - data classes used by GIROCollectionGenerator and the module handlers.

/// <summary>Input of one "Generate" / "Generate All" run (from popup ARGIROCollectionGenerate.aspx).</summary>
public class GIROGenerateRequest
{
    public int CompanyID;
    public int BankAccountID;          // company GIRO bank (CF_CompanyGiroBank.GiroBankAccountID)
    public int CurrencyID;             // currency of the GIRO bank: only bills in this currency (Stanley note 12/10)
    public int PayMethodID;            // CB_Receipt.PayMethod (CF_PopupLstElement, Type 'PayMethod')
    public DateTime PaymentDate;       // D08 -> CB_Receipt.DocumentDate / AR_Allocation.AllocDate
    public string ReferenceNo;         // D34 -> CB_Receipt.ReferenceNo
    public int UserID;
    public string GIROGuid;            // popup session (CB_GIROTempDetail), cleaned after save
    public List<GIROBillRequest> Bills = new List<GIROBillRequest>();
}

/// <summary>One bill the user wants to collect.</summary>
public class GIROBillRequest
{
    public int BillID;
    public decimal CollectAmt;
    public GIROBillRequest(int billID, decimal collectAmt) { BillID = billID; CollectAmt = collectAmt; }
}

/// <summary>One bill re-read from DB inside the save transaction (fresh balance).</summary>
public class GIROBill
{
    public int BillID;
    public int CompanyID;
    public int DebtorID;
    public string DebtorName;
    public string ReceiptType;         // MC_Fee / OD_Receipt / PM_Receipt / PS_Payment (from View_CB_GIROCollectionPending)
    public string Module;
    public string DocumentNo;
    public DateTime? DocumentDate;     // AR_Trx.DocumentDate (Construction: AR_Allocation.AllocDate = bill date)
    public int CurrencyID;
    public decimal TrxExchangeRate;    // AR_Trx.ExchangeRate
    public decimal BalanceAmt;
    public decimal CollectAmt;
    public string ItemCode;            // AR_BillItem.ItemCode
    public string StakeHolderFlag;     // AR_Trx.StakeHolderFlag (Property Sales allocation)
}

/// <summary>Values shared by all bills of one receipt (= one debtor + module + currency).</summary>
public class GIROReceiptContext
{
    public GIROGenerateRequest Request;
    public int DebtorID;
    public string DebtorName;
    public string ReceiptType;
    public int CurrencyID;
    public decimal ExchangeRate;       // receipt rate (same rule as ArFeeAdd2: Currency.GetCurrencyExchange at DateTime.Now)
    public string DocNo;
    public int ReceiptID;
    public List<GIROBill> Bills = new List<GIROBill>();
}

/// <summary>LKHS-325 Cancel Receipt Action (Stanley doc: CB_Receipt Voided, release AR_Allocation, recalculate bill balance):
/// one GIRO receipt to void - Failed receipt of a batch (Import (Reject) Confirm) or Generated receipt (Collection Verification Cancel).</summary>
public class GIROCancelContext
{
    public int ReceiptID;
    public string DocNo;
    public int CompanyID;
    public DateTime VoidDate;          // now (as the module void popups default)
    public int UserID;                 // user confirming
    public string VoidRemark;          // e.g. GIRO Batch 00005 rejected by DBS: 1209:Account closed
}

/// <summary>Result returned to the popup.</summary>
public class GIROGenerateResult
{
    public List<string> DocNos = new List<string>();
    public int BillCount;
    public decimal TotalAmt;
}

/// <summary>Business error with a message for the user (no rollback detail needed).</summary>
public class GIROException : Exception
{
    public GIROException(string message) : base(message) { }
}
