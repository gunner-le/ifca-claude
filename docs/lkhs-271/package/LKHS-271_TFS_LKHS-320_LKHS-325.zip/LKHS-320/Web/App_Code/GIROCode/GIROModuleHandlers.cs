using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Web.Common;
using IFCA.Business.Finance.Generic;   // FNDataFormat
using IFCA.Business.Finance;

// LKHS-271 - AR Collection GIRO (DBS) - one handler per module.
// The generator does the common part (lock / validate / group / doc no / CB_Receipt).
// Everything that differs between modules lives in its handler, so a change for one module
// never touches the others. A module without a handler is refused by the generator (no guessing).

/// <summary>LKHS-271 GIRO forex: switch for the LKHS-230 forex logic on Rental / Construction GIRO receipts.
///   false = each module keeps its own receipt screen logic (current, tested behaviour)
///   true  = main allocation in bill currency at the BILL rate + forex row for a foreign-currency bill paid at another rate:
///           AllocAmt 0, BaseAmt = round(amt * pay rate, 2) - round(amt * bill rate, 2), ExchangeRate = pay rate
///           (read by the GL Receipt import / Forex Gain or Loss import of LKHS-230).
/// Other Receivable always uses the LKHS-230 logic (its own screen). Property Sales: foreign-currency bills are refused.</summary>
public static class GIROForexSetting
{
    public static readonly bool EnableForexRow = false;   // change to true to enable (App_Code recompiles on save)
}

public interface IGIROModuleHandler
{
    /// <summary>CB_Receipt.ReceiptType created by the module's own collection screen.</summary>
    string ReceiptType { get; }

    /// <summary>SysCode document code used by the module's own collection screen.</summary>
    string DocCode { get; }

    /// <summary>Module-specific CB_Receipt columns (added to / overriding the common ones).</summary>
    void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields);

    /// <summary>Knock off one bill against the new receipt.</summary>
    void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill);

    /// <summary>Extra processing after all bills of the receipt are allocated.</summary>
    void AfterReceiptCreated(DbTransaction tran, GIROReceiptContext ctx);

    /// <summary>LKHS-325 Cancel Receipt Action: void the receipt the way the module's own void / delete screen does,
    /// inside the caller's transaction (never a module BL that opens its own transaction).</summary>
    void CancelReceipt(DbTransaction tran, GIROCancelContext ctx);
}

/// <summary>
/// Default behaviour = what Rental ArFeeAdd2.DataSave does for a normal bill:
///   update AR_Trx.BalanceAmt, insert AR_Allocation, extra AR_Allocation row for forex difference.
/// </summary>
public abstract class GIROHandlerBase : IGIROModuleHandler
{
    public abstract string ReceiptType { get; }
    public abstract string DocCode { get; }

    public virtual void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields)
    {
    }

    public virtual void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill)
    {
        decimal amt = bill.CollectAmt;
        decimal rate = ctx.ExchangeRate;

        // 1. bill balance (ArFeeAdd2: update AR_Trx set BalanceAmt = BalanceAmt - payamt)
        GIRODb.Execute(tran, "update AR_Trx set BalanceAmt = BalanceAmt - @Amt where BillID = @BillID",
            "@Amt", amt, "@BillID", bill.BillID);

        if (GIROForexSetting.EnableForexRow)
        {
            // 2+3. LKHS-271 GIRO forex: allocation at bill rate + forex row (LKHS-230 logic)
            InsertAllocationWithForex(tran, ctx, bill, ctx.Request.PaymentDate.Date);
            return;
        }

        // 2. allocation
        InsertAllocation(tran, ctx, bill, amt, amt * rate, rate);   // ArFeeAdd2: BaseAmt = payamt * exchangerate

        // 3. forex difference row (AllocAmt 0, BaseAmt = difference) - same rule as ArFeeAdd2
        if (rate != bill.TrxExchangeRate)
        {
            InsertAllocation(tran, ctx, bill, 0m, amt * bill.TrxExchangeRate - amt * rate, rate);
        }
    }

    public virtual void AfterReceiptCreated(DbTransaction tran, GIROReceiptContext ctx)
    {
    }

    public abstract void CancelReceipt(DbTransaction tran, GIROCancelContext ctx);

    /// <summary>VoidRemark for SQL built with string.Format by a module (quotes doubled, max 200 chars).</summary>
    public static string SqlText(string v)
    {
        v = v ?? "";
        if (v.Length > 200) v = v.Substring(0, 200);
        return v.Replace("'", "''");
    }

    protected static void InsertAllocation(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill, decimal allocAmt, decimal baseAmt, decimal rate)
    {
        InsertAllocation(tran, ctx, bill, allocAmt, baseAmt, rate, ctx.CurrencyID, ctx.Request.PaymentDate.Date);
    }

    /// <summary>Full version: currency / alloc date given by the module (modules do not use the same rule).</summary>
    protected static void InsertAllocation(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill, decimal allocAmt, decimal baseAmt,
                                           decimal rate, int currencyID, DateTime allocDate)
    {
        GIRODb.Execute(tran, @"insert into AR_Allocation (BillID, AllocAmt, BaseAmt, ExchangeRate, CurrencyID, ReceiptID, AllocDate,
                                                          RecordStatus, CreateUserID, ModifyUserID, CreateDate, ModifyDate)
                               values (@BillID, @AllocAmt, @BaseAmt, @Rate, @CurrencyID, @ReceiptID, @AllocDate,
                                       'Active', @UserID, @UserID, getdate(), getdate())",
            "@BillID", bill.BillID, "@AllocAmt", allocAmt, "@BaseAmt", baseAmt, "@Rate", rate,
            "@CurrencyID", currencyID, "@ReceiptID", ctx.ReceiptID, "@AllocDate", allocDate,
            "@UserID", ctx.Request.UserID);
    }

    /// <summary>LKHS-271 GIRO forex (LKHS-230 logic, same as GIROOtherReceivableHandler.AllocateBill):
    /// main row in bill currency at the bill rate, BaseAmt = round(amt * bill rate, 2);
    /// forex row only for a foreign-currency bill whose rate differs from the pay rate:
    /// AllocAmt 0, BaseAmt = round(amt * pay rate, 2) - main BaseAmt, ExchangeRate = pay rate.</summary>
    protected static void InsertAllocationWithForex(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill, DateTime allocDate)
    {
        decimal amt = bill.CollectAmt;
        decimal billRate = bill.TrxExchangeRate;
        decimal payRate = ctx.ExchangeRate;
        decimal baseAmt = FNDataFormat.FormatAmount(amt * billRate);

        InsertAllocation(tran, ctx, bill, amt, baseAmt, billRate, bill.CurrencyID, allocDate);

        if (bill.CurrencyID != GetBaseCurrencyID(tran) && billRate != payRate)
        {
            decimal gainOrLoss = FNDataFormat.FormatAmount(amt * payRate) - baseAmt;
            InsertAllocation(tran, ctx, bill, 0m, gainOrLoss, payRate, bill.CurrencyID, allocDate);
        }
    }

    /// <summary>System base currency (same query as the module screens: CF_Currency.IsBaseCurrency = 'Y').
    /// internal: also used by GIROPropertySalesHandler (LKHS-271 GIRO forex).</summary>
    internal static int GetBaseCurrencyID(DbTransaction tran)
    {
        object o = GIRODb.Scalar(tran, "select isnull(CurrencyID,0) from CF_Currency where RecordStatus = 'Active' and IsBaseCurrency = 'Y'");
        return (o == null || o == DBNull.Value) ? 0 : Convert.ToInt32(o);
    }
}

/// <summary>
/// Rental Management - copied from McAccount/ArFeeAdd2.aspx.cs (DataSave), Collection > Receivable.
/// </summary>
public class GIRORentalHandler : GIROHandlerBase
{
    public override string ReceiptType { get { return "MC_Fee"; } }

    // ArFeeAdd2: new SysCode("036", DocAnchorType.Company, CompanyID, tran)
    public override string DocCode { get { return "036"; } }

    public override void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields)
    {
        fields["IsAdvancePayment"] = "N";   // ArFeeAdd2: isAdvancePayment Y/N from checkbox
        // LKHS-271 TEMP: PaymentDescID / Supply left NULL (ArFeeAdd2 takes them from dropdowns)
    }

    public override void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill)
    {
        base.AllocateBill(tran, ctx, bill);

        // ArFeeAdd2: late payment interest bill -> MCInterest.PaidBill
        if (string.Equals(bill.ItemCode, "Interest", StringComparison.OrdinalIgnoreCase) && bill.CollectAmt > 0)
        {
            MCInterest interest = new MCInterest();
            interest.PaidBill(tran, bill.BillID.ToString(), bill.CollectAmt);
        }
        // LKHS-271 TEMP: no interest re-calculation up to payment date (ArFeeAdd2 "Calculate" button not applied)
    }

    /// <summary>LKHS-325: same as McAccount/ArReceiptDelete.aspx (button Delete of Receivable): the module's own SQL
    /// ArCharge.CancellationCB_Receipt (receipt Voided + void info, bill BalanceAmt += AllocAmt, allocations Inactive),
    /// run in the GIRO transaction. Like the screen: no MCInterest reversal.</summary>
    public override void CancelReceipt(DbTransaction tran, GIROCancelContext ctx)
    {
        GIRODb.Execute(tran, ArCharge.CancellationCB_Receipt(ctx.ReceiptID.ToString(), ctx.VoidDate, ctx.UserID.ToString(), SqlText(ctx.VoidRemark)));
    }
}

/// <summary>
/// Other Receivable - copied from AccountReceivable/OtherReceiptEditSG.aspx.cs (Save_Click), AR-01-04.
/// Differences with Rental:
///   - doc code 313
///   - AR_Allocation uses the BILL currency / BILL exchange rate (BaseAmt = round(amt * bill rate, 2))
///   - forex row only for a foreign-currency bill whose rate differs from the pay rate:
///       AllocAmt 0, BaseAmt = round(amt * pay rate, 2) - round(amt * bill rate, 2), ExchangeRate = pay rate
///   - AllocDate = getdate() (screen uses getdate(), not the receipt date)
///   - no interest processing
/// Not applicable to GIRO: "Debtor Payment" lines (CB_Payment contra), edit mode (reverse old allocations).
/// </summary>
public class GIROOtherReceivableHandler : GIROHandlerBase
{
    public override string ReceiptType { get { return "OD_Receipt"; } }

    // OtherReceiptEditSG: new SysCode("313", DocAnchorType.Company, CompanyID)
    public override string DocCode { get { return "313"; } }

    public override void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields)
    {
        fields["IsAdvancePayment"] = "N";   // OtherReceiptEditSG: IsCbAdv checkbox (Y/N)
        // LKHS-271 TEMP: Supply left NULL (screen: dropdown, only when advance payment)
    }

    public override void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill)
    {
        decimal amt = bill.CollectAmt;
        decimal billRate = bill.TrxExchangeRate;
        decimal payRate = ctx.ExchangeRate;   // receipt currency = bill currency (group key) -> pay rate = receipt rate
        decimal baseAmt = FNDataFormat.FormatAmount(amt * billRate);
        DateTime allocDate = DateTime.Now;    // screen: AllocDate = getdate()

        // 1. bill balance (screen: update AR_Trx set BalanceAmt = BalanceAmt - Payamt)
        GIRODb.Execute(tran, "update AR_Trx set BalanceAmt = BalanceAmt - @Amt where BillID = @BillID",
            "@Amt", amt, "@BillID", bill.BillID);

        // 2. allocation in bill currency / bill rate
        InsertAllocation(tran, ctx, bill, amt, baseAmt, billRate, bill.CurrencyID, allocDate);

        // 3. forex gain/loss row (LKHS-230 rule of the screen)
        if (bill.CurrencyID != GetBaseCurrencyID(tran) && billRate != payRate)
        {
            decimal gainOrLoss = FNDataFormat.FormatAmount(amt * payRate) - baseAmt;
            InsertAllocation(tran, ctx, bill, 0m, gainOrLoss, payRate, bill.CurrencyID, allocDate);
        }
    }

    /// <summary>LKHS-325: same SQL as AccountReceivable/OtherReceiptDelete.aspx.cs (Save_Click, button Delete of Other Receipt):
    /// receipt Voided + void info + AllocBalance 0, bill BalanceAmt += BaseAmt / ExchangeRate, CB_Payment contra AllocBalance,
    /// all allocations of the receipt InActive.</summary>
    public override void CancelReceipt(DbTransaction tran, GIROCancelContext ctx)
    {
        GIRODb.Execute(tran, @"
            UPDATE CB_Receipt SET RecordStatus = 'Voided', VoidUserID = @UserID, VoidRemark = @Remark, VoidDate = @VoidDate, AllocBalance = 0,
                   ModifyUserID = @UserID, ModifyDate = getdate()
            WHERE CBReceiptID = @ID;

            -- LKHS-271 GIRO forex: a foreign-currency bill has 2 allocation rows (main + forex row AllocAmt 0),
            -- UPDATE ... FROM could take the forex row -> restore sum(AllocAmt) per bill (same result for a 1-row bill)
            UPDATE T
            SET BalanceAmt = ISNULL(T.BalanceAmt,0) + A.AllocAmt
            FROM AR_Trx T
            CROSS APPLY (SELECT SUM(x.AllocAmt) AS AllocAmt FROM AR_Allocation x
                         WHERE x.BillID = T.BillID AND x.ReceiptID = @ID
                           AND x.RecordStatus NOT IN ('Inactive','Voided')) A
            WHERE A.AllocAmt IS NOT NULL;

            UPDATE CB_Payment
            SET AllocBalance = ISNULL(cp.AllocBalance,0) + A.BaseAmt/A.ExchangeRate
            FROM AR_Allocation A
            INNER JOIN CB_Receipt R ON A.ReceiptID = R.CBReceiptID
            INNER JOIN CB_Payment cp ON A.PaymentID = cp.CBPaymentID
            WHERE A.RecordStatus NOT IN ('Inactive','Voided') AND A.ReceiptID = @ID;

            UPDATE AR_Allocation SET RecordStatus = 'InActive' WHERE ReceiptID = @ID;",
            "@ID", ctx.ReceiptID, "@UserID", ctx.UserID, "@Remark", (ctx.VoidRemark ?? "").Length > 200 ? ctx.VoidRemark.Substring(0, 200) : (ctx.VoidRemark ?? ""),
            "@VoidDate", ctx.VoidDate);
    }
}

/// <summary>
/// Construction Management - copied from PMReceivable/ArFeeAdd.aspx.cs (class PMReceiptBL: GetReceiptEntity,
/// SaveAllocEntity, UpdateBalanceAmt), PM-10-03 Receivable > Receipt/Collection.
/// Differences with Rental / Other Receivable:
///   - doc code 400, CB_Receipt.Supply = 'T'
///   - AR_Allocation: bill currency, bill rate (View_PM_ReceiptBillAdd.ExchangeRate = AR_Trx.ExchangeRate),
///     BaseAmt = amt * rate (not rounded), AllocDate = bill DocumentDate (now if empty), no forex row
///   - bill balance is RE-CALCULATED: BalanceAmt = DocumentAmt - sum(AllocAmt of 'Active' allocations),
///     error PM.Common_DataSynch when allocations exceed the bill amount
/// </summary>
public class GIROConstructionHandler : GIROHandlerBase
{
    public override string ReceiptType { get { return "PM_Receipt"; } }

    // PMReceiptBL: new SysCode("400", DocAnchorType.Company, ComID, new Dictionary<string, string>())
    public override string DocCode { get { return "400"; } }

    public override void FillReceiptFields(GIROReceiptContext ctx, IDictionary<string, object> fields)
    {
        fields["Supply"] = "T";             // PMReceiptBL: entity.Supply = "T"
        fields["IsAdvancePayment"] = "N";   // PMReceiptBL: IsCbAdv checkbox
        // LKHS-271 NOTE: PMReceiptBL does not set TransactionDate (comment: "updated by Cash Management"),
        // manual PM receipts still end with TransactionDate = DocumentDate -> kept the common value (= payment date).
    }

    public override void AllocateBill(DbTransaction tran, GIROReceiptContext ctx, GIROBill bill)
    {
        decimal amt = bill.CollectAmt;
        decimal rate = bill.TrxExchangeRate;
        DateTime allocDate = bill.DocumentDate.HasValue ? bill.DocumentDate.Value : DateTime.Now;

        // 1. allocation (PMReceiptBL.SaveAllocEntity)
        if (GIROForexSetting.EnableForexRow)
            InsertAllocationWithForex(tran, ctx, bill, allocDate);   // LKHS-271 GIRO forex: + forex row (LKHS-230 logic)
        else
            InsertAllocation(tran, ctx, bill, amt, amt * rate, rate, bill.CurrencyID, allocDate);

        // 2. bill balance re-calculated from active allocations (PMReceiptBL.UpdateBalanceAmt)
        int updated = GIRODb.Execute(tran,
            @"update t set BalanceAmt = t.DocumentAmt - a.AllocAmt, ModifyDate = getdate(), ModifyUserID = @UserID
              from AR_Trx t
              cross apply (select isnull(sum(x.AllocAmt), 0) as AllocAmt from AR_Allocation x
                           where x.BillID = t.BillID and x.RecordStatus = 'Active') a
              where t.BillID = @BillID and t.DocumentAmt >= a.AllocAmt",
            "@UserID", ctx.Request.UserID, "@BillID", bill.BillID);
        if (updated == 0)
            throw new GIROException(Strings.GetString("PM.Common_DataSynch") + " (" + bill.DocumentNo + ")");
    }

    /// <summary>LKHS-325: PM own Cancel (PMReceivable/ARReceiptList -> ARVoidTransaction.CancelReceipt) is NOT called:
    /// it opens its own transaction and only runs for receipts without allocation (screen rule), its bill update works on an
    /// unfetched entity. Same steps here, in the GIRO transaction:
    ///   receipt Voided (Stanley doc; PM screen uses Inactive) + void info, Active allocations -> Inactive,
    ///   bill balance re-calculated with the PM rule (PMReceiptBL.UpdateBalanceAmt): DocumentAmt - sum(Active AllocAmt).</summary>
    public override void CancelReceipt(DbTransaction tran, GIROCancelContext ctx)
    {
        GIRODb.Execute(tran, @"
            declare @Bills table (BillID int primary key);
            insert into @Bills (BillID)
            select distinct BillID from AR_Allocation where ReceiptID = @ID and RecordStatus = 'Active' and BillID is not null;

            update CB_Receipt set RecordStatus = 'Voided', VoidUserID = @UserID, VoidRemark = @Remark, VoidDate = @VoidDate,
                   ModifyUserID = @UserID, ModifyDate = getdate()
            where CBReceiptID = @ID;

            update AR_Allocation set RecordStatus = 'Inactive', ModifyUserID = @UserID, ModifyDate = getdate()
            where ReceiptID = @ID and RecordStatus = 'Active';

            update t set BalanceAmt = t.DocumentAmt - a.AllocAmt, ModifyDate = getdate(), ModifyUserID = @UserID
            from AR_Trx t
                 inner join @Bills b on b.BillID = t.BillID
                 cross apply (select isnull(sum(x.AllocAmt), 0) as AllocAmt from AR_Allocation x
                              where x.BillID = t.BillID and x.RecordStatus = 'Active') a;",
            "@ID", ctx.ReceiptID, "@UserID", ctx.UserID, "@Remark", (ctx.VoidRemark ?? "").Length > 200 ? ctx.VoidRemark.Substring(0, 200) : (ctx.VoidRemark ?? ""),
            "@VoidDate", ctx.VoidDate);
    }
}

// Property Sales handler: GIROPropertySalesHandler.cs (separate file, uses the PS BL assembly).
