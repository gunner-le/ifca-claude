<%@ Page Title="" Language="C#" MasterPageFile="~/Common/MasterBarListFooter.master" AutoEventWireup="true" CodeFile="ARGIROCollectionGenerate.aspx.cs" Inherits="CashFlow_ARGIROCollectionGenerate" %>
<%@ Register Src="~/Common/PageBottom.ascx" TagName="PageBottom" TagPrefix="pb1" %>
<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%@ Register Src="../Common/Finance/FNCommon.ascx" TagName="FNCommon" TagPrefix="fnuc" %>
<%-- LKHS-271: Generate GIRO Collection - popup Generate (Mode=Selected) / Generate All (Mode=All)
     cloned from ACGeneratePayment.aspx --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" Runat="Server">
    <script type="text/javascript" language="javascript" src="../CashFlow/SubmitHelper.js"></script>
    <fnuc:FNCommon ID="FNCommonJs" runat="server" />
    <script type="text/javascript" language="javascript" src="../Common/Finance/FNCommon.js"></script>
    <script type="text/javascript">
        submitHelper.PleaseWaite = function() { return '<%=Strings.GetString("PleaseWaite") %>'; }
    </script>
    <script language="javascript" type="text/javascript">
    var GIROGuid = '';
    var giroMode = '<%=Mode %>';            // All | Selected
    var giroCompanyID = '<%=currCompanyID %>';
    var giroBankAccountID = '<%=giroBankAccountID %>';

    function f_GetMessage(tip)
    {
        return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
    }

    function f_init()
    {
        GIROGuid = document.getElementById("<%=giroGuid.ClientID%>").value;
        if (giroMode == "All")
        {
            return;     // Generate All: bills = listing filter (see summary line), no detail grid
        }
        f_LoadDetail("<%=billIDs %>", "");
    }

    // No. of Documents / Total Amount (read-only form fields, display only) - called by the detail grid after each load (Generate mode)
    function f_SetSummary(cnt, amt)
    {
        try { tabEditorManager.SetValueByFieldName("DocumentCount", cnt); } catch (e) { }
        try { tabEditorManager.SetCurrencyValueByName("TotalAmt", amt); } catch (e) { }
    }

    function f_LoadDetail(billIDs, cancelIDs)
    {
        document.getElementById("giroDetail").src = "../CashFlow/ARGIROCollectionGenerateDetail.aspx?guid=" + GIROGuid
            + "&CompanyID=" + giroCompanyID + "&BillIDs=" + billIDs + "&cancelIDs=" + cancelIDs;
    }

    // called by SubmitHelper (f_SaveData) before postback; server side validates the dates
    function f_CheckSave()
    {
        if (giroMode != "All")
        {
            var detail = document.getElementById("giroDetail").contentWindow;
            if (detail == null || typeof(detail.f_checkHaveDetail) == "undefined" || !detail.f_checkHaveDetail())
            {
                MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIRO_NoDetail")%>"));
                return false;
            }
        }
        return true;
    }

    function f_Close()
    {
        top.close();
    }

    // Import: popup to pick more outstanding bills (ARGIROCollectionSelect.aspx calls f_ImportBills)
    function f_Select()
    {
        // real child window (not sysf_opensubonewin): its close must not close this popup
        var w = window.open("../CashFlow/ARGIROCollectionSelect.aspx?guid=" + GIROGuid
            + "&CompanyID=" + giroCompanyID + "&BankAccountID=" + giroBankAccountID,
            "GIROImport", "width=900,height=600,resizable=yes,scrollbars=yes,status=no,toolbar=no,menubar=no");
        if (w != null) w.focus();
    }

    // called by the Import popup with the checked BillIDs
    function f_ImportBills(billIDs)
    {
        if (billIDs != null && billIDs != "")
            f_LoadDetail(billIDs, "");
    }

    // Remove checked lines from the detail grid
    function f_Cancel()
    {
        var cancelIDs = document.getElementById("giroDetail").contentWindow.f_GetCancelIDs();
        if (cancelIDs == null || cancelIDs == "")
        {
            MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected")%>"));
            return;
        }
        f_LoadDetail("", cancelIDs);
    }

    function alert(oldmessage)
    {
        MessageShow(f_GetMessage(oldmessage));
    }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" Runat="Server">
    <atlas:ScriptManager ID="sm" EnablePageMethods="true" runat="server"></atlas:ScriptManager>
    <IFCAUI:SysToolbar ID="SysToolBar2" runat="server" Style="width: 100%" ShowSettingMenu="false"
        TranslateBseNo="CB.GIROCollectionGenerate" TabNo="CB.GIROCollectionGenerate" MenuClass="CB.GIROCollectionGenerate"
        MenuNo="Cash-03-20" ShowFilter="false" ShowInterface="false" ShowListView="false"
        ShowQryCondition="false" ShowSort="false" />
</asp:Content>
<asp:Content ID="Content4" ContentPlaceHolderID="RightContentPlace" Runat="Server">
    <IFCAUI:SysTabEdit ID="SysTabEdit1" runat="server" TabNo="CB.GIROCollectionGenerate" AllowPaging="false" />
    <input type="hidden" id="CompanyID" name="CompanyID" runat="server" />
    <input type="hidden" id="bankAccountID" name="bankAccountID" runat="server" />
    <input type="hidden" id="hidMode" name="hidMode" runat="server" />
    <input type="hidden" id="giroGuid" runat="server" />
    <input type="hidden" id="hidFilter" runat="server" />  <%-- Generate All: listing filter (f_GetConditionFilter) --%>
    <div style="padding:2px 4px; color:red;"><asp:Label ID="lblSummary" runat="server" /></div>  <%-- warning only (no document / invalid filter) --%>
    <IFCAUI:SysContainer ID="SysContainer1" runat="server" TcdTabNo="CB.GIROCollectionGen" Width="100%" Height="350px">
        <IFCAUI:SysContainerTab ID="SysContainerTab1" runat="server" TcdCardNo="CB.GIRODetail">
            <iframe style="height:430px; width: 100%;" scrolling="no" frameborder="0" id="giroDetail" name="giroDetail" src=""></iframe>
        </IFCAUI:SysContainerTab>
    </IFCAUI:SysContainer>
</asp:Content>
<asp:Content ID="Content5" ContentPlaceHolderID="FooterContent" Runat="Server">
    <pb1:PageBottom ID="PageBottom1" runat="server" BseNo="CB.GIROCollectionGenerate" CurrentID="" />
</asp:Content>
