<%@ Page Language="C#" MasterPageFile="~/Common/Master2row_1row.master" AutoEventWireup="true" CodeFile="ARGIROCollection.aspx.cs" Inherits="CashFlow_ARGIROCollection" Title="Untitled Page" %>
<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc1" %>
<%-- LKHS-271: Generate GIRO Collection - frame page (cloned from ACPayment.aspx) --%>
<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" Runat="Server">
<script language="javascript" type="text/javascript">
var LIST_URL = "../CashFlow/ARGIROCollectionLst.aspx";

// called by CostCompanyTree when a company is selected
function f_ShowList(p_sType, p_sid, p_sName) {
    if (p_sType == "com") {
        document.getElementById("iframe3").src = LIST_URL + "?companyID=" + p_sid;
        document.getElementById("<% =this.CompanyID.ClientID%>").value = p_sid;
        document.getElementById("iframe2").src = "../CashFlow/BankTree.aspx?NotIncluseFuturCheque=Y&type=usecurrency&loadflag=1&companyID=" + p_sid;
    }
}

// called by BankTree when a bank account is selected
function f_ClickAccount(p_sType, bankAccountID, currencyID, currency, accountID) {
    if (p_sType == "CashAccount" || p_sType == "BankAccount") {
        var wait = new CusWait(document.getElementById("list"), "Please Wait Loading...");
        wait.Show();

        if (window.addEventListener) {
            document.getElementById("iframe3").addEventListener("load", function () { wait.Close() }, false);
        } else if (window.attachEvent) {
            document.getElementById("iframe3").attachEvent("onload", function () { wait.Close() });
        } else {
            document.getElementById("iframe3")["onload"] = function () { wait.Close() };
        }

        var companyID = document.getElementById("<% =this.CompanyID.ClientID%>").value;
        try {
            document.getElementById("iframe3").src = LIST_URL + "?companyID=" + companyID + "&currencyID=" + currencyID + "&bankAccountID=" + bankAccountID;
        }
        catch (ex) {
        }
    }
}

function f_init()
{
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="LeftBar1" Runat="Server">
    <IFCAUI:SysToolBar ID="SysToolBar1" runat="server" Style="width: 100%;" ShowTitleImg="false" ShowSettingMenu="false">
    </IFCAUI:SysToolBar>
</asp:Content>

<asp:Content ID="Content5" ContentPlaceHolderID="LeftContent1" Runat="Server">
    <%-- SelNode = MnuNo of this menu (placeholder Cash-03-20) --%>
    <iframe frameborder="0" src="../common/CostCompanyTree.aspx?SelNode=Cash-03-20&mType=m" id="CostEntityTree" style="height:100%;width:100%;"></iframe>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="LeftBar2" Runat="Server" >
    <IFCAUI:SysToolBar ID="SysToolBar2" runat="server" Style="width: 100%" ShowTitleImg="false" ShowSettingMenu="false">
    </IFCAUI:SysToolBar>
</asp:Content>

<asp:Content ID="Content6" ContentPlaceHolderID="LeftContent2" Runat="Server">
    <input type="hidden" id="CompanyID" name="CompanyID" runat="server" />
    <iframe id="iframe2" src="" frameborder="0" marginwidth="0"
        marginheight="0" scrolling="auto" style="height: 100%" name="iframe2" ></iframe>
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="RightContentPlace" Runat="Server">
    <iframe id="iframe3" src="" frameborder="0" marginwidth="0"
        marginheight="0" scrolling="no" style="height: 100%" name="iframe3"></iframe>
</asp:Content>
