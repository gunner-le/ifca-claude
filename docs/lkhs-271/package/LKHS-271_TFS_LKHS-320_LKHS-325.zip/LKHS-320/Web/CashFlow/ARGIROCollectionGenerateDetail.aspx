<%@ Page Language="C#" AutoEventWireup="true" CodeFile="ARGIROCollectionGenerateDetail.aspx.cs" Inherits="CashFlow_ARGIROCollectionGenerateDetail" %>
<%-- LKHS-271: Generate GIRO Collection - detail grid of the popup (cloned from ACGeneratePaymentDetail.aspx) --%>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script type="text/javascript" language="javascript" src="../Common/Finance/FNCommon.js"></script>
    <script type="text/javascript">
    var LIB_URL = "..";
    </script>
    <script src="../Lib/CommonScriptNET.js?version=<%=Application["JSVersion"]%>" type="text/javascript"></script>
    <script type="text/javascript" language="javascript">
        function f_init()
        {
            // update No. of Documents / Total Amount on the popup
            try { parent.f_SetSummary(<%=detailCount %>, <%=detailTotal.ToString(System.Globalization.CultureInfo.InvariantCulture) %>); } catch (e) { }
        }

        // checked lines -> GIRODetailID list (id field of the grid)
        function f_GetCancelIDs()
        {
            var ids = gridManager2.GetSelectedRowIds();
            return (ids == null) ? "" : ids.toString();
        }

        // has at least one line
        function f_checkHaveDetail()
        {
            var grid = gridManager2.GetGrid();
            return (grid != null && grid.get_rows().get_length() > 0);
        }
    </script>
</head>
<body onload="try{f_init();}catch(e){}">
    <form id="form1" runat="server" style="margin: 0; padding: 0;">
    <atlas:ScriptManager runat="Server" ID="bill" EnablePageMethods="true">
    </atlas:ScriptManager>
        <IFCAUI:SysList2 runat="server" ID="SysList1" LstNo="CB.GIROCollectionDetail" ShowContextMenu="false" PageSize="300" AllowPaging="false" ShowFooter="true" Height="100%" UseCheckBox="true" BorderStyle="None" />
    </form>
</body>
</html>
