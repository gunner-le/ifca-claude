using System;
using System.Data;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.UI.Controls;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Web.Common;
using IFCA.Business.Finance.Generic;
using IFCA.Business.Finance.Resoureces.Service;
using IFCA.Business.Finance.CB;
using Infragistics.WebUI.WebSchedule;

// LKHS-271: Generate GIRO Collection - popup (cloned from ACGeneratePayment.aspx.cs)
// Query string: Mode=All|Selected, CompanyID, BankAccountID, BillIDs (Selected only), whereT (All only = listing filter)
// Stanley note 12/10: Generate All = bills of the listing filter (no Processing Date / Module), Payment Method read-only GIRO,
//                     Reference No mandatory, only bills in the GIRO bank currency.
public partial class CashFlow_ARGIROCollectionGenerate : IFCA.Web.UI.Page
{
    protected string Mode = "Selected";
    protected int currCompanyID;
    protected int giroBankAccountID;
    protected string billIDs = "";
    protected int giroCurrencyID;

    protected void Page_Load(object sender, EventArgs e)
    {
        ReadQueryString();
        SysContainer1.Visible = (Mode != "All");

        if (!Page.IsPostBack)
        {
            string title = Strings.GetString(Mode == "All" ? "CB.GIRO_Title_GenerateAll" : "CB.GIRO_Title_Generate");
            this.Page.Title = title;
            this.SysToolBar2.Title = title;
            SysTabEdit1.PrimaryKeyValue = "0";
            giroGuid.Value = Guid.NewGuid().ToString("D");
            hidMode.Value = Mode;
            CompanyID.Value = currCompanyID.ToString();
            bankAccountID.Value = giroBankAccountID.ToString();

            // clean old working rows (popups closed without saving)
            DataAccessHelper.ExecuteNonQuery("delete CB_GIROTempDetail where CreateDate < dateadd(d,-3,getdate())");

            LoadBankHeader();

            if (Mode == "All")
                ShowAllSummary(Request.QueryString["whereT"]);
        }
    }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        Common.pf_LoadCustomization(this, "CB.GIROCollectionGenerate", "Init");
        SysToolBar2.CustomControlsCreated += new EventHandler(SysToolBar2_CustomControlsCreated);
        this.SysTabEdit1.CustomControlsCreated += new EventHandler(SysTabEdit1_CustomControlsCreated);
    }

    void SysTabEdit1_CustomControlsCreated(object sender, EventArgs e)
    {
        SetPayMethod();
    }

    void SysToolBar2_CustomControlsCreated(object sender, EventArgs e)
    {
        SysToolbarButton saveButton = SysToolBar2.FindContextButton("Save");
        if (saveButton != null)
            saveButton.Click += new EventHandler(SaveButton_Click);
    }

    #region internal function
    private void ReadQueryString()
    {
        Mode = string.Equals(Request.QueryString["Mode"], "All", StringComparison.OrdinalIgnoreCase) ? "All" : "Selected";
        currCompanyID = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        giroBankAccountID = FNCommon.ObjToInt(Request.QueryString["BankAccountID"]);
        billIDs = CleanIDs(Request.QueryString["BillIDs"]);
    }

    // keep only "1,2,3" (ids go into SQL / JS)
    private static string CleanIDs(string ids)
    {
        if (string.IsNullOrEmpty(ids)) return "";
        ids = ids.Trim().Trim(',');
        return Regex.IsMatch(ids, @"^\d+(,\d+)*$") ? ids : "";
    }

    // header values from the selected bank (same idea as Generate Payment)
    private void LoadBankHeader()
    {
        string sql = string.Format(@"select ba.BankAccountID, ba.AccountNo as ACNo, ca.Name as BankName, ba.CurrencyID, c.ISOCode as Currency
                                     from CF_BankAccount ba
                                     left join CF_Account ca on ca.AccountID = ba.AccountID
                                     left join CF_Currency c on c.CurrencyID = ba.CurrencyID
                                     where ba.BankAccountID = {0} and ba.CompanyID = {1}", giroBankAccountID, currCompanyID);
        DataTable bankDt = FNCommon.GetDataTable(sql);
        if (bankDt == null || bankDt.Rows.Count == 0)
            return;

        DataRow bankDr = bankDt.Rows[0];
        Dictionary<string, InputValues> lstD = SysTabEdit1.GetInputValuesInDictionary(true);
        foreach (DataColumn col in bankDt.Columns)
        {
            string name = col.ColumnName;
            if (lstD.ContainsKey(name) || name == "ACNo" && lstD.ContainsKey("BankAccountID") || name == "Currency" && lstD.ContainsKey("CurrencyID"))
            {
                SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, name, bankDr[name]);
            }
        }
        SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "DocumentDate", DateTime.Today);
    }

    // Payment Method: read-only, always GIRO (Stanley note 12/10)
    private void SetPayMethod()
    {
        DropDownList payMethodDDL = this.SysTabEdit1.FindControl("PayMethod") as DropDownList;
        if (payMethodDDL == null) return;

        payMethodDDL.Items.Clear();
        int giroID = GetGIROPayMethodID();
        if (giroID > 0)
            payMethodDDL.Items.Add(new ListItem(GetGIROPayMethodText(giroID), giroID.ToString()));
        payMethodDDL.Enabled = false;
    }

    // GIRO pay method = active PayMethod element whose title contains "GIRO" (no hard-coded ID; CashPayment / Account excluded)
    private static int GetGIROPayMethodID()
    {
        foreach (Popuplstelement item in new SettleType().GetElements())
        {
            if (item == SettleType.CashPayment) continue;
            string text = Strings.GetString(item.TitleStringCode);
            if (text != null && text.ToUpper().Contains("GIRO"))
                return item.PopuplstelementID;
        }
        return 0;
    }

    private static string GetGIROPayMethodText(int id)
    {
        foreach (Popuplstelement item in new SettleType().GetElements())
            if (item.PopuplstelementID == id) return Strings.GetString(item.TitleStringCode);
        return "GIRO";
    }

    // currency of the GIRO bank (only bills in this currency are collected)
    private int GetBankCurrencyID()
    {
        return FNCommon.GetScalarInteger(string.Format(
            "select isnull(CurrencyID,0) from CF_BankAccount where BankAccountID = {0} and CompanyID = {1}", giroBankAccountID, currCompanyID));
    }

    // listing filter sent by ARGIROCollectionLst (f_GetConditionFilter, same as SysListPrint / VoucherListPrint whereT).
    // Only a WHERE fragment on View_CB_GIROCollectionPending columns; company / bank / currency are always added here.
    private static bool IsSafeFilter(string filter)
    {
        if (string.IsNullOrEmpty(filter)) return true;
        return filter.IndexOf(";") < 0 && filter.IndexOf("--") < 0 && filter.IndexOf("/*") < 0 && filter.IndexOf("*/") < 0;
    }

    private string BuildAllSql(string filter, string columns)
    {
        string sql = string.Format(
            "select {0} from View_CB_GIROCollectionPending where CompanyID = {1} and GIROBankAccountID = {2} and CurrencyID = {3}",
            columns, currCompanyID, giroBankAccountID, giroCurrencyID);
        if (!string.IsNullOrEmpty(filter))
            sql += " and (" + filter + ")";
        return sql;
    }

    // Generate All: keep the listing filter and show how many documents will be collected
    private void ShowAllSummary(string filter)
    {
        filter = (filter ?? "").Trim();
        hidFilter.Value = filter;
        giroCurrencyID = GetBankCurrencyID();

        string text;
        if (!IsSafeFilter(filter))
            text = Strings.GetString("CB.GIRO_InvalidFilter");
        else
        {
            try
            {
                DataTable dt = FNCommon.GetDataTable(BuildAllSql(filter, "count(*) as Cnt, isnull(sum(BalanceAmt),0) as Amt"));
                int cnt = Convert.ToInt32(dt.Rows[0]["Cnt"]);
                decimal amt = Convert.ToDecimal(dt.Rows[0]["Amt"]);
                SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "DocumentCount", cnt);
                SysTabEditUtil.SetSysTabEditValueByName(SysTabEdit1, "TotalAmt", amt);
                text = cnt == 0 ? Strings.GetString("CB.GIRO_NoDetail") : "";
            }
            catch
            {
                text = Strings.GetString("CB.GIRO_InvalidFilter");
            }
        }
        lblSummary.Text = text;
    }

    private DateTime? GetTabDate(string name)
    {
        WebDateChooser ctl = SysTabEdit1.FindControl(name) as WebDateChooser;
        if (ctl == null || ctl.Value == null || ctl.Value == DBNull.Value || ctl.Value.ToString() == "") return null;
        DateTime d;
        if (DateTime.TryParse(ctl.Value.ToString(), out d)) return d.Date;
        return null;
    }

    void ShowMessStr(string msgText)
    {
        Message msg = new Message();
        msg.AutoClientJs = "MessageClose();";
        msg.MsgTitle = Strings.GetString("CommonSaveTitle");
        msg.Msg = msgText;
        msg.TipPic = Message.EnumTipPicType.Remind;
        msg.MsgType = Message.EnumMsgType.OKOnly;
        Page.ClientScript.RegisterStartupScript(GetType(), "Result", msg.GetHtml());
    }
    #endregion

    #region Save
    void SaveButton_Click(object sender, EventArgs e)
    {
        // read again from hidden fields (postback)
        Mode = hidMode.Value == "All" ? "All" : "Selected";
        currCompanyID = FNCommon.ObjToInt(CompanyID.Value);
        giroBankAccountID = FNCommon.ObjToInt(bankAccountID.Value);
        giroCurrencyID = GetBankCurrencyID();

        int payMethodID = GetGIROPayMethodID();   // read-only field: never trust the posted value
        if (payMethodID <= 0)
        {
            ShowMessStr(Strings.GetString("CB.GIRO_PayMethodRequired"));
            return;
        }

        DateTime? paymentDate = GetTabDate("DocumentDate");
        if (paymentDate == null)
        {
            ShowMessStr(Strings.GetString("CB.GIRO_PaymentDateRequired"));
            return;
        }
        if (paymentDate.Value < DateTime.Today)
        {
            ShowMessStr(Strings.GetString("CB.GIRO_PaymentDateMustNotPast"));
            return;
        }

        TextBox refNo = SysTabEdit1.FindControl("ReferenceNo") as TextBox;
        string referenceNo = refNo != null ? refNo.Text.Trim() : "";
        if (referenceNo == "")
        {
            ShowMessStr(Strings.GetString("CB.GIRO_ReferenceNoRequired"));
            return;
        }

        // ---- build the request ----
        GIROGenerateRequest req = new GIROGenerateRequest();
        req.CompanyID = currCompanyID;
        req.BankAccountID = giroBankAccountID;
        req.CurrencyID = giroCurrencyID;
        req.PayMethodID = payMethodID;
        req.PaymentDate = paymentDate.Value;
        req.ReferenceNo = referenceNo;
        req.UserID = FNCommon.ObjToInt(SysContext.CurrentUserId);

        Guid g;
        if (Mode != "All")
        {
            // Generate: bills of this popup session
            if (!Guid.TryParse(giroGuid.Value, out g))
            {
                ShowMessStr(Strings.GetString("CB.GIRO_NoDetail"));
                return;
            }
            req.GIROGuid = g.ToString("D");
            DataTable dt = FNCommon.GetDataTable(string.Format(
                "select BillID, CollectAmt from CB_GIROTempDetail where GIROGuid = '{0}'", req.GIROGuid));
            foreach (DataRow r in dt.Rows)
                req.Bills.Add(new GIROBillRequest(Convert.ToInt32(r["BillID"]), Convert.ToDecimal(r["CollectAmt"])));
        }
        else
        {
            // Generate All: every outstanding bill of the listing filter (Stanley note 12/10)
            string filter = hidFilter.Value.Trim();
            if (!IsSafeFilter(filter))
            {
                ShowMessStr(Strings.GetString("CB.GIRO_InvalidFilter"));
                return;
            }
            DataTable dt;
            try
            {
                dt = FNCommon.GetDataTable(BuildAllSql(filter, "BillID, BalanceAmt"));
            }
            catch
            {
                ShowMessStr(Strings.GetString("CB.GIRO_InvalidFilter"));
                return;
            }
            foreach (DataRow r in dt.Rows)
                req.Bills.Add(new GIROBillRequest(Convert.ToInt32(r["BillID"]), Convert.ToDecimal(r["BalanceAmt"])));
        }

        if (req.Bills.Count == 0)
        {
            ShowMessStr(Strings.GetString("CB.GIRO_NoDetail"));
            return;
        }

        // ---- create receipts (one transaction) ----
        try
        {
            GIROGenerateResult result = new GIROCollectionGenerator().Generate(req);

            string text = string.Format(Strings.GetString("CB.GIRO_SaveSuccess"), result.DocNos.Count, result.BillCount, result.TotalAmt.ToString("#,##0.00"))
                        + "<br>" + string.Join(", ", result.DocNos.ToArray());
            NameValueCollection buttons = new NameValueCollection();
            buttons.Add(Strings.GetString("Close"), "try{opener.f_ReLoad();}catch(e){};top.close();");
            Message msg = new Message(text, buttons);
            msg.MsgType = Message.EnumMsgType.No;
            Page.ClientScript.RegisterStartupScript(GetType(), "Result", msg.GetHtml());
        }
        catch (GIROException ex)
        {
            ShowMessStr(ex.Message.Replace("\r", "").Replace("\n", "<br>"));   // LKHS-320 GIRO: CR/LF breaks the JS popup
        }
        catch (Exception ex)
        {
            ShowMessStr(Strings.GetString("ErrorMessage") + "<br>" + Message.FormatMessage(ex.Message.Replace("\r", "").Replace("\n", " ")));   // LKHS-320 GIRO: CR/LF breaks the JS popup
        }
    }
    #endregion
}
