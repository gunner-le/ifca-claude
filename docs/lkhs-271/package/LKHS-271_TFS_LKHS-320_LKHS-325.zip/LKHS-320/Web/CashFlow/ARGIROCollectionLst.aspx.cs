using System;
using System.Data;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Business.Finance.Generic;

// LKHS-271: Generate GIRO Collection - list page (cloned from ACPaymentLst.aspx.cs)
// Query string: companyID, currencyID, bankAccountID (sent by frame page ARGIROCollection.aspx)
public partial class CashFlow_ARGIROCollectionLst : IFCA.Web.UI.Page
{
    protected string ContextMnuNo = "";

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected override void OnInit(EventArgs e)
    {
        this.SysToolBar3.Title = Strings.GetString("CB.GIROCollection_Title");

        // read and sanitize query string (ints only)
        int companyID     = FNCommon.ObjToInt(Request.QueryString["companyid"]);
        int currencyID    = FNCommon.ObjToInt(Request.QueryString["currencyID"]);
        int bankAccountID = FNCommon.ObjToInt(Request.QueryString["bankAccountID"]);

        this.CompanyID.Value     = companyID.ToString();
        this.payCurrencyID.Value = currencyID.ToString();
        this.bankAccountID.Value = bankAccountID.ToString();

        // selected bank must be an active company GIRO bank (CF_CompanyGiroBank)
        bool isGIROBank = false;
        if (companyID > 0 && bankAccountID > 0)
        {
            int cnt = FNCommon.GetScalarInteger(string.Format(
                "select count(*) from CF_CompanyGiroBank where CompanyID={0} and GiroBankAccountID={1} and RecordStatus='Active'",
                companyID, bankAccountID));
            isGIROBank = (cnt > 0);
        }
        this.hidIsGIROBank.Value = isGIROBank ? "Y" : "N";

        if (!Page.IsPostBack)
        {
            if (companyID > 0 && isGIROBank)
            {
                // only bills in the GIRO bank currency (Stanley note 12/10)
                int bankCurrencyID = FNCommon.GetScalarInteger(string.Format(
                    "select isnull(CurrencyID,0) from CF_BankAccount where BankAccountID={0}", bankAccountID));
                this.SysList1.SelectCommandText = string.Format(
                    "select * from View_CB_GIROCollectionPending where CompanyID={0} and GIROBankAccountID={1} and CurrencyID={2}",
                    companyID, bankAccountID, bankCurrencyID);
            }
            else
            {
                this.SysList1.SelectCommandText = "select * from View_CB_GIROCollectionPending where 1=2";
            }

            // to call customization .dll (same hook as Generate Payment)
            Common.pf_LoadCustomization(this, "", "Init");

            // toolbar buttons of this menu -> used by JS OnBeforeMenu()
            try
            {
                DataTable rs = DataAccessHelper.ExecuteDataset(string.Format(
                    "select ContextMnuNo from Sys_ContextMenu where MnuNo='{0}' and MnuClass='{1}' order by SeqNo",
                    SysToolBar3.MenuNo, SysToolBar3.MenuClass)).Tables[0];
                foreach (DataRow row in rs.Rows)
                {
                    ContextMnuNo += "," + row["ContextMnuNo"].ToString();
                }
                if (ContextMnuNo.Length > 0)
                    ContextMnuNo = ContextMnuNo.Substring(1);
            }
            catch { }
        }
        // NOTE: ACPaymentLst.OnInit does not call base.OnInit(e) - kept the same behaviour
    }
}
