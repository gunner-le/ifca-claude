<%@ Page Language="C#" MasterPageFile="~/Common/MasterBarCondList.master" AutoEventWireup="true" CodeFile="ARGIROCollectionLst.aspx.cs" Inherits="CashFlow_ARGIROCollectionLst" Title="Untitled Page" %>

<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System" %>
<%-- LKHS-271: Generate GIRO Collection - list page (cloned from ACPaymentLst.aspx) --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" runat="Server">
<script language="javascript" type="text/javascript">
var PubPrive;
var _companyId = "";
var PubCont = '<%=ContextMnuNo %>';

function f_GetMessage(tip)
{
    return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
}

// common checks before opening the generation popup
function f_CheckBank()
{
    var bankAccountID = document.getElementById("<% =this.bankAccountID.ClientID%>").value;
    if (bankAccountID == "" || bankAccountID == "0")
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("MustSelectBankAccount") %>"));
        return false;
    }
    if (document.getElementById("<% =this.hidIsGIROBank.ClientID%>").value != "Y")
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("CB.GIRO_NotGIROBank") %>"));
        return false;
    }
    return true;
}

/* Generate: selected bill lines */
function f_GIROGenerate()
{
    if (!f_CheckBank()) return;

    var billIDs = gridManager2.GetSelectedRowIds();
    if (billIDs == null || billIDs.length == 0)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected") %>"));
        return;
    }
    var url = "../CashFlow/ARGIROCollectionGenerate.aspx?Mode=Selected"
            + "&CompanyID=" + _companyId
            + "&BankAccountID=" + document.getElementById("<% =this.bankAccountID.ClientID%>").value
            + "&BillIDs=" + billIDs;
    sysf_opensubonewin(url, 900, 650, "yes");
}

/* Generate All: all bills of the current listing filter (Stanley note 12/10) - same filter as SysListPrint (LKHS-231) */
function f_GIROGenerateAll()
{
    if (!f_CheckBank()) return;

    var oCond = document.getElementById("<%=SysCondition1.ClientID%>_condition");
    var sfilter = (oCond != null) ? f_GetConditionFilter(oCond) : "";
    if (sfilter == null) sfilter = "";
    var url = "../CashFlow/ARGIROCollectionGenerate.aspx?Mode=All"
            + "&CompanyID=" + _companyId
            + "&BankAccountID=" + document.getElementById("<% =this.bankAccountID.ClientID%>").value
            + "&whereT=" + escape(sfilter);
    sysf_opensubonewin(url, 900, 650, "yes");
}

/* View: read-only detail of the selected bill (generic form Sys_Tab CB.GIROCollectionView, same for all modules) */
function f_View()
{
    var row = gridManager2.GetSelectedRow();
    if (row == null)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected") %>"));
        return;
    }
    var billID = gridManager2.GetSelectRowKeyValue();
    sysf_opensubonewin("../Common/ApproveView.aspx?TabNo=CB.GIROCollectionView&isView=Y&CurId=" + billID, 780, 450, "yes");
}

// Build the WHERE fragment of the listing search criteria (Generate All uses the listing filter - Stanley note 12/10).
// Copied as-is from GLVoucher/GLAuditAdjustmentVoucherList.aspx (page-level function, not in a shared .js), incl. LKHS-231 fix.
function f_GetConditionFilter(oTable){
        var tableForCondition = oTable.id.substring(0, oTable.id.length - 10); if (oTable == null || oTable.tagName!='TABLE') return; var elements = oTable.getElementsByTagName("INPUT"); var aryNameValue = new Array(); 
        for(var i=0,len=elements.length;i<len;i++)
        { if (elements[i].type!='text') continue; if (elements[i].value.trim().length==0) continue; var elementName = elements[i].name.substring(tableForCondition.length+1); 
        if (elements[i].className=='PopupCalendarEditStyle')
        { 
        if (elementName.endsWith('From_input'))
        { elementName = elementName.substring(0, elementName.length - 10); aryNameValue.push(elementName); aryNameValue.push(elementName + ">='"+ GetDateChooserValue(elements[i].id)+"' "); continue;}
        if (elementName.endsWith('To_input'))
        { elementName = elementName.substring(0, elementName.length - 8); aryNameValue.push(elementName); aryNameValue.push(elementName + "<='"+ GetDateChooserValue(elements[i].id)+" 23:59:00' "); continue;}
        if (elementName.endsWith('_input'))
        { elementName = elementName.substring(0, elementName.length - 6); aryNameValue.push(elementName); aryNameValue.push(elementName + "='"+ GetDateChooserValue(elements[i].id)+"' "); continue;}
        }
        else if (elements[i].className=='WebCurrencyEdit')
        { elementName = elements[i].id.substring(6 + tableForCondition.length, elements[i].id.length); var controlId = elements[i].id.substring(5, elements[i].id.length); if (elementName.endsWith('From'))
        { elementName = elementName.substring(0, elementName.length - 4); aryNameValue.push(elementName); aryNameValue.push(elementName + " >='" + document.getElementById(controlId).value.trim() + "' ");}
        else if (elementName.endsWith('To'))
        { elementName = elementName.substring(0, elementName.length - 2); aryNameValue.push(elementName); aryNameValue.push(elementName + " <='" + document.getElementById(controlId).value.trim() + "' ");}
        else
        { aryNameValue.push(elementName); aryNameValue.push(elementName + " ='" + document.getElementById(controlId).value.trim() + "' ");}
        }
        else
        { if (elementName.endsWith('_From'))
        {elementName = elementName.substring(0, elementName.length - 5);
        aryNameValue.push(elementName); aryNameValue.push(elementName + " >='" + elements[i].value.trim() + "' ");
        continue;}
        if (elementName.endsWith('_To'))
        {elementName = elementName.substring(0, elementName.length - 3);
        aryNameValue.push(elementName); aryNameValue.push(elementName + " <='" + elements[i].value.trim() + "' ");
        continue;}
        var txtValue=elements[i].value.trim();
        var ary =[];
        if (txtValue.length>0)
        {
        var aryValue=txtValue.split(',');
        for(var j=0,aryLen=aryValue.length;j<aryLen;j++)
        {
        var text = aryValue[j].trim();var starts=text.startsWith('[');var ends=text.endsWith(']');
        if (starts&&ends) { ary.push(elementName + "='" + text.replace(/^\[/, "").replace(/\]$/, "") + "'");continue;}
        if (starts) { ary.push(elementName + " LIKE '" + text.replace(/^\[/, "") + "%'");continue;}
        if (ends) { ary.push(elementName + " LIKE '%" + text.replace(/\]$/, "") + "'");continue;}
         ary.push(elementName + " LIKE '%" + text + "%' ");
        }}
        if (ary.length>0){
        aryNameValue.push(elementName);aryNameValue.push(' ('+ ary.join(' OR ') +') ');}}}
        var slectElements = oTable.getElementsByTagName("SELECT"); 
        for(var j=0,len=slectElements.length;j<len;j++)
        { 
            if (!slectElements[j].name) continue; //LKHS-231
            if (slectElements[j].value =='') 
                continue; 
            var elementName = slectElements[j].name.substring(tableForCondition.length+1); 
            if (slectElements[j].value != '0')
            { 
                if (elementName.toLowerCase().endsWith('stringcode') && !elementName.toLowerCase().endsWith('recordstatusstringcode') && !elementName.toLowerCase().endsWith('propertytypestringcode') && !elementName.toLowerCase().endsWith('billtypestringcode')) {
                    var fieldName = elementName.substring(0, elementName.length - 10) + 'Id';
                    aryNameValue.push(fieldName); 
                    aryNameValue.push(fieldName + "='" + slectElements[j].value+ "'");
                }
                else
                { 
                    aryNameValue.push(elementName); 
                    aryNameValue.push(elementName + "='" + slectElements[j].value+ "'");
                }
            }
          }
            var result = ""; for(var a=1;a<aryNameValue.length;a+=2)
            { if (a!=1) result+= "AND "; result+=aryNameValue[a];}
            return result;
        }

// called by popup after save
function refresh(result)
{
    MessageShow(f_GetMessage(result));
    f_ReLoad();
}

function f_ReLoad()
{
    gridManager2.Refresh();
}

function f_init()
{
    OnBeforeMenu();
    _companyId = document.getElementById("<% =this.CompanyID.ClientID%>").value;
}

// enable/disable toolbar buttons by selection (View / GenerateAll always enabled)
function OnBeforeMenu()
{
    var selectRowId = gridManager2.GetSelectedRowIds();
    if (selectRowId == null) { selectRowId = ""; }
    var pc = PubCont.split(",");
    PubPrive = "";
    for (var i = 0; i < pc.length; i++)
    {
        if (pc[i] == "") continue;
        var isDisable = (selectRowId == "") ? 1 : 0;
        var btn = pc[i].toLowerCase();
        if (btn == "view" || btn == "generateall")
            isDisable = 0;
        var obj = document.getElementById(pc[i]);
        if (obj != null) obj.disabled = isDisable;
        PubPrive = PubPrive + isDisable;
    }
}

function OnBeforeShowContextMenu(gridIndex, menu)
{
    if (menu == null) return;
    var items = menu.getItems();
    OnBeforeMenu();
    var p = PubPrive.split("");
    for (var i = 0; i < p.length; i++)
    {
        var item = items.getItem(i);
        if (item != null) item.set_enabled(1 - p[i]);
    }
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" runat="Server">
    <%-- MenuNo placeholder Cash-03-20 (must match Sys_ContextMenu.MnuNo) --%>
    <IFCAUI:SysToolbar ID="SysToolBar3" runat="server" Style="width: 100%"
        ShowSettingMenu="true" LstNo="CB.GIROCollection" TranslateBseNo="CB.GIROCollection"
        MenuClass="CB.GIROCollection" MenuNo="Cash-03-20" ShowEditView="false" ShowFilter="false"
        ShowHelp="true" ShowHelpSetting="true" ShowInterface="false" ShowSort="false"></IFCAUI:SysToolbar>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="SearchContent" runat="Server">
    <IFCAUI:SysCondition ID="SysCondition1" runat="server" LstNo="CB.GIROCollection" />
    <input type="hidden" id="LstOrder" value="1" />
    <input type="hidden" id="CompanyID" name="CompanyID" runat="server" />
    <input type="hidden" id="payCurrencyID" name="payCurrencyID" runat="server" />
    <input type="hidden" id="bankAccountID" name="bankAccountID" runat="server" />
    <input type="hidden" id="hidIsGIROBank" name="hidIsGIROBank" runat="server" />
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="ListContent" runat="server">
    <atlas:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true"></atlas:ScriptManager>
    <IFCAUI:SysList2 UseCheckBox="true" StationaryMargins="Header" runat="server" ID="SysList1"
        LstNo="CB.GIROCollection" Height="95%" Width="100%" ShowContextMenu="true"
        MenuClass="CB.GIROCollection" MenuNo="Cash-03-20">
    </IFCAUI:SysList2>
</asp:Content>
