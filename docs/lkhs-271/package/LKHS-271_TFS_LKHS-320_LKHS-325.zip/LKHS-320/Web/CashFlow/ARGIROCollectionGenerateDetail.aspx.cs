using System;
using System.Text.RegularExpressions;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Framework.Utility.DataAccess;
using IFCA.Business.Finance.Generic;

// LKHS-271: Generate GIRO Collection - detail grid (cloned from ACGeneratePaymentDetail.aspx.cs)
// Query string: guid, CompanyID, BillIDs (bills to add), cancelIDs (GIRODetailID to remove)
// Works on the working table CB_GIROTempDetail of this popup session (guid).
public partial class CashFlow_ARGIROCollectionGenerateDetail : System.Web.UI.Page
{
    protected int detailCount = 0;          // -> popup No. of Documents
    protected decimal detailTotal = 0m;     // -> popup Total Amount

    protected void Page_Load(object sender, EventArgs e)
    {
        GetDataSource();
    }

    private static string CleanIDs(string ids)
    {
        if (string.IsNullOrEmpty(ids)) return "";
        ids = ids.Trim().Trim(',');
        return Regex.IsMatch(ids, @"^\d+(,\d+)*$") ? ids : "";
    }

    private void GetDataSource()
    {
        Guid g;
        if (!Guid.TryParse(Request.QueryString["guid"], out g))
        {
            SysList1.SelectCommandText = "select * from View_CB_GIROCollectionTempDetail where 1=2";
            return;
        }
        string guid = g.ToString("D");
        int companyID = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        string billIDs = CleanIDs(Request.QueryString["BillIDs"]);
        string cancelIDs = CleanIDs(Request.QueryString["cancelIDs"]);
        string userID = SysContext.CurrentUserId;

        // remove checked lines
        if (cancelIDs != "")
        {
            DataAccessHelper.ExecuteNonQuery(string.Format(
                "delete CB_GIROTempDetail where GIROGuid = '{0}' and GIRODetailID in ({1})", guid, cancelIDs));
        }

        // add bills (only still outstanding, same company, not added yet); collect amount = balance
        if (billIDs != "" && companyID > 0)
        {
            DataAccessHelper.ExecuteNonQuery(string.Format(@"
                insert into CB_GIROTempDetail (GIROGuid, BillID, BalanceAmt, CollectAmt, CreateUserID, CreateDate)
                select '{0}', v.BillID, v.BalanceAmt, v.BalanceAmt, {1}, getdate()
                from View_CB_GIROCollectionPending v
                where v.BillID in ({2}) and v.CompanyID = {3}
                  and not exists (select 1 from CB_GIROTempDetail t where t.GIROGuid = '{0}' and t.BillID = v.BillID)",
                guid, FNCommon.ObjToInt(userID), billIDs, companyID));
        }

        SysList1.SelectCommandText = string.Format(
            "select * from View_CB_GIROCollectionTempDetail where GIROGuid = '{0}' order by DebtorName, DocumentNo", guid);

        System.Data.DataTable sum = DataAccessHelper.ExecuteDataTable(string.Format(
            "select count(*) as Cnt, isnull(sum(CollectAmt),0) as Amt from CB_GIROTempDetail where GIROGuid = '{0}'", guid));
        if (sum != null && sum.Rows.Count > 0)
        {
            detailCount = Convert.ToInt32(sum.Rows[0]["Cnt"]);
            detailTotal = Convert.ToDecimal(sum.Rows[0]["Amt"]);
        }

        Common.pf_LoadCustomization(this, "", "Init", guid);
    }
}
