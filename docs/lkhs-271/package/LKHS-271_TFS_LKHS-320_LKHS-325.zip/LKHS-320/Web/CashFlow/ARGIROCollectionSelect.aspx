<%@ Page Language="C#" MasterPageFile="~/Common/MasterBarCondList.master" AutoEventWireup="true" CodeFile="ARGIROCollectionSelect.aspx.cs" Inherits="CashFlow_ARGIROCollectionSelect" Title="Untitled Page" %>

<%@ Register Assembly="IFCA.Framework.BL" Namespace="IFCA.Framework.BL" TagPrefix="cc2" %>
<%-- LKHS-271: Generate GIRO Collection - Import popup: pick more outstanding documents
     Same list / search config as the main screen (LstNo CB.GIROCollection), excluding bills already in the popup --%>

<asp:Content ID="Content1" ContentPlaceHolderID="JSContentPlace" runat="Server">
<script language="javascript" type="text/javascript">
function f_GetMessage(tip)
{
    return {Title:"<%=Strings.GetString("CommonSaveTitle")%>",Tip:tip,Pic:"Remind",Buttons:[{Name:"<%=Strings.GetString("OK") %>",Event:""}]};
}

// return checked BillIDs to the Generate popup
function f_OK()
{
    var billIDs = gridManager2.GetSelectedRowIds();
    if (billIDs == null || billIDs.length == 0)
    {
        MessageShow(f_GetMessage("<%=Strings.GetString("NoRecordSelected") %>"));
        return;
    }
    try
    {
        window.opener.f_ImportBills(billIDs.toString());
    }
    catch (e)
    {
    }
    window.close();
}

// close only this Import window
function f_Close()
{
    window.close();
}

function f_init()
{
}
</script>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="BarContent" runat="Server">
    <IFCAUI:SysToolbar ID="SysToolBar3" runat="server" Style="width: 100%"
        ShowSettingMenu="true" LstNo="CB.GIROCollection" TranslateBseNo="CB.GIROCollection"
        MenuClass="CB.GIROSelect" MenuNo="Cash-03-20" ShowEditView="false" ShowFilter="false"
        ShowHelp="false" ShowHelpSetting="false" ShowInterface="false" ShowSort="false"></IFCAUI:SysToolbar>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="SearchContent" runat="Server">
    <IFCAUI:SysCondition ID="SysCondition1" runat="server" LstNo="CB.GIROCollection" />
    <input type="hidden" id="LstOrder" value="1" />
</asp:Content>

<asp:Content ID="Content4" ContentPlaceHolderID="ListContent" runat="server">
    <atlas:ScriptManager ID="ScriptManager1" runat="server" EnablePageMethods="true"></atlas:ScriptManager>
    <IFCAUI:SysList2 UseCheckBox="true" StationaryMargins="Header" runat="server" ID="SysList1"
        LstNo="CB.GIROCollection" Height="95%" Width="100%" ShowContextMenu="false">
    </IFCAUI:SysList2>
</asp:Content>
