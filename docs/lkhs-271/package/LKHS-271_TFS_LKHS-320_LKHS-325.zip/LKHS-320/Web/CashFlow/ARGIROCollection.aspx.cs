using System;
using IFCA.Framework.BL;

// LKHS-271: Generate GIRO Collection - frame page (cloned from ACPayment.aspx.cs)
public partial class CashFlow_ARGIROCollection : IFCA.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.SysToolBar1.Title = Strings.GetString("S7211");             // same as Generate Payment (company tree)
            this.SysToolBar2.Title = Strings.GetString("SelectBankAccount"); // same as Generate Payment (bank tree)
        }
    }
}
