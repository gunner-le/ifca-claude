using System;
using IFCA.Framework.BL;
using IFCA.Framework.UI;
using IFCA.Business.Finance.Generic;

// LKHS-271: Generate GIRO Collection - Import popup
// Query string: guid (popup session), CompanyID, BankAccountID
public partial class CashFlow_ARGIROCollectionSelect : IFCA.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected override void OnInit(EventArgs e)
    {
        this.SysToolBar3.Title = Strings.GetString("CB.GIRO_Title_Import");

        int companyID     = FNCommon.ObjToInt(Request.QueryString["CompanyID"]);
        int bankAccountID = FNCommon.ObjToInt(Request.QueryString["BankAccountID"]);
        Guid g;
        bool hasGuid = Guid.TryParse(Request.QueryString["guid"], out g);

        if (!Page.IsPostBack)
        {
            if (companyID > 0 && bankAccountID > 0 && hasGuid)
            {
                // outstanding bills of this company GIRO bank, not yet in the Generate popup
                this.SysList1.SelectCommandText = string.Format(
                    "select * from View_CB_GIROCollectionPending where CompanyID={0} and GIROBankAccountID={1} " +
                    "and CurrencyID = (select isnull(CurrencyID,0) from CF_BankAccount where BankAccountID={1}) " +   // GIRO bank currency only
                    "and BillID not in (select BillID from CB_GIROTempDetail where GIROGuid='{2}')",
                    companyID, bankAccountID, g.ToString("D"));
            }
            else
            {
                this.SysList1.SelectCommandText = "select * from View_CB_GIROCollectionPending where 1=2";
            }
            Common.pf_LoadCustomization(this, "", "Init");
        }
        // NOTE: same as ARGIROCollectionLst / ACPaymentLst - base.OnInit(e) not called
    }
}
