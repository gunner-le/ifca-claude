-----------------------------------------------------------------------------------------
-- LKHS-271 - GIRO Collection
-- Script 05: new columns on CB_Receipt
--   IsGiroReceipt    CHAR(1)      'Y' = receipt created by Generate GIRO Collection (Stanley note 12/10 - 1.a)
--   GIRORecordStatus VARCHAR(20)  Generated / Exported / Completed / Failed (spec v1.2 1a.ii)
--   GroupNo          NVARCHAR(50) GIRO batch no (CB_ReceiptGroup.GroupNo) the receipt belongs to (Batch spec 1f)
--   NULL on all three = normal (non-GIRO) receipt.
-- Re-runnable.
-----------------------------------------------------------------------------------------
IF COL_LENGTH('dbo.CB_Receipt', 'IsGiroReceipt') IS NULL
    ALTER TABLE dbo.CB_Receipt ADD IsGiroReceipt CHAR(1) NULL;
GO

IF COL_LENGTH('dbo.CB_Receipt', 'GIRORecordStatus') IS NULL
    ALTER TABLE dbo.CB_Receipt ADD GIRORecordStatus VARCHAR(20) NULL;
GO

IF COL_LENGTH('dbo.CB_Receipt', 'GroupNo') IS NULL
    ALTER TABLE dbo.CB_Receipt ADD GroupNo NVARCHAR(50) NULL;
GO

-- GIRO receipts created before GIRORecordStatus existed and not yet verified -> Generated
UPDATE dbo.CB_Receipt
SET    GIRORecordStatus = 'Generated'
WHERE  IsGiroReceipt = 'Y'
  AND  GIRORecordStatus IS NULL
  AND  RecordStatus = 'Active';
GO

-- Check
SELECT c.name, t.name AS DataType, c.max_length, c.is_nullable
FROM   sys.columns c
JOIN   sys.types t ON t.user_type_id = c.user_type_id
WHERE  c.object_id = OBJECT_ID('dbo.CB_Receipt') AND c.name IN ('IsGiroReceipt', 'GIRORecordStatus', 'GroupNo')
ORDER BY c.name;
-- expected: GIRORecordStatus varchar 20 / GroupNo nvarchar 100 (bytes) / IsGiroReceipt char 1
