-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection: View_CB_GIROCollectionGenerate
-- read view of the popup header (SysTabEdit, write table CB_Receipt)
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 2. Header read view (popup always opens with key 0 -> no row; columns give the field structure)
IF OBJECT_ID('dbo.View_CB_GIROCollectionGenerate', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_GIROCollectionGenerate
GO

CREATE VIEW dbo.View_CB_GIROCollectionGenerate
AS
-- LKHS-271: header of popup ARGIROCollectionGenerate.aspx
SELECT  r.CBReceiptID,
        r.CompanyID,
        r.BankAccountID,
        ba.AccountNo                    AS ACNo,
        ca.Name                         AS BankName,
        r.CurrencyID,
        c.ISOCode                       AS Currency,
        r.PayMethod,
        CAST(NULL AS NVARCHAR(150))     AS PayMethodStringCode,
        CAST(NULL AS DATETIME)          AS ProcessingDate,
        CAST(NULL AS NVARCHAR(50))      AS Module,
        CAST(NULL AS NVARCHAR(50))      AS ModuleName,
        r.DocumentDate,                                     -- Payment Date (D08)
        r.ReferenceNo,                                      -- Reference (D34)
        r.DocumentAmt,
        r.RecordStatus
FROM    dbo.CB_Receipt r WITH (NOLOCK)
        LEFT JOIN dbo.CF_BankAccount ba WITH (NOLOCK) ON ba.BankAccountID = r.BankAccountID
        LEFT JOIN dbo.CF_Account     ca WITH (NOLOCK) ON ca.AccountID     = ba.AccountID
        LEFT JOIN dbo.CF_Currency    c  WITH (NOLOCK) ON c.CurrencyID     = r.CurrencyID
GO
