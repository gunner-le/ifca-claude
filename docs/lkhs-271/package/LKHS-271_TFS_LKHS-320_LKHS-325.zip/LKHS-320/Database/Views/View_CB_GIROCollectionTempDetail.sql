-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection: View_CB_GIROCollectionTempDetail
-- read view of the detail grid of the popup
-- Requires: table CB_GIROTempDetail, view View_CB_GIROCollectionPending
-- Re-runnable.
-----------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.CB_GIROTempDetail', 'U') IS NULL OR OBJECT_ID('dbo.View_CB_GIROCollectionPending', 'V') IS NULL
BEGIN
    RAISERROR('LKHS-271: create table CB_GIROTempDetail and view View_CB_GIROCollectionPending first.', 16, 1)
    SET NOEXEC ON
END
GO

-- 3. Detail grid read view
IF OBJECT_ID('dbo.View_CB_GIROCollectionTempDetail', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_GIROCollectionTempDetail
GO

CREATE VIEW dbo.View_CB_GIROCollectionTempDetail
AS
-- LKHS-271: detail grid of popup (bills still outstanding only)
SELECT  d.GIRODetailID,
        d.GIROGuid,
        d.BillID,
        v.CompanyID,
        v.Module,
        v.ReceiptType,
        v.DebtorID,
        v.DebtorAccount,
        v.DebtorName,
        v.DocumentNo,
        v.DocumentDate,
        v.DueDate,
        v.DocumentDesc,
        v.CurrencyID,
        v.Currency,
        v.DocumentAmt,
        v.BalanceAmt,
        d.CollectAmt
FROM    dbo.CB_GIROTempDetail d WITH (NOLOCK)
        INNER JOIN dbo.View_CB_GIROCollectionPending v ON v.BillID = d.BillID
GO

SET NOEXEC OFF
GO
