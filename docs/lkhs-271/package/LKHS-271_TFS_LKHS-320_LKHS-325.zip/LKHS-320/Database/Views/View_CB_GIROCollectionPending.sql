-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection
-- Script 01: Source view for the list
-- Re-runnable. Run order: see RUN_ORDER.txt
-- Depends on master setup columns (LKHS-271 sub-tasks):
--   CF_Company.AllowGiroProcess, CF_CompanyGiroBank (company GIRO bank: GiroBankAccountID),
--   AR_Debtor.AllowGiroProcess / GiroBankSwiftCodeID / GiroAccountNo
-----------------------------------------------------------------------------------------
IF OBJECT_ID('dbo.CF_CompanyGiroBank', 'U') IS NULL
   OR COL_LENGTH('dbo.CF_Company', 'AllowGiroProcess') IS NULL
   OR COL_LENGTH('dbo.AR_Debtor', 'AllowGiroProcess') IS NULL
   OR COL_LENGTH('dbo.AR_Debtor', 'GiroBankSwiftCodeID') IS NULL
   OR COL_LENGTH('dbo.AR_Debtor', 'GiroAccountNo') IS NULL
BEGIN
    RAISERROR('LKHS-271: GIRO master columns not found. Run master setup scripts first.', 16, 1)
    SET NOEXEC ON
END
GO

IF OBJECT_ID('dbo.View_CB_GIROCollectionPending', 'V') IS NOT NULL
    DROP VIEW dbo.View_CB_GIROCollectionPending
GO

CREATE VIEW dbo.View_CB_GIROCollectionPending
AS
-- LKHS-271: Outstanding AR bill lines (AR_Trx) of debtors with GIRO setup.
-- List page filters by CompanyID + GIROBankAccountID (= bank selected in Bank tree).
-- One row per bill per active company GIRO bank (CF_CompanyGiroBank) -> always filter by GIROBankAccountID.
SELECT  t.BillID,
        t.CompanyID,
        CAST(CASE d.RefTable                                          -- module = debtor source (1-1 with ReceiptType)
                 WHEN 'RT_RentalContract' THEN 'Rental Management'
                 WHEN 'CF_Company'        THEN 'Other Receivable'
                 WHEN 'CF_Client'         THEN 'Construction Management'
                 WHEN 'PS_Sale'           THEN 'Property Sales'
             END AS NVARCHAR(50))               AS Module,
        CAST(CASE d.RefTable                                          -- CB_Receipt.ReceiptType to create
                 WHEN 'RT_RentalContract' THEN 'MC_Fee'
                 WHEN 'CF_Company'        THEN 'OD_Receipt'
                 WHEN 'CF_Client'         THEN 'PM_Receipt'
                 WHEN 'PS_Sale'           THEN 'PS_Payment'
             END AS NVARCHAR(20))               AS ReceiptType,
        t.DebtorID,
        d.DebtorAcct                            AS DebtorAccount,
        a.Name                                  AS DebtorName,
        t.DocumentNo,
        t.DocumentDate,
        t.DueDate,
        t.DocumentDesc,
        t.CurrencyID,
        c.ISOCode                               AS Currency,
        t.DocumentAmt,
        bal.BalanceAmt,                                     -- see CROSS APPLY bal
        t.ExchangeRate                          AS TrxExchangeRate,
        bi.ItemCode,                                        -- Rental: 'Interest' -> MCInterest.PaidBill on collection
        cgb.GiroBankAccountID                   AS GIROBankAccountID, -- company GIRO bank (CF_CompanyGiroBank)
        d.GiroBankSwiftCodeID,
        d.GiroAccountNo,
        t.IsDispute,
        t.StakeHolderFlag,                                  -- Property Sales: passed to Alloction.AddCBAndBill
        t.RefTable,
        t.RecordStatus
FROM    dbo.AR_Trx t WITH (NOLOCK)
        INNER JOIN dbo.AR_Debtor   d   WITH (NOLOCK) ON d.DebtorID    = t.DebtorID
        INNER JOIN dbo.CF_Account  a   WITH (NOLOCK) ON a.AccountID   = d.AccountID
        INNER JOIN dbo.CF_Currency c   WITH (NOLOCK) ON c.CurrencyID  = t.CurrencyID
        INNER JOIN dbo.CF_Company  com WITH (NOLOCK) ON com.CompanyID = t.CompanyID
        INNER JOIN dbo.CF_CompanyGiroBank cgb WITH (NOLOCK) ON cgb.CompanyID = t.CompanyID
                                                         AND cgb.RecordStatus = 'Active'
                                                         AND cgb.GiroBankAccountID IS NOT NULL
        LEFT  JOIN dbo.AR_BillItem bi  WITH (NOLOCK) ON bi.BillItemID = t.BillItemID
        LEFT  JOIN dbo.CF_PopupLstElement bt WITH (NOLOCK) ON bt.PopupLstElementID = bi.BillTypeID
        OUTER APPLY (SELECT SUM(CASE WHEN x.RecordStatus NOT IN ('Inactive', 'Voided') THEN x.AllocAmt ELSE 0 END) AS AllocAmt,
                            SUM(CASE WHEN x.RecordStatus = 'Active' THEN x.AllocAmt ELSE 0 END)                    AS ActiveAllocAmt
                     FROM dbo.AR_Allocation x WITH (NOLOCK)
                     WHERE x.BillID = t.BillID) al
        -- Balance source = the one the module's own Collection screen uses:
        --   Rental (ArFeeAdd2 / View_MC_ReceiptBill), Other Receivable (OtherReceiptEditSG / View_AR_TrxOfOtherDebtor)
        --   and Property Sales (PSReceiptAdd) read and maintain AR_Trx.BalanceAmt
        --   Construction (PMReceivable/ArFeeAdd / View_PM_ReceiptBillAdd): DocumentAmt - 'Active' allocations
        CROSS APPLY (SELECT CASE WHEN d.RefTable IN ('RT_RentalContract', 'CF_Company', 'PS_Sale')
                                 THEN t.BalanceAmt
                                 WHEN d.RefTable = 'CF_Client'
                                 THEN t.DocumentAmt - ISNULL(al.ActiveAllocAmt, 0)
                                 ELSE t.DocumentAmt - ISNULL(al.AllocAmt, 0)
                            END AS BalanceAmt) bal
WHERE   t.RecordStatus = CASE d.RefTable                  -- open bill status differs per module
                             WHEN 'CF_Company' THEN 'Approved'   -- OtherReceiptEditSG: RecordStatus IN ('Approved')
                             WHEN 'CF_Client'  THEN 'Approved'   -- PMReceivable/ArFeeAdd: RecordStatus = 'Approved'
                             ELSE 'Active'                       -- Rental, Property Sales (PSReceiptAdd)
                         END
  AND   t.DocumentAmt > 0                                  -- debit bills only (exclude CN / adjustment)
  AND   ROUND(bal.BalanceAmt, 2) > 0                       -- still outstanding
  AND   t.DocumentDate IS NOT NULL                         -- same filters as Rental collection screen
  AND   ISNULL(t.IsFreeze, 'N') <> 'Y'                     -- bill on hold
  AND   d.AllowGiroProcess = 'Y'                           -- debtor allowed for GIRO (spec v1.2 filter #4)
  AND   com.AllowGiroProcess = 'Y'                         -- company allowed for GIRO (spec v1.2 company panel)
  AND   d.RefTable IN ('RT_RentalContract', 'CF_Company', 'CF_Client', 'PS_Sale')  -- 4 GIRO modules
  AND   ISNULL(bt.ElementCode, '') <> 'RT.Deposit'           -- exclude rental deposits (collected by MC_Deposit receipt)
  AND   ISNULL(t.RefTable, '') <> 'RT_Deposit'
  -- Other Receivable: same bill set as View_AR_TrxOfOtherDebtor (original bill, or debit note from AR_Trx)
  AND   (d.RefTable <> 'CF_Company'
         OR (    (t.RefTable IS NULL OR (t.RefTable = 'AR_Trx' AND t.IsDebit = 'Y'))
             AND EXISTS (SELECT 1 FROM dbo.View_AR_BillItemOfOtherDebtor ob WHERE ob.BillItemID = t.BillItemID)))
  -- Construction: same bill set as View_PM_ReceiptBillAdd (progress claim / retention / MOS / other billing)
  AND   (d.RefTable <> 'CF_Client'
         OR (    t.BalanceAmt > 0
             AND t.ReceivableType IN ('PM_Retention', 'PM_Claim', 'PM_MOS', 'PM_OtherExpense', 'PM_OtherBilling')))
  -- Property Sales: same bill set as PSReceiptAdd (GetDataSource)
  AND   (d.RefTable <> 'PS_Sale'
         OR (    t.VoidDate IS NULL AND t.VoidByID IS NULL
             AND t.DocumentNo IS NOT NULL
             AND t.RequestUserID IS NULL
             AND (ISNULL(t.StakeHolderFlag, 'N') = 'N'
                  OR (t.StakeHolderFlag = 'Y' AND t.MasterBillID IS NULL AND t.TaxAmt > 0))
             -- unit under ContractLock cannot be collected (PS.LockCannotReceipt)
             AND NOT EXISTS (SELECT 1
                             FROM dbo.PS_Sale s WITH (NOLOCK)
                                  INNER JOIN dbo.PS_Unit u WITH (NOLOCK) ON u.UnitID = s.UnitID
                             WHERE s.SaleID = d.RefRecordID
                               AND u.LockStatus = 'ContractLock')))
GO

SET NOEXEC OFF
GO
