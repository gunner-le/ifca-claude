-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection: CB_GIROTempDetail
-- working table of popup Generate / Generate All: selected bills of one popup session (by GIROGuid)
-- Created once, never dropped.
-- Re-runnable.
-----------------------------------------------------------------------------------------

-- 1. Working table (same idea as CB_PaymentTempDetail). Created once, never dropped.
IF OBJECT_ID('dbo.CB_GIROTempDetail', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.CB_GIROTempDetail
    (
        GIRODetailID  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CB_GIROTempDetail PRIMARY KEY,
        GIROGuid      VARCHAR(36)       NOT NULL,
        BillID        INT               NOT NULL,
        BalanceAmt    DECIMAL(22,10)    NOT NULL,   -- bill balance when added
        CollectAmt    DECIMAL(22,10)    NOT NULL,   -- amount to collect (default = balance)
        CreateUserID  INT               NOT NULL,
        CreateDate    DATETIME          NOT NULL
    )
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CB_GIROTempDetail_GIROGuid' AND object_id = OBJECT_ID('dbo.CB_GIROTempDetail'))
    CREATE INDEX IX_CB_GIROTempDetail_GIROGuid ON dbo.CB_GIROTempDetail (GIROGuid, BillID)
GO
