-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection - popup Generate / Generate All
-- Script 04: Sys_ framework config + strings
--   Header  : BseNo / TabNo / MnuClass CB.GIROCollectionGenerate  (SysTabEdit, cloned from AC.PaymentConfirm)
--   Detail  : BseNo / LstNo CB.GIROCollectionDetail  (SysList2 in iframe)
--   Container CB.GIROCollectionGen / card CB.GIRODetail (Import / Remove buttons)
--   MnuNo     Cash-03-20
-- Re-runnable: each block deletes existing rows then inserts again.
-- Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------

-- Sys_Base
IF EXISTS (SELECT TOP 1 1 FROM Sys_Base WITH (NOLOCK) WHERE BseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail'))
BEGIN
    DELETE FROM Sys_Base WHERE BseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail');
END

INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROCollectionGenerate', N'GIRO Collection Generation', N'Sys_Base_Name_CB.GIROCollectionGenerate', N'View_CB_GIROCollectionGenerate', N'CB_Receipt', N'GIRO Collection Generation', N'Sys_Base_Desc_CB.GIROCollectionGenerate', N'CBReceiptID', NULL, NULL, NULL);
INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROCollectionDetail', N'GIRO Collection Detail', N'Sys_Base_Name_CB.GIROCollectionDetail', N'View_CB_GIROCollectionTempDetail', N'CB_GIROTempDetail', N'GIRO Collection Detail', N'Sys_Base_Desc_CB.GIROCollectionDetail', N'GIRODetailID', NULL, NULL, NULL);

-- Sys_BaseDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail'))
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail');
END

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'ACNo', N'Account No.', N'Account No.', N'CB.GIROCollectionGenerate_ACNo', N'CB.GIROCollectionGenerate_ACNo', 50, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 1, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, N'BankAccountID', 1, N'1', N'1', NULL, NULL, N'CB_Receipt', N'BankAccountID', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'BankName', N'Bank Name', N'Bank Name', N'CB.GIROCollectionGenerate_BankName', N'CB.GIROCollectionGenerate_BankName', 150, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 2, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'Currency', N'Currency', N'Currency', N'CB.GIROCollectionGenerate_Currency', N'CB.GIROCollectionGenerate_Currency', 40, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 3, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, N'1', N'1', NULL, NULL, N'CB_Receipt', N'CurrencyID', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'PayMethodStringCode', N'Payment Method', N'Payment Method', N'CB.GIROCollectionGenerate_PayMethodStringCode', N'CB.GIROCollectionGenerate_PayMethodStringCode', 150, N'L', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 4, N'PayMethod', N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'PayMethod', 1, N'1', N'1', NULL, NULL, N'CB_Receipt', N'PayMethod', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'DocumentDate', N'Payment Date', N'Payment Date', N'CB.GIROCollectionGenerate_DocumentDate', N'CB.GIROCollectionGenerate_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 80, NULL, 1, N'1', N'1', NULL, NULL, N'CB_Receipt', N'DocumentDate', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'ReferenceNo', N'Reference No', N'Reference No', N'CB.GIROCollectionGenerate_ReferenceNo', N'CB.GIROCollectionGenerate_ReferenceNo', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 6, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, N'1', N'1', NULL, NULL, N'CB_Receipt', N'ReferenceNo', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'DocumentCount', N'No. of Documents', N'No. of Documents', N'CB.GIROCollectionGenerate_DocumentCount', N'CB.GIROCollectionGenerate_DocumentCount', 8, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 7, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'TotalAmt', N'Total Amount', N'Total Amount', N'CB.GIROCollectionGenerate_TotalAmt', N'CB.GIROCollectionGenerate_TotalAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 8, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'CBReceiptID', N'Receipt ID', N'Receipt ID', N'CB.GIROCollectionGenerate_CBReceiptID', N'CB.GIROCollectionGenerate_CBReceiptID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 20, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROCollectionGenerate_CompanyID', N'CB.GIROCollectionGenerate_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 21, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, N'CB_Receipt', N'CompanyID', 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'BankAccountID', N'Bank Account ID', N'Bank Account ID', N'CB.GIROCollectionGenerate_BankAccountID', N'CB.GIROCollectionGenerate_BankAccountID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 22, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROCollectionGenerate_CurrencyID', N'CB.GIROCollectionGenerate_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 23, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'PayMethod', N'Pay Method ID', N'Pay Method ID', N'CB.GIROCollectionGenerate_PayMethod', N'CB.GIROCollectionGenerate_PayMethod', 4, N'I', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 24, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'Module', N'Module Code', N'Module Code', N'CB.GIROCollectionGenerate_Module', N'CB.GIROCollectionGenerate_Module', 50, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 25, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'DocumentAmt', N'Amount', N'Amount', N'CB.GIROCollectionGenerate_DocumentAmt', N'CB.GIROCollectionGenerate_DocumentAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, NULL, N'1', NULL, 26, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, N'CB_Receipt', N'DocumentAmt', 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionGenerate', N'RecordStatus', N'Status', N'Status', N'CB.GIROCollectionGenerate_RecordStatus', N'CB.GIROCollectionGenerate_RecordStatus', 20, N'S', 80, N'left', NULL, N'1', NULL, NULL, N'1', NULL, 27, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'GIRODetailID', N'Detail ID', N'Detail ID', N'CB.GIROCollectionDetail_GIRODetailID', N'CB.GIROCollectionDetail_GIRODetailID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'GIROGuid', N'GUID', N'GUID', N'CB.GIROCollectionDetail_GIROGuid', N'CB.GIROCollectionDetail_GIROGuid', 36, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'BillID', N'Bill ID', N'Bill ID', N'CB.GIROCollectionDetail_BillID', N'CB.GIROCollectionDetail_BillID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROCollectionDetail_CompanyID', N'CB.GIROCollectionDetail_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'Module', N'Module', N'Module', N'CB.GIROCollectionDetail_Module', N'CB.GIROCollectionDetail_Module', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'ReceiptType', N'Receipt Type', N'Receipt Type', N'CB.GIROCollectionDetail_ReceiptType', N'CB.GIROCollectionDetail_ReceiptType', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DebtorID', N'Debtor ID', N'Debtor ID', N'CB.GIROCollectionDetail_DebtorID', N'CB.GIROCollectionDetail_DebtorID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DebtorAccount', N'Debtor Account', N'Debtor Account', N'CB.GIROCollectionDetail_DebtorAccount', N'CB.GIROCollectionDetail_DebtorAccount', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DebtorName', N'Debtor Name', N'Debtor Name', N'CB.GIROCollectionDetail_DebtorName', N'CB.GIROCollectionDetail_DebtorName', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DocumentNo', N'Document No', N'Document No', N'CB.GIROCollectionDetail_DocumentNo', N'CB.GIROCollectionDetail_DocumentNo', 60, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DocumentDate', N'Document Date', N'Document Date', N'CB.GIROCollectionDetail_DocumentDate', N'CB.GIROCollectionDetail_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DueDate', N'Due Date', N'Due Date', N'CB.GIROCollectionDetail_DueDate', N'CB.GIROCollectionDetail_DueDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DocumentDesc', N'Document Description', N'Document Description', N'CB.GIROCollectionDetail_DocumentDesc', N'CB.GIROCollectionDetail_DocumentDesc', 500, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROCollectionDetail_CurrencyID', N'CB.GIROCollectionDetail_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'Currency', N'Currency', N'Currency', N'CB.GIROCollectionDetail_Currency', N'CB.GIROCollectionDetail_Currency', 40, N'L2', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'DocumentAmt', N'Document Amount', N'Document Amount', N'CB.GIROCollectionDetail_DocumentAmt', N'CB.GIROCollectionDetail_DocumentAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'BalanceAmt', N'Balance Amount', N'Balance Amount', N'CB.GIROCollectionDetail_BalanceAmt', N'CB.GIROCollectionDetail_BalanceAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');
INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollectionDetail', N'CollectAmt', N'Collect Amount', N'Collect Amount', N'CB.GIROCollectionDetail_CollectAmt', N'CB.GIROCollectionDetail_CollectAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');

-- Sys_Tab
IF EXISTS (SELECT TOP 1 1 FROM Sys_Tab WITH (NOLOCK) WHERE TabNo = N'CB.GIROCollectionGenerate')
BEGIN
    DELETE FROM Sys_Tab WHERE TabNo = N'CB.GIROCollectionGenerate';
END

INSERT INTO Sys_Tab ([TabNo], [TabName], [TabBseNo], [TabNameStringCode])
VALUES (N'CB.GIROCollectionGenerate', N'GIRO Generation', N'CB.GIROCollectionGenerate', N'Sys_Tab_Name_CB.GIROCollectionGenerate');

-- Sys_TabClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabClass WITH (NOLOCK) WHERE TcsTabNo = N'CB.GIROCollectionGenerate')
BEGIN
    DELETE FROM Sys_TabClass WHERE TcsTabNo = N'CB.GIROCollectionGenerate';
END

INSERT INTO Sys_TabClass ([TcsTabNo], [TcsNo], [TcsName], [TcsNameEN], [TcsNameStringCode], [TcsClass], [TcsListNum])
VALUES (N'CB.GIROCollectionGenerate', N'GIRO0001', N'GIRO Collection Generation', N'GIRO Collection Generation', N'TabClass_CB.GIROCollectionGenerate_GIRO0001', NULL, 2);

-- Sys_TabDt (2 fields per row)
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabDt WITH (NOLOCK) WHERE TdtTabNo = N'CB.GIROCollectionGenerate')
BEGIN
    DELETE FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROCollectionGenerate';
END

INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'ACNo', N'Account No.', N'CB.GIROCollectionGenerate_ACNo', N'CB.GIROCollectionGenerate_ACNo', NULL, 1, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'BankName', N'Bank Name', N'CB.GIROCollectionGenerate_BankName', N'CB.GIROCollectionGenerate_BankName', NULL, 2, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'Currency', N'Currency', N'CB.GIROCollectionGenerate_Currency', N'CB.GIROCollectionGenerate_Currency', NULL, 3, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'PayMethodStringCode', N'Payment Method', N'CB.GIROCollectionGenerate_PayMethodStringCode', N'CB.GIROCollectionGenerate_PayMethodStringCode', N'1', 4, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'DocumentDate', N'Payment Date', N'CB.GIROCollectionGenerate_DocumentDate', N'CB.GIROCollectionGenerate_DocumentDate', N'1', 5, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'ReferenceNo', N'Reference No', N'CB.GIROCollectionGenerate_ReferenceNo', N'CB.GIROCollectionGenerate_ReferenceNo', N'1', 6, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'DocumentCount', N'No. of Documents', N'CB.GIROCollectionGenerate_DocumentCount', N'CB.GIROCollectionGenerate_DocumentCount', NULL, 7, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionGenerate', N'GIRO0001', N'TotalAmt', N'Total Amount', N'CB.GIROCollectionGenerate_TotalAmt', N'CB.GIROCollectionGenerate_TotalAmt', NULL, 8, NULL, NULL, NULL, NULL);

-- Sys_TabCard (detail container + Import / Remove buttons)
IF EXISTS (SELECT TOP 1 1 FROM Sys_TabCard WITH (NOLOCK) WHERE TcdTabNo = N'CB.GIROCollectionGen')
BEGIN
    DELETE FROM Sys_TabCard WHERE TcdTabNo = N'CB.GIROCollectionGen';
END

INSERT INTO Sys_TabCard ([TcdTabNo], [TcdCardNo], [TcdStringCode], [TcdScript], [TcdOrder], [MnuClass], [MnuNo])
VALUES (N'CB.GIROCollectionGen', N'CB.GIRODetail', N'CB.GIRODetail_Title', NULL, 1, N'CB.GIRODetail', N'Cash-03-20');

-- Sys_List (detail grid)
IF EXISTS (SELECT TOP 1 1 FROM Sys_List WITH (NOLOCK) WHERE LstNo = N'CB.GIROCollectionDetail')
BEGIN
    DELETE FROM Sys_List WHERE LstNo = N'CB.GIROCollectionDetail';
END

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROCollectionDetail', -1, N'GIRO Collection Detail', N'Sys_List_Name_CB.GIROCollectionDetail_-1', N'GIRO Collection Detail', N'Sys_List_Title_CB.GIROCollectionDetail_-1', N'CB.GIROCollectionDetail', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);
INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROCollectionDetail', 1, N'GIRO Collection Detail', N'Sys_List_Name_CB.GIROCollectionDetail_1', N'GIRO Collection Detail', N'Sys_List_Title_CB.GIROCollectionDetail_1', N'CB.GIROCollectionDetail', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);

-- Sys_ListDt (detail grid)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo = N'CB.GIROCollectionDetail')
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROCollectionDetail';
END

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'Module', N'Module', NULL, N'CB.GIROCollectionDetail_Module', N'CB.GIROCollectionDetail_Module', 50, 120, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROCollectionDetail_DebtorAccount', N'CB.GIROCollectionDetail_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROCollectionDetail_DebtorName', N'CB.GIROCollectionDetail_DebtorName', 200, 200, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DocumentNo', N'Document No', NULL, N'CB.GIROCollectionDetail_DocumentNo', N'CB.GIROCollectionDetail_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROCollectionDetail_DocumentDate', N'CB.GIROCollectionDetail_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DueDate', N'Due Date', NULL, N'CB.GIROCollectionDetail_DueDate', N'CB.GIROCollectionDetail_DueDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DocumentDesc', N'Document Description', NULL, N'CB.GIROCollectionDetail_DocumentDesc', N'CB.GIROCollectionDetail_DocumentDesc', 500, 250, N'left', NULL, N'S', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'Currency', N'Currency', NULL, N'CB.GIROCollectionDetail_Currency', N'CB.GIROCollectionDetail_Currency', 40, 50, N'left', NULL, N'L2', N'1', 8, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'DocumentAmt', N'Document Amount', NULL, N'CB.GIROCollectionDetail_DocumentAmt', N'CB.GIROCollectionDetail_DocumentAmt', 13, 90, N'right', NULL, N'FM', N'1', 9, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'BalanceAmt', N'Balance Amount', NULL, N'CB.GIROCollectionDetail_BalanceAmt', N'CB.GIROCollectionDetail_BalanceAmt', 13, 90, N'right', NULL, N'FM', N'1', 10, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', -1, N'CollectAmt', N'Collect Amount', NULL, N'CB.GIROCollectionDetail_CollectAmt', N'CB.GIROCollectionDetail_CollectAmt', 13, 90, N'right', NULL, N'FM', N'1', 11, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'Module', N'Module', NULL, N'CB.GIROCollectionDetail_Module', N'CB.GIROCollectionDetail_Module', 50, 120, N'left', NULL, N'S', N'1', 1, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROCollectionDetail_DebtorAccount', N'CB.GIROCollectionDetail_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROCollectionDetail_DebtorName', N'CB.GIROCollectionDetail_DebtorName', 200, 200, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DocumentNo', N'Document No', NULL, N'CB.GIROCollectionDetail_DocumentNo', N'CB.GIROCollectionDetail_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROCollectionDetail_DocumentDate', N'CB.GIROCollectionDetail_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 5, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DueDate', N'Due Date', NULL, N'CB.GIROCollectionDetail_DueDate', N'CB.GIROCollectionDetail_DueDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DocumentDesc', N'Document Description', NULL, N'CB.GIROCollectionDetail_DocumentDesc', N'CB.GIROCollectionDetail_DocumentDesc', 500, 250, N'left', NULL, N'S', N'1', 7, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'Currency', N'Currency', NULL, N'CB.GIROCollectionDetail_Currency', N'CB.GIROCollectionDetail_Currency', 40, 50, N'left', NULL, N'L2', N'1', 8, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'DocumentAmt', N'Document Amount', NULL, N'CB.GIROCollectionDetail_DocumentAmt', N'CB.GIROCollectionDetail_DocumentAmt', 13, 90, N'right', NULL, N'FM', N'1', 9, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'BalanceAmt', N'Balance Amount', NULL, N'CB.GIROCollectionDetail_BalanceAmt', N'CB.GIROCollectionDetail_BalanceAmt', 13, 90, N'right', NULL, N'FM', N'1', 10, N'1', NULL, NULL, NULL);
INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollectionDetail', 1, N'CollectAmt', N'Collect Amount', NULL, N'CB.GIROCollectionDetail_CollectAmt', N'CB.GIROCollectionDetail_CollectAmt', 13, 90, N'right', NULL, N'FM', N'1', 11, N'1', NULL, NULL, NULL);

-- Sys_ContextMenuClass
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenuClass WITH (NOLOCK) WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect'))
BEGIN
    DELETE FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect');
END

INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROCollectionGenerate', N'MnuClass_CB.GIROCollectionGenerate');
INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIRODetail', N'MnuClass_CB.GIRODetail');
INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROSelect', N'MnuClass_CB.GIROSelect');

-- Sys_ContextMenu (Save / Close on toolbar, Import / Remove on detail card)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect') AND MnuNo = N'Cash-03-20')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect') AND MnuNo = N'Cash-03-20';
END

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Save', N'CB.GIROCollectionGenerate', N'Cash-03-20', N'Cash-03-20_CB.GIROCollectionGenerate_Save', N' if(!f_SaveData()) return ', NULL, 1, N'N', N'N', N'btn_save.gif', NULL, 2);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROCollectionGenerate', N'Cash-03-20', N'Cash-03-20_CB.GIROCollectionGenerate_Close', N'f_Close()', NULL, 1, N'N', N'N', N'btn_exit.gif', NULL, 3);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Select', N'CB.GIRODetail', N'Cash-03-20', N'Cash-03-20_CB.GIRODetail_Select', N'f_Select()', NULL, 1, N'N', N'N', N'btn_selectall.gif', NULL, 1);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Cancel', N'CB.GIRODetail', N'Cash-03-20', N'Cash-03-20_CB.GIRODetail_Cancel', N'f_Cancel()', NULL, 1, N'N', N'N', N'btn_delete.gif', NULL, 3);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'OK', N'CB.GIROSelect', N'Cash-03-20', N'Cash-03-20_CB.GIROSelect_OK', N'f_OK()', NULL, 1, N'N', N'N', N'btn_save.gif', NULL, 1);
INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Close', N'CB.GIROSelect', N'Cash-03-20', N'Cash-03-20_CB.GIROSelect_Close', N'f_Close()', NULL, 1, N'N', N'N', N'btn_exit.gif', NULL, 2);

-- CF_String
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (
    N'CB.GIROCollectionGenerate_ACNo',
    N'CB.GIROCollectionGenerate_BankName',
    N'CB.GIROCollectionGenerate_Currency',
    N'CB.GIROCollectionGenerate_PayMethodStringCode',
    N'CB.GIROCollectionGenerate_DocumentDate',
    N'CB.GIROCollectionGenerate_ReferenceNo',
    N'CB.GIROCollectionGenerate_DocumentCount',
    N'CB.GIROCollectionGenerate_TotalAmt',
    N'CB.GIROCollectionGenerate_CBReceiptID',
    N'CB.GIROCollectionGenerate_CompanyID',
    N'CB.GIROCollectionGenerate_BankAccountID',
    N'CB.GIROCollectionGenerate_CurrencyID',
    N'CB.GIROCollectionGenerate_PayMethod',
    N'CB.GIROCollectionGenerate_Module',
    N'CB.GIROCollectionGenerate_DocumentAmt',
    N'CB.GIROCollectionGenerate_RecordStatus',
    N'CB.GIROCollectionDetail_GIRODetailID',
    N'CB.GIROCollectionDetail_GIROGuid',
    N'CB.GIROCollectionDetail_BillID',
    N'CB.GIROCollectionDetail_CompanyID',
    N'CB.GIROCollectionDetail_Module',
    N'CB.GIROCollectionDetail_ReceiptType',
    N'CB.GIROCollectionDetail_DebtorID',
    N'CB.GIROCollectionDetail_DebtorAccount',
    N'CB.GIROCollectionDetail_DebtorName',
    N'CB.GIROCollectionDetail_DocumentNo',
    N'CB.GIROCollectionDetail_DocumentDate',
    N'CB.GIROCollectionDetail_DueDate',
    N'CB.GIROCollectionDetail_DocumentDesc',
    N'CB.GIROCollectionDetail_CurrencyID',
    N'CB.GIROCollectionDetail_Currency',
    N'CB.GIROCollectionDetail_DocumentAmt',
    N'CB.GIROCollectionDetail_BalanceAmt',
    N'CB.GIROCollectionDetail_CollectAmt',
    N'Sys_Base_Name_CB.GIROCollectionGenerate',
    N'Sys_Base_Desc_CB.GIROCollectionGenerate',
    N'Sys_Base_Name_CB.GIROCollectionDetail',
    N'Sys_Base_Desc_CB.GIROCollectionDetail',
    N'Sys_List_Name_CB.GIROCollectionDetail_-1',
    N'Sys_List_Title_CB.GIROCollectionDetail_-1',
    N'Sys_List_Name_CB.GIROCollectionDetail_1',
    N'Sys_List_Title_CB.GIROCollectionDetail_1',
    N'Sys_Tab_Name_CB.GIROCollectionGenerate',
    N'TabClass_CB.GIROCollectionGenerate_GIRO0001',
    N'CB.GIRODetail_Title',
    N'MnuClass_CB.GIROCollectionGenerate',
    N'MnuClass_CB.GIRODetail',
    N'MnuClass_CB.GIROSelect',
    N'Cash-03-20_CB.GIROCollectionGenerate_Save',
    N'Cash-03-20_CB.GIROCollectionGenerate_Close',
    N'Cash-03-20_CB.GIRODetail_Select',
    N'Cash-03-20_CB.GIRODetail_Cancel',
    N'Cash-03-20_CB.GIROSelect_OK',
    N'Cash-03-20_CB.GIROSelect_Close',
    N'CB.GIRO_Title_Generate',
    N'CB.GIRO_Title_GenerateAll',
    N'CB.GIRO_NoDetail',
    N'CB.GIRO_PaymentDateRequired',
    N'CB.GIRO_PaymentDateMustNotPast',
    N'CB.GIRO_PayMethodRequired',
    N'CB.GIRO_ReferenceNoRequired',
    N'CB.GIRO_AllSummary',
    N'CB.GIRO_InvalidFilter',
    N'CB.GIRO_SaveSuccess',
    N'CB.GIRO_BillChanged',
    N'CB.GIRO_ModuleNotSupported',
    N'CB.GIRO_Title_Import',
    N'CB.GIROCollectionGenerate_ProcessingDate',
    N'CB.GIROCollectionGenerate_ModuleName',
    N'CB.GIRO_ModuleAll',
    N'CB.GIRO_ProcessingDateRequired'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (
    N'CB.GIROCollectionGenerate_ACNo',
    N'CB.GIROCollectionGenerate_BankName',
    N'CB.GIROCollectionGenerate_Currency',
    N'CB.GIROCollectionGenerate_PayMethodStringCode',
    N'CB.GIROCollectionGenerate_DocumentDate',
    N'CB.GIROCollectionGenerate_ReferenceNo',
    N'CB.GIROCollectionGenerate_DocumentCount',
    N'CB.GIROCollectionGenerate_TotalAmt',
    N'CB.GIROCollectionGenerate_CBReceiptID',
    N'CB.GIROCollectionGenerate_CompanyID',
    N'CB.GIROCollectionGenerate_BankAccountID',
    N'CB.GIROCollectionGenerate_CurrencyID',
    N'CB.GIROCollectionGenerate_PayMethod',
    N'CB.GIROCollectionGenerate_Module',
    N'CB.GIROCollectionGenerate_DocumentAmt',
    N'CB.GIROCollectionGenerate_RecordStatus',
    N'CB.GIROCollectionDetail_GIRODetailID',
    N'CB.GIROCollectionDetail_GIROGuid',
    N'CB.GIROCollectionDetail_BillID',
    N'CB.GIROCollectionDetail_CompanyID',
    N'CB.GIROCollectionDetail_Module',
    N'CB.GIROCollectionDetail_ReceiptType',
    N'CB.GIROCollectionDetail_DebtorID',
    N'CB.GIROCollectionDetail_DebtorAccount',
    N'CB.GIROCollectionDetail_DebtorName',
    N'CB.GIROCollectionDetail_DocumentNo',
    N'CB.GIROCollectionDetail_DocumentDate',
    N'CB.GIROCollectionDetail_DueDate',
    N'CB.GIROCollectionDetail_DocumentDesc',
    N'CB.GIROCollectionDetail_CurrencyID',
    N'CB.GIROCollectionDetail_Currency',
    N'CB.GIROCollectionDetail_DocumentAmt',
    N'CB.GIROCollectionDetail_BalanceAmt',
    N'CB.GIROCollectionDetail_CollectAmt',
    N'Sys_Base_Name_CB.GIROCollectionGenerate',
    N'Sys_Base_Desc_CB.GIROCollectionGenerate',
    N'Sys_Base_Name_CB.GIROCollectionDetail',
    N'Sys_Base_Desc_CB.GIROCollectionDetail',
    N'Sys_List_Name_CB.GIROCollectionDetail_-1',
    N'Sys_List_Title_CB.GIROCollectionDetail_-1',
    N'Sys_List_Name_CB.GIROCollectionDetail_1',
    N'Sys_List_Title_CB.GIROCollectionDetail_1',
    N'Sys_Tab_Name_CB.GIROCollectionGenerate',
    N'TabClass_CB.GIROCollectionGenerate_GIRO0001',
    N'CB.GIRODetail_Title',
    N'MnuClass_CB.GIROCollectionGenerate',
    N'MnuClass_CB.GIRODetail',
    N'MnuClass_CB.GIROSelect',
    N'Cash-03-20_CB.GIROCollectionGenerate_Save',
    N'Cash-03-20_CB.GIROCollectionGenerate_Close',
    N'Cash-03-20_CB.GIRODetail_Select',
    N'Cash-03-20_CB.GIRODetail_Cancel',
    N'Cash-03-20_CB.GIROSelect_OK',
    N'Cash-03-20_CB.GIROSelect_Close',
    N'CB.GIRO_Title_Generate',
    N'CB.GIRO_Title_GenerateAll',
    N'CB.GIRO_NoDetail',
    N'CB.GIRO_PaymentDateRequired',
    N'CB.GIRO_PaymentDateMustNotPast',
    N'CB.GIRO_PayMethodRequired',
    N'CB.GIRO_ReferenceNoRequired',
    N'CB.GIRO_AllSummary',
    N'CB.GIRO_InvalidFilter',
    N'CB.GIRO_SaveSuccess',
    N'CB.GIRO_BillChanged',
    N'CB.GIRO_ModuleNotSupported',
    N'CB.GIRO_Title_Import',
    N'CB.GIROCollectionGenerate_ProcessingDate',
    N'CB.GIROCollectionGenerate_ModuleName',
    N'CB.GIRO_ModuleAll',
    N'CB.GIRO_ProcessingDateRequired');
END

-- field labels (Field + Help)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_ACNo', N'Account No.', N'Account No.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_ACNo', N'Account No.', N'Account No.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_BankName', N'Bank Name', N'Bank Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_BankName', N'Bank Name', N'Bank Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_PayMethodStringCode', N'Payment Method', N'Payment Method', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_PayMethodStringCode', N'Payment Method', N'Payment Method', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentDate', N'Payment Date', N'Payment Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_ReferenceNo', N'Reference No', N'Reference No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentCount', N'No. of Documents', N'No. of Documents', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentCount', N'No. of Documents', N'No. of Documents', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_TotalAmt', N'Total Amount', N'Total Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CBReceiptID', N'Receipt ID', N'Receipt ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_BankAccountID', N'Bank Account ID', N'Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_PayMethod', N'Pay Method ID', N'Pay Method ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_PayMethod', N'Pay Method ID', N'Pay Method ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_Module', N'Module Code', N'Module Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_Module', N'Module Code', N'Module Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentAmt', N'Amount', N'Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_DocumentAmt', N'Amount', N'Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionGenerate_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_GIRODetailID', N'Detail ID', N'Detail ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_GIRODetailID', N'Detail ID', N'Detail ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_GIROGuid', N'GUID', N'GUID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_GIROGuid', N'GUID', N'GUID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_BillID', N'Bill ID', N'Bill ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_BillID', N'Bill ID', N'Bill ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DueDate', N'Due Date', N'Due Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DueDate', N'Due Date', N'Due Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentDesc', N'Document Description', N'Document Description', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentDesc', N'Document Description', N'Document Description', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentAmt', N'Document Amount', N'Document Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_DocumentAmt', N'Document Amount', N'Document Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_BalanceAmt', N'Balance Amount', N'Balance Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_BalanceAmt', N'Balance Amount', N'Balance Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CollectAmt', N'Collect Amount', N'Collect Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollectionDetail_CollectAmt', N'Collect Amount', N'Collect Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- names / buttons: StringType + RefTable copied from the equivalent Generate Payment string
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROCollectionGenerate', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROCollectionGenerate', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Name_CB.GIROCollectionDetail', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROCollectionDetail', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROCollectionDetail_-1', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROCollectionDetail_-1', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Name_CB.GIROCollectionDetail_1', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_List_Title_CB.GIROCollectionDetail_1', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Sys_Tab_Name_CB.GIROCollectionGenerate', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Tab_Name_AC.PaymentConfirm' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'TabClass_CB.GIROCollectionGenerate_GIRO0001', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'TabClass_AC.PaymentConfirm_AC00073' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'CB.GIRODetail_Title', N'Invoice Detail', N'Invoice Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'AC.Pay_Title' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROCollectionGenerate', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIRODetail', N'GIRO Collection Detail', N'GIRO Collection Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'MnuClass_CB.GIROSelect', N'GIRO Collection Import', N'GIRO Collection Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIROCollectionGenerate_Save', N'Save', N'Save', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Save' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIROCollectionGenerate_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIRODetail_Select', N'Import', N'Import', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.Pay_Select' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIRODetail_Cancel', N'Remove', N'Remove', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.Pay_Cancel' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIROSelect_OK', N'OK', N'OK', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Save' ORDER BY [StringType];

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT TOP 1 [StringType], [RefTable], N'Cash-03-20_CB.GIROSelect_Close', N'Close', N'Close', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-04_AC.PayConfirm.Edit_Close' ORDER BY [StringType];

-- messages used in code (Strings.GetString)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_Title_Generate', N'GIRO Collection Generation', N'GIRO Collection Generation', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_Title_GenerateAll', N'Generate All', N'Generate All', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_NoDetail', N'Please select at least one document.', N'Please select at least one document.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_PaymentDateRequired', N'Payment Date is required.', N'Payment Date is required.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_PaymentDateMustNotPast', N'Payment Date must be today or later.', N'Payment Date must be today or later.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_PayMethodRequired', N'Payment Method GIRO is not set up (Pay Method list).', N'Payment Method GIRO is not set up (Pay Method list).', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_ReferenceNoRequired', N'Reference No is required.', N'Reference No is required.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_AllSummary', N'{0} document(s) of the current listing filter will be collected, total amount {1}.', N'{0} document(s) of the current listing filter will be collected, total amount {1}.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_InvalidFilter', N'Invalid search criteria. Please search again on the listing.', N'Invalid search criteria. Please search again on the listing.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_SaveSuccess', N'{0} receipt(s) created for {1} document(s), total amount {2}.', N'{0} receipt(s) created for {1} document(s), total amount {2}.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_BillChanged', N'These documents are no longer outstanding or were changed by another user. Please reload and try again:', N'These documents are no longer outstanding or were changed by another user. Please reload and try again:', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_ModuleNotSupported', N'GIRO collection for module {0} is not supported yet.', N'GIRO collection for module {0} is not supported yet.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Common', NULL, N'CB.GIRO_Title_Import', N'Import Outstanding Documents', N'Import Outstanding Documents', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- Check
SELECT N'Sys_Base' AS Tbl, COUNT(*) AS Cnt FROM Sys_Base WHERE BseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail')
UNION ALL SELECT N'Sys_BaseDt', COUNT(*) FROM Sys_BaseDt WHERE BdtBseNo IN (N'CB.GIROCollectionGenerate', N'CB.GIROCollectionDetail')
UNION ALL SELECT N'Sys_Tab', COUNT(*) FROM Sys_Tab WHERE TabNo = N'CB.GIROCollectionGenerate'
UNION ALL SELECT N'Sys_TabClass', COUNT(*) FROM Sys_TabClass WHERE TcsTabNo = N'CB.GIROCollectionGenerate'
UNION ALL SELECT N'Sys_TabDt', COUNT(*) FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROCollectionGenerate'
UNION ALL SELECT N'Sys_TabCard', COUNT(*) FROM Sys_TabCard WHERE TcdTabNo = N'CB.GIROCollectionGen'
UNION ALL SELECT N'Sys_List', COUNT(*) FROM Sys_List WHERE LstNo = N'CB.GIROCollectionDetail'
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROCollectionDetail'
UNION ALL SELECT N'Sys_ContextMenuClass', COUNT(*) FROM Sys_ContextMenuClass WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect')
UNION ALL SELECT N'Sys_ContextMenu', COUNT(*) FROM Sys_ContextMenu WHERE MnuClass IN (N'CB.GIROCollectionGenerate', N'CB.GIRODetail', N'CB.GIROSelect') AND MnuNo = N'Cash-03-20'
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (
    N'CB.GIROCollectionGenerate_ACNo',
    N'CB.GIROCollectionGenerate_BankName',
    N'CB.GIROCollectionGenerate_Currency',
    N'CB.GIROCollectionGenerate_PayMethodStringCode',
    N'CB.GIROCollectionGenerate_DocumentDate',
    N'CB.GIROCollectionGenerate_ReferenceNo',
    N'CB.GIROCollectionGenerate_DocumentCount',
    N'CB.GIROCollectionGenerate_TotalAmt',
    N'CB.GIROCollectionGenerate_CBReceiptID',
    N'CB.GIROCollectionGenerate_CompanyID',
    N'CB.GIROCollectionGenerate_BankAccountID',
    N'CB.GIROCollectionGenerate_CurrencyID',
    N'CB.GIROCollectionGenerate_PayMethod',
    N'CB.GIROCollectionGenerate_Module',
    N'CB.GIROCollectionGenerate_DocumentAmt',
    N'CB.GIROCollectionGenerate_RecordStatus',
    N'CB.GIROCollectionDetail_GIRODetailID',
    N'CB.GIROCollectionDetail_GIROGuid',
    N'CB.GIROCollectionDetail_BillID',
    N'CB.GIROCollectionDetail_CompanyID',
    N'CB.GIROCollectionDetail_Module',
    N'CB.GIROCollectionDetail_ReceiptType',
    N'CB.GIROCollectionDetail_DebtorID',
    N'CB.GIROCollectionDetail_DebtorAccount',
    N'CB.GIROCollectionDetail_DebtorName',
    N'CB.GIROCollectionDetail_DocumentNo',
    N'CB.GIROCollectionDetail_DocumentDate',
    N'CB.GIROCollectionDetail_DueDate',
    N'CB.GIROCollectionDetail_DocumentDesc',
    N'CB.GIROCollectionDetail_CurrencyID',
    N'CB.GIROCollectionDetail_Currency',
    N'CB.GIROCollectionDetail_DocumentAmt',
    N'CB.GIROCollectionDetail_BalanceAmt',
    N'CB.GIROCollectionDetail_CollectAmt',
    N'Sys_Base_Name_CB.GIROCollectionGenerate',
    N'Sys_Base_Desc_CB.GIROCollectionGenerate',
    N'Sys_Base_Name_CB.GIROCollectionDetail',
    N'Sys_Base_Desc_CB.GIROCollectionDetail',
    N'Sys_List_Name_CB.GIROCollectionDetail_-1',
    N'Sys_List_Title_CB.GIROCollectionDetail_-1',
    N'Sys_List_Name_CB.GIROCollectionDetail_1',
    N'Sys_List_Title_CB.GIROCollectionDetail_1',
    N'Sys_Tab_Name_CB.GIROCollectionGenerate',
    N'TabClass_CB.GIROCollectionGenerate_GIRO0001',
    N'CB.GIRODetail_Title',
    N'MnuClass_CB.GIROCollectionGenerate',
    N'MnuClass_CB.GIRODetail',
    N'MnuClass_CB.GIROSelect',
    N'Cash-03-20_CB.GIROCollectionGenerate_Save',
    N'Cash-03-20_CB.GIROCollectionGenerate_Close',
    N'Cash-03-20_CB.GIRODetail_Select',
    N'Cash-03-20_CB.GIRODetail_Cancel',
    N'Cash-03-20_CB.GIROSelect_OK',
    N'Cash-03-20_CB.GIROSelect_Close',
    N'CB.GIRO_Title_Generate',
    N'CB.GIRO_Title_GenerateAll',
    N'CB.GIRO_NoDetail',
    N'CB.GIRO_PaymentDateRequired',
    N'CB.GIRO_PaymentDateMustNotPast',
    N'CB.GIRO_PayMethodRequired',
    N'CB.GIRO_ReferenceNoRequired',
    N'CB.GIRO_AllSummary',
    N'CB.GIRO_InvalidFilter',
    N'CB.GIRO_SaveSuccess',
    N'CB.GIRO_BillChanged',
    N'CB.GIRO_ModuleNotSupported',
    N'CB.GIRO_Title_Import',
    N'CB.GIROCollectionGenerate_ProcessingDate',
    N'CB.GIROCollectionGenerate_ModuleName',
    N'CB.GIRO_ModuleAll',
    N'CB.GIRO_ProcessingDateRequired');
-- expected: Sys_Base 2, Sys_BaseDt 34, Sys_Tab 1, Sys_TabClass 1, Sys_TabDt 8, Sys_TabCard 1, Sys_List 2, Sys_ListDt 22, Sys_ContextMenuClass 3, Sys_ContextMenu 6, CF_String 101
