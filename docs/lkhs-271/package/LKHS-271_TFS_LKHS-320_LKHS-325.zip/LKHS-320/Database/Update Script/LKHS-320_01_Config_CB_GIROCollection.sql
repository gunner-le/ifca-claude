-----------------------------------------------------------------------------------------
-- LKHS-271 - Generate GIRO Collection
-- Script 02: Sys_ framework config + menu + strings
--   BseNo / LstNo / MnuClass : CB.GIROCollection
--   MnuNo                    : Cash-03-20 (Cash Management > Receipt)
-- Re-runnable: each block deletes existing rows then inserts again.
-- Run order: see RUN_ORDER.txt
-----------------------------------------------------------------------------------------

-- Sys_Base
IF EXISTS (SELECT TOP 1 1 FROM Sys_Base WITH (NOLOCK) WHERE BseNo = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_Base WHERE BseNo = N'CB.GIROCollection';
END

INSERT INTO Sys_Base ([BseClass], [BseNo], [BseName], [BseNameStringCode], [BseReadTable], [BseWriteTable], [BseDesc], [BseDescStringCode], [BseIdField], [BseQryType], [BseMenu], [BseDefine])
VALUES (NULL, N'CB.GIROCollection', N'Generate GIRO Collection', N'Sys_Base_Name_CB.GIROCollection', N'View_CB_GIROCollectionPending', N'AR_Trx', N'Generate GIRO Collection', N'Sys_Base_Desc_CB.GIROCollection', N'BillID', NULL, NULL, NULL);

-- Sys_BaseDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_BaseDt WITH (NOLOCK) WHERE BdtBseNo = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_BaseDt WHERE BdtBseNo = N'CB.GIROCollection';
END

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'BillID', N'Bill ID', N'Bill ID', N'CB.GIROCollection_BillID', N'CB.GIROCollection_BillID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 1, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'CompanyID', N'Company ID', N'Company ID', N'CB.GIROCollection_CompanyID', N'CB.GIROCollection_CompanyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 2, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'Module', N'Module', N'Module', N'CB.GIROCollection_Module', N'CB.GIROCollection_Module', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 3, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DebtorID', N'Debtor ID', N'Debtor ID', N'CB.GIROCollection_DebtorID', N'CB.GIROCollection_DebtorID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 4, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DebtorAccount', N'Debtor Account', N'Debtor Account', N'CB.GIROCollection_DebtorAccount', N'CB.GIROCollection_DebtorAccount', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 5, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DebtorName', N'Debtor Name', N'Debtor Name', N'CB.GIROCollection_DebtorName', N'CB.GIROCollection_DebtorName', 200, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 6, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DocumentNo', N'Document No', N'Document No', N'CB.GIROCollection_DocumentNo', N'CB.GIROCollection_DocumentNo', 60, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 7, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DocumentDate', N'Document Date', N'Document Date', N'CB.GIROCollection_DocumentDate', N'CB.GIROCollection_DocumentDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 8, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DueDate', N'Due Date', N'Due Date', N'CB.GIROCollection_DueDate', N'CB.GIROCollection_DueDate', 8, N'D', 80, N'center', NULL, N'1', NULL, N'1', N'1', NULL, 9, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DocumentDesc', N'Document Description', N'Document Description', N'CB.GIROCollection_DocumentDesc', N'CB.GIROCollection_DocumentDesc', 500, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 10, NULL, N'1', NULL, NULL, N'0', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'CurrencyID', N'Currency ID', N'Currency ID', N'CB.GIROCollection_CurrencyID', N'CB.GIROCollection_CurrencyID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 11, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'Currency', N'Currency', N'Currency', N'CB.GIROCollection_Currency', N'CB.GIROCollection_Currency', 40, N'L2', 80, N'left', NULL, N'1', NULL, N'1', N'1', NULL, 12, NULL, N'1', NULL, NULL, N'2', NULL, NULL, NULL, NULL, NULL, 150, N'CurrencyID', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'DocumentAmt', N'Document Amount', N'Document Amount', N'CB.GIROCollection_DocumentAmt', N'CB.GIROCollection_DocumentAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 13, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'BalanceAmt', N'Balance Amount', N'Balance Amount', N'CB.GIROCollection_BalanceAmt', N'CB.GIROCollection_BalanceAmt', 13, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'1', NULL, 14, NULL, N'1', NULL, NULL, N'1', NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 2, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'GIROBankAccountID', N'GIRO Bank Account ID', N'GIRO Bank Account ID', N'CB.GIROCollection_GIROBankAccountID', N'CB.GIROCollection_GIROBankAccountID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 15, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'GiroBankSwiftCodeID', N'GIRO Bank SWIFT Code', N'GIRO Bank SWIFT Code', N'CB.GIROCollection_GiroBankSwiftCodeID', N'CB.GIROCollection_GiroBankSwiftCodeID', 4, N'I', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 17, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'GiroAccountNo', N'GIRO Account No', N'GIRO Account No', N'CB.GIROCollection_GiroAccountNo', N'CB.GIROCollection_GiroAccountNo', 35, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 18, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'IsDispute', N'Is Dispute', N'Is Dispute', N'CB.GIROCollection_IsDispute', N'CB.GIROCollection_IsDispute', 1, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 19, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'RefTable', N'Ref Table', N'Ref Table', N'CB.GIROCollection_RefTable', N'CB.GIROCollection_RefTable', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 20, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'RecordStatus', N'Status', N'Status', N'CB.GIROCollection_RecordStatus', N'CB.GIROCollection_RecordStatus', 10, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 21, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'ReceiptType', N'Receipt Type', N'Receipt Type', N'CB.GIROCollection_ReceiptType', N'CB.GIROCollection_ReceiptType', 20, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 22, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'TrxExchangeRate', N'Bill Exchange Rate', N'Bill Exchange Rate', N'CB.GIROCollection_TrxExchangeRate', N'CB.GIROCollection_TrxExchangeRate', 15, N'FM', 80, N'right', NULL, N'1', NULL, N'1', N'0', NULL, 23, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 8, N'N', N'N');

INSERT INTO Sys_BaseDt ([BdtBseNo], [BdtFldName], [BdtFldDesc], [BdtFldDescEN], [BdtFldDescStringCode], [BdtFldHelpStringCode], [BdtFldMaxLen], [BdtFldType], [BdtFldWidth], [BdtFldAlign], [BdtFldVAlign], [BdtLstDefault], [BdtLstNeed], [BdtLstEdit], [BdtLstDisplay], [BdtPrnDefault], [BdtFldOrder], [BdtFldList], [BdtTabDisplay], [BdtTabSave], [BdtFormula], [BdtFilter], [BdtTabChg], [BdtTabDefault], [BdtTabSelect], [BdtPrivilege], [BdtFldKind], [BdtTabWidth], [BdtRelationName], [BdtTabColSpan], [BdtFldBEmpty], [BdtFldUEmpty], [BdtFldRange], [BdtSelNo], [BdtWriteTable], [BdtWriteField], [BdtDecimalPlace], [BdtIsCurrentDate], [BdtIsNegativeAllow])
VALUES (N'CB.GIROCollection', N'ItemCode', N'Item Code', N'Item Code', N'CB.GIROCollection_ItemCode', N'CB.GIROCollection_ItemCode', 50, N'S', 80, N'left', NULL, N'1', NULL, N'1', N'0', NULL, 24, NULL, N'1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'N', N'N');


-- Sys_List
IF EXISTS (SELECT TOP 1 1 FROM Sys_List WITH (NOLOCK) WHERE LstNo = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_List WHERE LstNo = N'CB.GIROCollection';
END

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROCollection', -1, N'Generate GIRO Collection', N'Sys_List_Name_CB.GIROCollection_-1', N'Generate GIRO Collection', N'Sys_List_Title_CB.GIROCollection_-1', N'CB.GIROCollection', NULL, NULL, NULL, NULL, N'N', NULL, NULL, NULL, NULL);

INSERT INTO Sys_List ([LstNo], [LstOrder], [LstName], [LstNameStringCode], [LstTitle], [LstTitleStringCode], [LstBseNo], [LstSort], [LstFilter], [LstFilterDesc], [LstStat], [LstDefault], [LstUseId], [LstRange], [LstFront], [LstPage])
VALUES (N'CB.GIROCollection', 1, N'Generate GIRO Collection', N'Sys_List_Name_CB.GIROCollection_1', N'Generate GIRO Collection', N'Sys_List_Title_CB.GIROCollection_1', N'CB.GIROCollection', NULL, NULL, NULL, NULL, N'Y', NULL, 0, NULL, NULL);


-- Sys_ListDt
IF EXISTS (SELECT TOP 1 1 FROM Sys_ListDt WITH (NOLOCK) WHERE LdtLstNo = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROCollection';
END

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'BillID', N'Bill ID', NULL, N'CB.GIROCollection_BillID', N'CB.GIROCollection_BillID', 4, 40, N'right', NULL, N'I', N'1', 1, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'Module', N'Module', NULL, N'CB.GIROCollection_Module', N'CB.GIROCollection_Module', 50, 120, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROCollection_DebtorAccount', N'CB.GIROCollection_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROCollection_DebtorName', N'CB.GIROCollection_DebtorName', 200, 200, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DocumentNo', N'Document No', NULL, N'CB.GIROCollection_DocumentNo', N'CB.GIROCollection_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROCollection_DocumentDate', N'CB.GIROCollection_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DueDate', N'Due Date', NULL, N'CB.GIROCollection_DueDate', N'CB.GIROCollection_DueDate', 8, 80, N'center', NULL, N'D', N'1', 7, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DocumentDesc', N'Document Description', NULL, N'CB.GIROCollection_DocumentDesc', N'CB.GIROCollection_DocumentDesc', 500, 250, N'left', NULL, N'S', N'1', 8, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'Currency', N'Currency', NULL, N'CB.GIROCollection_Currency', N'CB.GIROCollection_Currency', 40, 50, N'left', NULL, N'L2', N'1', 9, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'DocumentAmt', N'Document Amount', NULL, N'CB.GIROCollection_DocumentAmt', N'CB.GIROCollection_DocumentAmt', 13, 90, N'right', NULL, N'FM', N'1', 10, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', -1, N'BalanceAmt', N'Balance Amount', NULL, N'CB.GIROCollection_BalanceAmt', N'CB.GIROCollection_BalanceAmt', 13, 90, N'right', NULL, N'FM', N'1', 11, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'BillID', N'Bill ID', NULL, N'CB.GIROCollection_BillID', N'CB.GIROCollection_BillID', 4, 40, N'right', NULL, N'I', N'1', 1, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'Module', N'Module', NULL, N'CB.GIROCollection_Module', N'CB.GIROCollection_Module', 50, 120, N'left', NULL, N'S', N'1', 2, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DebtorAccount', N'Debtor Account', NULL, N'CB.GIROCollection_DebtorAccount', N'CB.GIROCollection_DebtorAccount', 50, 150, N'left', NULL, N'S', N'1', 3, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DebtorName', N'Debtor Name', NULL, N'CB.GIROCollection_DebtorName', N'CB.GIROCollection_DebtorName', 200, 200, N'left', NULL, N'S', N'1', 4, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DocumentNo', N'Document No', NULL, N'CB.GIROCollection_DocumentNo', N'CB.GIROCollection_DocumentNo', 60, 130, N'left', NULL, N'S', N'1', 5, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DocumentDate', N'Document Date', NULL, N'CB.GIROCollection_DocumentDate', N'CB.GIROCollection_DocumentDate', 8, 80, N'center', NULL, N'D', N'1', 6, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DueDate', N'Due Date', NULL, N'CB.GIROCollection_DueDate', N'CB.GIROCollection_DueDate', 8, 80, N'center', NULL, N'D', N'1', 7, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DocumentDesc', N'Document Description', NULL, N'CB.GIROCollection_DocumentDesc', N'CB.GIROCollection_DocumentDesc', 500, 250, N'left', NULL, N'S', N'1', 8, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'Currency', N'Currency', NULL, N'CB.GIROCollection_Currency', N'CB.GIROCollection_Currency', 40, 50, N'left', NULL, N'L2', N'1', 9, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'DocumentAmt', N'Document Amount', NULL, N'CB.GIROCollection_DocumentAmt', N'CB.GIROCollection_DocumentAmt', 13, 90, N'right', NULL, N'FM', N'1', 10, N'1', NULL, NULL, NULL);

INSERT INTO Sys_ListDt ([LdtLstNo], [LdtLstOrder], [LdtFldName], [LdtFldDesc], [LdtFldDescEN], [LdtFldDescStringCode], [LdtFldHelpStringCode], [LdtFldMaxLen], [LdtFldWidth], [LdtFldAlign], [LdtFldVAlign], [LdtFldType], [LdtFldEdit], [LdtFldOrder], [LdtFldDisplay], [LdtStatMode], [LdtFixHeaderStringCode], [LdtFixHeaderSeq])
VALUES (N'CB.GIROCollection', 1, N'BalanceAmt', N'Balance Amount', NULL, N'CB.GIROCollection_BalanceAmt', N'CB.GIROCollection_BalanceAmt', 13, 90, N'right', NULL, N'FM', N'1', 11, N'1', NULL, NULL, NULL);


-- Sys_Filter (search fields above the list)
IF EXISTS (SELECT TOP 1 1 FROM Sys_Filter WITH (NOLOCK) WHERE FltBseNo = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_Filter WHERE FltBseNo = N'CB.GIROCollection';
END

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 1, 0, N'Module');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 2, 0, N'DebtorAccount');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 3, 0, N'DebtorName');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 4, 0, N'DocumentNo');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'D', NULL, 0, 1, NULL, NULL, 1, NULL, 5, 0, N'DocumentDate');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'D', NULL, 0, 1, NULL, NULL, 1, NULL, 6, 0, N'DueDate');

INSERT INTO Sys_Filter ([FltBseNo], [FltLstNo], [FltTitle], [FltType], [FltPrecision], [FltDisMode], [FltRange], [FltBIncNullText], [FltBIncNullvalue], [FltEIncNullText], [FltEIncNullvalue], [FltOrder], [FltNewline], [FltName])
VALUES (N'CB.GIROCollection', N'CB.GIROCollection', NULL, N'S', NULL, 0, 0, NULL, NULL, 1, NULL, 7, 0, N'DocumentDesc');


-- Sys_ContextMenuClass (register the button class)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenuClass WITH (NOLOCK) WHERE MnuClass = N'CB.GIROCollection')
BEGIN
    DELETE FROM Sys_ContextMenuClass WHERE MnuClass = N'CB.GIROCollection';
END

INSERT INTO Sys_ContextMenuClass ([MnuClass], [DescriptionStringCode])
VALUES (N'CB.GIROCollection', N'MnuClass_CB.GIROCollection');


-- Sys_ContextMenu (toolbar buttons -> JS functions in ARGIROCollectionLst.aspx)
IF EXISTS (SELECT TOP 1 1 FROM Sys_ContextMenu WITH (NOLOCK) WHERE MnuClass = N'CB.GIROCollection' AND MnuNo = N'Cash-03-20')
BEGIN
    DELETE FROM Sys_ContextMenu WHERE MnuClass = N'CB.GIROCollection' AND MnuNo = N'Cash-03-20';
END

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'GenerateAll', N'CB.GIROCollection', N'Cash-03-20', N'Cash-03-20_CB.GIROCollection_GenerateAll', N'f_GIROGenerateAll()', NULL, 1, N'N', N'Y', NULL, NULL, 1);

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'Generate', N'CB.GIROCollection', N'Cash-03-20', N'Cash-03-20_CB.GIROCollection_Generate', N'f_GIROGenerate()', NULL, 1, N'N', N'Y', NULL, NULL, 2);

INSERT INTO Sys_ContextMenu ([ContextMnuNo], [MnuClass], [MnuNo], [MnuStringCode], [MnuScript], [InitStatus], [CausesValidation], [IsInDropDown], [IsNeedPrivilege], [ImageName], [ParentID], [SeqNo])
VALUES (N'View', N'CB.GIROCollection', N'Cash-03-20', N'Cash-03-20_CB.GIROCollection_View', N'f_View()', NULL, 1, N'N', N'Y', NULL, NULL, 3);


-- Sys_Menu: Cash Management > Payment > Generate GIRO Collection
-- Copied from Collection menu (mcorp-15-08): same parent (Cash-03), MnuSystem, MnuType, IntegrityCheck...
IF EXISTS (SELECT TOP 1 1 FROM Sys_Menu WITH (NOLOCK) WHERE MnuNo = N'Cash-03-20')
BEGIN
    DELETE FROM Sys_Menu WHERE MnuNo = N'Cash-03-20';
END

INSERT INTO Sys_Menu ([MnuSystem], [MnuType], [MnuOrder], [MnuNo], [MnuName], [MnuNameEN], [MnuBaseNameStringCode], [MnuNameStringCode], [MnuProgram], [MnuPic], [MnuParentNo], [MnuFunNo], [MnuMduNo], [MnuDesc], [MnuEdition], [MnuClass], [MnuClsOrder], [IsVisible], [IntegrityCheck], [RecordStatus], [IsLeaf], [IsHideMenu])
SELECT [MnuSystem], [MnuType], 7, N'Cash-03-20', N'Generate GIRO Collection', N'Generate GIRO Collection', N'Cash-03-20_Base', N'Cash-03-20', N'/CashFlow/ARGIROCollection.aspx?MnuNo=Cash-03-20', [MnuPic], N'Cash-03', [MnuFunNo], [MnuMduNo], N'Generate GIRO Collection', [MnuEdition], [MnuClass], [MnuClsOrder], N'Y', [IntegrityCheck], N'Active', N'Y', [IsHideMenu]
FROM Sys_Menu WITH (NOLOCK)
WHERE MnuNo = N'mcorp-15-08';


-- Sys_Tab / Sys_TabClass / Sys_TabDt : read-only View form (base CB.GIROCollection)
IF EXISTS (SELECT TOP 1 1 FROM Sys_Tab WITH (NOLOCK) WHERE TabNo = N'CB.GIROCollectionView')
BEGIN
    DELETE FROM Sys_Tab WHERE TabNo = N'CB.GIROCollectionView';
END
INSERT INTO Sys_Tab ([TabNo], [TabName], [TabBseNo], [TabNameStringCode])
VALUES (N'CB.GIROCollectionView', N'GIRO View', N'CB.GIROCollection', N'Sys_Tab_Name_CB.GIROCollectionView');   -- TabName nvarchar(20)

IF EXISTS (SELECT TOP 1 1 FROM Sys_TabClass WITH (NOLOCK) WHERE TcsTabNo = N'CB.GIROCollectionView')
BEGIN
    DELETE FROM Sys_TabClass WHERE TcsTabNo = N'CB.GIROCollectionView';
END
INSERT INTO Sys_TabClass ([TcsTabNo], [TcsNo], [TcsName], [TcsNameEN], [TcsNameStringCode], [TcsClass], [TcsListNum])
VALUES (N'CB.GIROCollectionView', N'GIROV001', N'Document Detail', N'Document Detail', N'TabClass_CB.GIROCollectionView_GIROV001', NULL, 2);

IF EXISTS (SELECT TOP 1 1 FROM Sys_TabDt WITH (NOLOCK) WHERE TdtTabNo = N'CB.GIROCollectionView')
BEGIN
    DELETE FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROCollectionView';
END

INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'Module', N'Module', N'CB.GIROCollection_Module', N'CB.GIROCollection_Module', NULL, 1, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DebtorAccount', N'Debtor Account', N'CB.GIROCollection_DebtorAccount', N'CB.GIROCollection_DebtorAccount', NULL, 2, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DebtorName', N'Debtor Name', N'CB.GIROCollection_DebtorName', N'CB.GIROCollection_DebtorName', NULL, 3, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DocumentNo', N'Document No', N'CB.GIROCollection_DocumentNo', N'CB.GIROCollection_DocumentNo', NULL, 4, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DocumentDate', N'Document Date', N'CB.GIROCollection_DocumentDate', N'CB.GIROCollection_DocumentDate', NULL, 5, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DueDate', N'Due Date', N'CB.GIROCollection_DueDate', N'CB.GIROCollection_DueDate', NULL, 6, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'Currency', N'Currency', N'CB.GIROCollection_Currency', N'CB.GIROCollection_Currency', NULL, 7, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DocumentDesc', N'Document Description', N'CB.GIROCollection_DocumentDesc', N'CB.GIROCollection_DocumentDesc', NULL, 8, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'DocumentAmt', N'Document Amount', N'CB.GIROCollection_DocumentAmt', N'CB.GIROCollection_DocumentAmt', NULL, 9, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'BalanceAmt', N'Balance Amount', N'CB.GIROCollection_BalanceAmt', N'CB.GIROCollection_BalanceAmt', NULL, 10, NULL, NULL, NULL, NULL);
INSERT INTO Sys_TabDt ([TdtBseNo], [TdtTabNo], [TdtTcsNo], [TdtFldName], [TdtFldDesc], [TdtFldDescStringCode], [TdtFldHelpStringCode], [TdtFldEdit], [TdtFldOrder], [TdtListType], [TdtIsHidden], [TdtIsNewLine], [TdtIsMergeNextField])
VALUES (N'CB.GIROCollection', N'CB.GIROCollectionView', N'GIROV001', N'GiroAccountNo', N'GIRO Account No', N'CB.GIROCollection_GiroAccountNo', N'CB.GIROCollection_GiroAccountNo', NULL, 11, NULL, NULL, NULL, NULL);

-- CF_String
IF EXISTS (SELECT TOP 1 1 FROM CF_String WITH (NOLOCK) WHERE StringCode IN (
    N'CB.GIROCollection_BillID',
    N'CB.GIROCollection_CompanyID',
    N'CB.GIROCollection_Module',
    N'CB.GIROCollection_DebtorID',
    N'CB.GIROCollection_DebtorAccount',
    N'CB.GIROCollection_DebtorName',
    N'CB.GIROCollection_DocumentNo',
    N'CB.GIROCollection_DocumentDate',
    N'CB.GIROCollection_DueDate',
    N'CB.GIROCollection_DocumentDesc',
    N'CB.GIROCollection_CurrencyID',
    N'CB.GIROCollection_Currency',
    N'CB.GIROCollection_DocumentAmt',
    N'CB.GIROCollection_BalanceAmt',
    N'CB.GIROCollection_GIROBankAccountID',
    N'CB.GIROCollection_GiroBankSwiftCodeID',
    N'CB.GIROCollection_GiroAccountNo',
    N'CB.GIROCollection_IsDispute',
    N'CB.GIROCollection_RefTable',
    N'CB.GIROCollection_RecordStatus',
    N'CB.GIROCollection_ReceiptType',
    N'CB.GIROCollection_TrxExchangeRate',
    N'CB.GIROCollection_ItemCode',
    N'Cash-03-20',
    N'Sys_Base_Name_CB.GIROCollection',
    N'Sys_Base_Desc_CB.GIROCollection',
    N'Sys_List_Name_CB.GIROCollection_-1',
    N'Sys_List_Title_CB.GIROCollection_-1',
    N'Sys_List_Name_CB.GIROCollection_1',
    N'Sys_List_Title_CB.GIROCollection_1',
    N'Cash-03-20_CB.GIROCollection_GenerateAll',
    N'Cash-03-20_CB.GIROCollection_Generate',
    N'Cash-03-20_CB.GIROCollection_View',
    N'CB.GIROCollection_Title',
    N'CB.GIRO_NotGIROBank',
    N'MnuClass_CB.GIROCollection',
    N'Sys_Tab_Name_CB.GIROCollectionView',
    N'TabClass_CB.GIROCollectionView_GIROV001',
    N'Cash-03-20_Base'))
BEGIN
    DELETE FROM CF_String WHERE StringCode IN (
    N'CB.GIROCollection_BillID',
    N'CB.GIROCollection_CompanyID',
    N'CB.GIROCollection_Module',
    N'CB.GIROCollection_DebtorID',
    N'CB.GIROCollection_DebtorAccount',
    N'CB.GIROCollection_DebtorName',
    N'CB.GIROCollection_DocumentNo',
    N'CB.GIROCollection_DocumentDate',
    N'CB.GIROCollection_DueDate',
    N'CB.GIROCollection_DocumentDesc',
    N'CB.GIROCollection_CurrencyID',
    N'CB.GIROCollection_Currency',
    N'CB.GIROCollection_DocumentAmt',
    N'CB.GIROCollection_BalanceAmt',
    N'CB.GIROCollection_GIROBankAccountID',
    N'CB.GIROCollection_GiroBankSwiftCodeID',
    N'CB.GIROCollection_GiroAccountNo',
    N'CB.GIROCollection_IsDispute',
    N'CB.GIROCollection_RefTable',
    N'CB.GIROCollection_RecordStatus',
    N'CB.GIROCollection_ReceiptType',
    N'CB.GIROCollection_TrxExchangeRate',
    N'CB.GIROCollection_ItemCode',
    N'Cash-03-20',
    N'Sys_Base_Name_CB.GIROCollection',
    N'Sys_Base_Desc_CB.GIROCollection',
    N'Sys_List_Name_CB.GIROCollection_-1',
    N'Sys_List_Title_CB.GIROCollection_-1',
    N'Sys_List_Name_CB.GIROCollection_1',
    N'Sys_List_Title_CB.GIROCollection_1',
    N'Cash-03-20_CB.GIROCollection_GenerateAll',
    N'Cash-03-20_CB.GIROCollection_Generate',
    N'Cash-03-20_CB.GIROCollection_View',
    N'CB.GIROCollection_Title',
    N'CB.GIRO_NotGIROBank',
    N'MnuClass_CB.GIROCollection',
    N'Sys_Tab_Name_CB.GIROCollectionView',
    N'TabClass_CB.GIROCollectionView_GIROV001',
    N'Cash-03-20_Base');
END
-- obsolete labels (AR_Debtor.GiroBankSwiftCode renamed to GiroBankSwiftCodeID, GiroInterfaceBank removed)
DELETE FROM CF_String WHERE StringCode IN (N'CB.GIROCollection_GiroBankSwiftCode', N'CB.GIROCollection_GiroInterfaceBank');

-- field labels (Field + Help, same as Bank SWIFT Code / DBS Purpose Code scripts)
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_BillID', N'Bill ID', N'Bill ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_BillID', N'Bill ID', N'Bill ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_CompanyID', N'Company ID', N'Company ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_Module', N'Module', N'Module', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DebtorID', N'Debtor ID', N'Debtor ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DebtorAccount', N'Debtor Account', N'Debtor Account', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DebtorName', N'Debtor Name', N'Debtor Name', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DocumentNo', N'Document No', N'Document No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DocumentDate', N'Document Date', N'Document Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DueDate', N'Due Date', N'Due Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DueDate', N'Due Date', N'Due Date', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DocumentDesc', N'Document Description', N'Document Description', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DocumentDesc', N'Document Description', N'Document Description', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_CurrencyID', N'Currency ID', N'Currency ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_Currency', N'Currency', N'Currency', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_DocumentAmt', N'Document Amount', N'Document Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_DocumentAmt', N'Document Amount', N'Document Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_BalanceAmt', N'Balance Amount', N'Balance Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_BalanceAmt', N'Balance Amount', N'Balance Amount', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_GIROBankAccountID', N'GIRO Bank Account ID', N'GIRO Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_GIROBankAccountID', N'GIRO Bank Account ID', N'GIRO Bank Account ID', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_GiroBankSwiftCodeID', N'GIRO Bank SWIFT Code', N'GIRO Bank SWIFT Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_GiroBankSwiftCodeID', N'GIRO Bank SWIFT Code', N'GIRO Bank SWIFT Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_GiroAccountNo', N'GIRO Account No', N'GIRO Account No', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_IsDispute', N'Is Dispute', N'Is Dispute', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_IsDispute', N'Is Dispute', N'Is Dispute', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_RefTable', N'Ref Table', N'Ref Table', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_RefTable', N'Ref Table', N'Ref Table', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_RecordStatus', N'Status', N'Status', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_ReceiptType', N'Receipt Type', N'Receipt Type', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_TrxExchangeRate', N'Bill Exchange Rate', N'Bill Exchange Rate', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_TrxExchangeRate', N'Bill Exchange Rate', N'Bill Exchange Rate', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Field', N'Sys_BaseDt', N'CB.GIROCollection_ItemCode', N'Item Code', N'Item Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
VALUES (N'Help', N'Sys_BaseDt', N'CB.GIROCollection_ItemCode', N'Item Code', N'Item Code', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE());

-- other labels: StringType / RefTable taken from the equivalent existing string (template)
-- so the same kind of string is created on every environment
INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Cash-03-20', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-08';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_Base_Name_CB.GIROCollection', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_Base_Desc_CB.GIROCollection', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Desc_AC.Payable';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_List_Name_CB.GIROCollection_-1', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_-1';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_List_Title_CB.GIROCollection_-1', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_-1';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_List_Name_CB.GIROCollection_1', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Name_AC.Payable_1';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_List_Title_CB.GIROCollection_1', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_List_Title_AC.Payable_1';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Cash-03-20_CB.GIROCollection_GenerateAll', N'Generate All', N'Generate All', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-09_AC.Payable_PaymentAuto';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Cash-03-20_CB.GIROCollection_Generate', N'Generate', N'Generate', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-09_AC.Payable_PaymentAuto';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Cash-03-20_CB.GIROCollection_View', N'View', N'View', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'mcorp-15-09_AC.Payable_View';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'CB.GIROCollection_Title', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Base_Name_AC.Payable';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'CB.GIRO_NotGIROBank', N'The selected bank account is not the company AR GIRO bank.', N'The selected bank account is not the company AR GIRO bank.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MustSelectBankAccount';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'MnuClass_CB.GIROCollection', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'MnuClass_AC.Payable';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'Sys_Tab_Name_CB.GIROCollectionView', N'GIRO Collection - View', N'GIRO Collection - View', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'Sys_Tab_Name_AC.PaymentConfirm';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT [StringType], [RefTable], N'TabClass_CB.GIROCollectionView_GIROV001', N'Document Detail', N'Document Detail', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM CF_String WITH (NOLOCK) WHERE StringCode = N'TabClass_AC.PaymentConfirm_AC00073';

INSERT INTO CF_String ([StringType], [RefTable], [StringCode], [StringCN], [StringEN], [StringSP], [StringJP], [StringKR], [StringTH], [StringMY], [StringFR], [StringGM], [StringENGB], [StringCNT], [IsSystem], [RecordStatus], [CreateUserID], [CreateDate], [ModifyUserID], [ModifyDate], [IsTranslated2EN], [Dummy], [DummyDate])
SELECT DISTINCT cs.[StringType], cs.[RefTable], N'Cash-03-20_Base', N'Generate GIRO Collection', N'Generate GIRO Collection', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'Y', N'Active', 1, GETDATE(), 1, GETDATE(), NULL, N'N', GETDATE()
FROM Sys_Menu m WITH (NOLOCK) JOIN CF_String cs WITH (NOLOCK) ON cs.StringCode = m.MnuBaseNameStringCode
WHERE m.MnuNo = N'mcorp-15-08';  -- menu name shown in Menu Template tree


-- Check counts
SELECT N'Sys_Menu' AS Item, COUNT(*) AS Cnt FROM Sys_Menu WHERE MnuNo = N'Cash-03-20'
UNION ALL SELECT N'Sys_BaseDt', COUNT(*) FROM Sys_BaseDt WHERE BdtBseNo = N'CB.GIROCollection'
UNION ALL SELECT N'Sys_ListDt', COUNT(*) FROM Sys_ListDt WHERE LdtLstNo = N'CB.GIROCollection'
UNION ALL SELECT N'Sys_Filter', COUNT(*) FROM Sys_Filter WHERE FltBseNo = N'CB.GIROCollection'
UNION ALL SELECT N'Sys_ContextMenuClass', COUNT(*) FROM Sys_ContextMenuClass WHERE MnuClass = N'CB.GIROCollection'
UNION ALL SELECT N'Sys_ContextMenu', COUNT(*) FROM Sys_ContextMenu WHERE MnuClass = N'CB.GIROCollection'
UNION ALL SELECT N'Sys_TabDt (View)', COUNT(*) FROM Sys_TabDt WHERE TdtTabNo = N'CB.GIROCollectionView'
UNION ALL SELECT N'CF_String', COUNT(*) FROM CF_String WHERE StringCode IN (
    N'CB.GIROCollection_BillID',
    N'CB.GIROCollection_CompanyID',
    N'CB.GIROCollection_Module',
    N'CB.GIROCollection_DebtorID',
    N'CB.GIROCollection_DebtorAccount',
    N'CB.GIROCollection_DebtorName',
    N'CB.GIROCollection_DocumentNo',
    N'CB.GIROCollection_DocumentDate',
    N'CB.GIROCollection_DueDate',
    N'CB.GIROCollection_DocumentDesc',
    N'CB.GIROCollection_CurrencyID',
    N'CB.GIROCollection_Currency',
    N'CB.GIROCollection_DocumentAmt',
    N'CB.GIROCollection_BalanceAmt',
    N'CB.GIROCollection_GIROBankAccountID',
    N'CB.GIROCollection_GiroBankSwiftCodeID',
    N'CB.GIROCollection_GiroAccountNo',
    N'CB.GIROCollection_IsDispute',
    N'CB.GIROCollection_RefTable',
    N'CB.GIROCollection_RecordStatus',
    N'CB.GIROCollection_ReceiptType',
    N'CB.GIROCollection_TrxExchangeRate',
    N'CB.GIROCollection_ItemCode',
    N'Cash-03-20',
    N'Sys_Base_Name_CB.GIROCollection',
    N'Sys_Base_Desc_CB.GIROCollection',
    N'Sys_List_Name_CB.GIROCollection_-1',
    N'Sys_List_Title_CB.GIROCollection_-1',
    N'Sys_List_Name_CB.GIROCollection_1',
    N'Sys_List_Title_CB.GIROCollection_1',
    N'Cash-03-20_CB.GIROCollection_GenerateAll',
    N'Cash-03-20_CB.GIROCollection_Generate',
    N'Cash-03-20_CB.GIROCollection_View',
    N'CB.GIROCollection_Title',
    N'CB.GIRO_NotGIROBank',
    N'MnuClass_CB.GIROCollection',
    N'Sys_Tab_Name_CB.GIROCollectionView',
    N'TabClass_CB.GIROCollectionView_GIROV001',
    N'Cash-03-20_Base');
-- expected: Sys_Menu 1, Sys_BaseDt 23, Sys_ListDt 22, Sys_Filter 7, Sys_ContextMenuClass 1, Sys_ContextMenu 3, Sys_TabDt (View) 11, CF_String >= 62
